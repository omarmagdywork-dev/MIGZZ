﻿# MIGZZ installer: copies the panel for After Effects + Premiere Pro (current user) and allows it to load.
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'com.migzz.panel'
$dst = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.migzz.panel'
if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
Copy-Item $src $dst -Recurse
# unsigned builds only: let CEP load the panel (a signed ZXP doesn't need this)
foreach ($v in 9..12) { New-Item -Path "HKCU:\Software\Adobe\CSXS.$v" -Force | Out-Null; Set-ItemProperty -Path "HKCU:\Software\Adobe\CSXS.$v" -Name PlayerDebugMode -Value '1' -Type String }
Write-Host 'MIGZZ اتسطب. افتح الافتر أو بريمير: Window > Extensions > MIGZZ'
