﻿$dst = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.migzz.panel'
if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
Write-Host 'MIGZZ اتشال. (المحركات والموديلات في %APPDATA%\MIGZZ ممكن تمسحها بإيدك)'
