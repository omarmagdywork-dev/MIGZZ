/*  MIGZZ — After Effects: motion tools (ExtendScript ES3).
    curves (keyframe easing) · bounce (appear with spring/bounce) · text animations · speed ramp */

// ───────────── curves: a cubic-bezier value curve → AE speed/influence on the selected keyframes
function mz_keyProps(c) {
  var out = [], ps = c.selectedProperties, i, p;
  for (i = 0; i < ps.length; i++) {
    p = ps[i];
    if (p.propertyType === PropertyType.PROPERTY && p.numKeys > 1 && p.selectedKeys && p.selectedKeys.length > 0) out.push(p);
  }
  return out;
}
function mz_isSpatial(p) { return p.propertyValueType === PropertyValueType.TwoD_SPATIAL || p.propertyValueType === PropertyValueType.ThreeD_SPATIAL; }
function mz_easeable(p) {
  var t = p.propertyValueType;
  return t === PropertyValueType.OneD || t === PropertyValueType.TwoD || t === PropertyValueType.ThreeD ||
    t === PropertyValueType.TwoD_SPATIAL || t === PropertyValueType.ThreeD_SPATIAL || t === PropertyValueType.COLOR;
}
// value change per ease dimension of the segment k → k+1
function mz_segDeltas(p, k) {
  var a = p.keyValue(k), b = p.keyValue(k + 1), i, s = 0, d = [];
  if (mz_isSpatial(p)) {
    for (i = 0; i < a.length; i++) s += (b[i] - a[i]) * (b[i] - a[i]);
    return [Math.sqrt(s)];
  }
  if (a instanceof Array) { for (i = 0; i < a.length; i++) d.push(b[i] - a[i]); return d; }
  return [b - a];
}
function mz_clampInfl(x) { return Math.max(0.1, Math.min(100, x)); }
// the pairs of neighbouring selected keyframes; with one selected key, the segment after it
function mz_segments(p) {
  var sk = p.selectedKeys, out = [], i;
  for (i = 0; i < sk.length - 1; i++) if (sk[i + 1] === sk[i] + 1) out.push(sk[i]);
  if (!out.length && sk.length === 1 && sk[0] < p.numKeys) out.push(sk[0]);
  return out;
}
function mz_easeApply(b) {
  return mz_run('منحنى الحركة', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var props = mz_keyProps(c), i, j, n = 0, skipped = 0, p, segs, k, dt, dv, inE, outE, d, sp;
    if (!props.length) return mz_err('NO_KEYS');
    var linear = Math.abs(b[0] - b[1]) < 0.001 && Math.abs(b[2] - b[3]) < 0.001;
    var x1 = Math.max(0.001, b[0]), y1 = b[1], x2 = Math.min(0.999, b[2]), y2 = b[3];
    for (i = 0; i < props.length; i++) {
      p = props[i];
      if (!mz_easeable(p)) { skipped++; continue; }
      segs = mz_segments(p);
      for (j = 0; j < segs.length; j++) {
        k = segs[j];
        if (linear) {
          p.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), KeyframeInterpolationType.LINEAR);
          p.setInterpolationTypeAtKey(k + 1, KeyframeInterpolationType.LINEAR, p.keyOutInterpolationType(k + 1));
          n++; continue;
        }
        dt = p.keyTime(k + 1) - p.keyTime(k);
        dv = mz_segDeltas(p, k);
        outE = []; inE = [];
        for (d = 0; d < dv.length; d++) {
          sp = dv[d] / dt;
          if (mz_isSpatial(p)) sp = Math.abs(sp);
          outE.push(new KeyframeEase(sp * y1 / x1, mz_clampInfl(x1 * 100)));
          inE.push(new KeyframeEase(sp * (1 - y2) / (1 - x2), mz_clampInfl((1 - x2) * 100)));
        }
        p.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), KeyframeInterpolationType.BEZIER);
        p.setInterpolationTypeAtKey(k + 1, KeyframeInterpolationType.BEZIER, p.keyOutInterpolationType(k + 1));
        try { p.setTemporalAutoBezierAtKey(k, false); p.setTemporalAutoBezierAtKey(k + 1, false); } catch (e1) {}
        p.setTemporalEaseAtKey(k, p.keyInTemporalEase(k), outE);
        p.setTemporalEaseAtKey(k + 1, inE, p.keyOutTemporalEase(k + 1));
        n++;
      }
    }
    if (!n) return mz_err(skipped ? 'KEYS_KIND' : 'NO_KEYS');
    return mz_ok({ count: n, skipped: skipped });
  });
}
// reads the curve of the first selected segment back as a cubic-bezier
function mz_easeRead() {
  var c = mz_comp(); if (!c) return mz_err('NO_COMP');
  var props = mz_keyProps(c), i, p, segs, k, dt, dv, d, oe, ie, x1, x2, y1, y2;
  for (i = 0; i < props.length; i++) {
    p = props[i];
    if (!mz_easeable(p)) continue;
    segs = mz_segments(p);
    if (!segs.length) continue;
    k = segs[0];
    if (p.keyOutInterpolationType(k) === KeyframeInterpolationType.LINEAR && p.keyInInterpolationType(k + 1) === KeyframeInterpolationType.LINEAR) return mz_ok({ b: [0.33, 0.33, 0.67, 0.67], name: p.name });
    if (p.keyOutInterpolationType(k) === KeyframeInterpolationType.HOLD) return mz_err('KEYS_HOLD');
    dt = p.keyTime(k + 1) - p.keyTime(k);
    dv = mz_segDeltas(p, k);
    for (d = 0; d < dv.length; d++) if (Math.abs(dv[d]) > 1e-6) break;
    if (d === dv.length) return mz_err('KEYS_FLAT');
    oe = p.keyOutTemporalEase(k)[d]; ie = p.keyInTemporalEase(k + 1)[d];
    x1 = oe.influence / 100; x2 = 1 - ie.influence / 100;
    y1 = oe.speed * x1 * dt / dv[d]; y2 = 1 - ie.speed * (ie.influence / 100) * dt / dv[d];
    if (mz_isSpatial(p)) { y1 = Math.abs(y1); y2 = 1 - Math.abs(1 - y2); }
    return mz_ok({ b: [x1, y1, x2, y2], name: p.name });
  }
  return mz_err('NO_KEYS');
}

// ───────────── bounce / spring entrances (keyframes + an expression driven by sliders)
var MZ_SPRING = ['MIGZZ ارتداد · القوة', 'MIGZZ ارتداد · السرعة', 'MIGZZ ارتداد · الهدوء'];
var MZ_GRAV = ['MIGZZ نطة · المرونة', 'MIGZZ نطة · الجاذبية'];
function mz_fxByName(L, name) {
  var fx = L.property('ADBE Effect Parade'), i;
  for (i = 1; i <= fx.numProperties; i++) if (fx.property(i).name === name) return fx.property(i);
  return null;
}
function mz_slider(L, name, v) {
  var e = mz_fxByName(L, name);
  if (!e) { e = L.property('ADBE Effect Parade').addProperty('ADBE Slider Control'); e.name = name; }
  e = mz_fxByName(L, name);
  e.property(1).setValue(v);
}
function mz_q(s) { return '"' + s.replace(/"/g, '\\"') + '"'; }
function mz_springExpr() {
  return 'var a=effect(' + mz_q(MZ_SPRING[0]) + ')(1)/100, f=Math.max(0.1,effect(' + mz_q(MZ_SPRING[1]) + ')(1)), d=effect(' + mz_q(MZ_SPRING[2]) + ')(1);\n' +
    'var n=0; if(numKeys>0){n=nearestKey(time).index; if(key(n).time>time) n--;}\n' +
    'if(n>0){var t=time-key(n).time; var v=velocityAtTime(key(n).time-thisComp.frameDuration/10); var w=f*2*Math.PI; value+v*a*Math.sin(w*t)/Math.exp(d*t)/w;} else value;';
}
function mz_gravExpr() {
  return 'var e=Math.min(0.95,Math.max(0,effect(' + mz_q(MZ_GRAV[0]) + ')(1)/100)), g=Math.max(1,effect(' + mz_q(MZ_GRAV[1]) + ')(1)), nMax=9;\n' +
    'var n=0; if(numKeys>0){n=nearestKey(time).index; if(key(n).time>time) n--;}\n' +
    'if(n>0){var t=time-key(n).time; var v=-velocityAtTime(key(n).time-0.001)*e; var vl=length(v); var vu;\n' +
    ' if(value instanceof Array){vu=(vl>0)?normalize(v):value*0;} else {vu=(v<0)?-1:1;}\n' +
    ' var tCur=0, segDur=2*vl/g, tNext=segDur, nb=1;\n' +
    ' while(tNext<t && nb<=nMax){vl*=e; segDur*=e; tCur=tNext; tNext+=segDur; nb++;}\n' +
    ' if(nb<=nMax){var dl=t-tCur; value+vu*dl*(vl-g*dl/2);} else value;} else value;';
}
// sets two keyframes from→to with a linear arrival (the expression needs the arrival speed)
function mz_twoKeys(p, t0, t1, from, to) {
  var k0 = p.addKey(t0); p.setValueAtKey(k0, from);
  var k1 = p.addKey(t1); p.setValueAtKey(k1, to);
  k0 = p.nearestKeyIndex(t0); k1 = p.nearestKeyIndex(t1);
  p.setInterpolationTypeAtKey(k0, p.keyInInterpolationType(k0), KeyframeInterpolationType.LINEAR);
  p.setInterpolationTypeAtKey(k1, KeyframeInterpolationType.LINEAR, p.keyOutInterpolationType(k1));
}
function mz_fadeKeys(L, t0, t) {
  var o = L.property('ADBE Transform Group').property('ADBE Opacity'), v = o.valueAtTime(t0 + t, true);
  var k0 = o.addKey(t0); o.setValueAtKey(k0, 0);
  var k1 = o.addKey(t0 + t); o.setValueAtKey(k1, v);
}
function mz_add(v, d) { var o = [], i; for (i = 0; i < v.length; i++) o.push(v[i] + (d[i] || 0)); return o; }
function mz_bounce(kind, o) {
  return mz_run('حركة ظهور بارتداد', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, i, L, t0, t1, tr, n = 0, gravity = kind === 'drop';
    if (!sel.length) return mz_err('NO_SEL');
    for (i = 0; i < sel.length; i++) {
      L = sel[i];
      if (!mz_isAV(L)) continue;
      t0 = o.at === 'in' ? L.inPoint : c.time;
      t1 = t0 + o.dur;
      if (gravity) { mz_slider(L, MZ_GRAV[0], o.amp * 0.6); mz_slider(L, MZ_GRAV[1], 6000 * o.freq / 3); }
      else { mz_slider(L, MZ_SPRING[0], o.amp); mz_slider(L, MZ_SPRING[1], o.freq); mz_slider(L, MZ_SPRING[2], o.decay); }
      tr = L.property('ADBE Transform Group');
      var pos = tr.property('ADBE Position'), sc = tr.property('ADBE Scale'), rot = tr.property('ADBE Rotate Z');
      var posY = pos.dimensionsSeparated ? tr.property('ADBE Position_1') : null, posX = pos.dimensionsSeparated ? tr.property('ADBE Position_0') : null;
      var expr = gravity ? mz_gravExpr() : mz_springExpr(), fv, from;
      if (kind === 'pop' || kind === 'spin' || kind === 'jelly') {
        fv = sc.valueAtTime(t1, true);
        from = kind === 'jelly' ? [fv[0] * 1.35, fv[1] * 0.65].concat(fv.length > 2 ? [fv[2]] : []) : [0, 0].concat(fv.length > 2 ? [fv[2]] : []);
        mz_twoKeys(sc, t0, t1, from, fv); sc.expression = expr;
        if (kind === 'spin') { fv = rot.valueAtTime(t1, true); mz_twoKeys(rot, t0, t1, fv - 180, fv); rot.expression = expr; }
      } else {
        var dx = kind === 'slideR' ? c.width * 0.45 : (kind === 'slideL' ? -c.width * 0.45 : 0);
        var dy = kind === 'drop' ? -c.height * 0.6 : (kind === 'rise' ? c.height * 0.35 : 0);
        if (posY) {
          var P = dx ? posX : posY, v1 = P.valueAtTime(t1, true);
          mz_twoKeys(P, t0, t1, v1 + (dx || dy), v1); P.expression = expr;
        } else {
          fv = pos.valueAtTime(t1, true);
          mz_twoKeys(pos, t0, t1, mz_add(fv, [dx, dy]), fv); pos.expression = expr;
        }
        mz_fadeKeys(L, t0, Math.min(o.dur * 0.5, 0.15));
      }
      n++;
    }
    if (!n) return mz_err('NO_SEL');
    return mz_ok({ count: n });
  });
}
// removes the bounce sliders/expressions (keyframes stay)
function mz_bounceRemove() {
  return mz_run('شيل الارتداد', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, i, j, L, fx, tr, names = ['ADBE Position', 'ADBE Position_0', 'ADBE Position_1', 'ADBE Scale', 'ADBE Rotate Z'], p, n = 0;
    if (!sel.length) return mz_err('NO_SEL');
    for (i = 0; i < sel.length; i++) {
      L = sel[i]; if (!mz_isAV(L)) continue;
      tr = L.property('ADBE Transform Group');
      for (j = 0; j < names.length; j++) {
        p = tr.property(names[j]);
        if (p && p.canSetExpression && /MIGZZ (ارتداد|نطة)/.test(p.expression)) { p.expression = ''; n++; }
      }
      fx = L.property('ADBE Effect Parade');
      for (j = fx.numProperties; j >= 1; j--) if (/^MIGZZ (ارتداد|نطة)/.test(fx.property(j).name)) fx.property(j).remove();
    }
    return mz_ok({ count: n });
  });
}

// ───────────── text animations (Text Animators with a Range or Wiggly selector)
// p: [prop, value]; values marked f are multiplied by the font size
var MZ_TA = {
  fade: { p: [['op', 0]] },
  rise: { p: [['op', 0], ['pos', [0, 0.9], 'f']] },
  drop: { p: [['op', 0], ['pos', [0, -0.9], 'f']] },
  slideR: { p: [['op', 0], ['pos', [1.2, 0], 'f']] },
  slideL: { p: [['op', 0], ['pos', [-1.2, 0], 'f']] },
  pop: { p: [['op', 0], ['scale', [0, 0]]] },
  zoom: { p: [['op', 0], ['scale', [280, 280]]] },
  blur: { p: [['op', 0], ['blur', [0.45, 0.45], 'f']] },
  track: { p: [['op', 0], ['track', 350]] },
  rotate: { p: [['op', 0], ['rot', -90]] },
  skew: { p: [['op', 0], ['skew', 45], ['pos', [0.6, 0], 'f']] },
  type: { p: [['op', 0]], shape: 'square' },
  random: { p: [['op', 0]], rnd: true },
  shake: { p: [['pos', [0.12, 0.12], 'f']], wiggle: { freq: 6, corr: 0, minA: -100 } },
  'float': { p: [['pos', [0, 0.18], 'f']], wiggle: { freq: 0.8, corr: 75, minA: -100 } },
  flicker: { p: [['op', 0]], wiggle: { freq: 8, corr: 0, minA: 0 } },
  wave: { p: [['pos', [0, -0.25], 'f']], wave: true }
};
var MZ_TA_PROP = { op: 'ADBE Text Opacity', pos: 'ADBE Text Position 3D', scale: 'ADBE Text Scale 3D', blur: 'ADBE Text Blur', track: 'ADBE Text Tracking Amount', rot: 'ADBE Text Rotation', skew: 'ADBE Text Skew' };
var MZ_TA_GROUP = { 'in': 'MIGZZ دخول', out: 'MIGZZ خروج', loop: 'MIGZZ مستمر' };
function mz_taValue(k, v, fs) {
  var x;
  if (v instanceof Array) {
    x = [v[0], v[1]];
    if (k === 'pos') x.push(0);
    if (k === 'scale') x.push(100);
    return x;
  }
  return v;
}
function mz_animators(L) { return L.property('ADBE Text Properties').property('ADBE Text Animators'); }
function mz_taClear(L, prefix) {
  var A = mz_animators(L), i, n = 0;
  for (i = A.numProperties; i >= 1; i--) if (A.property(i).name.indexOf(prefix) === 0) { A.property(i).remove(); n++; }
  return n;
}
function mz_easeKeys(p, linear) {
  var i, e = new KeyframeEase(0, 70);
  for (i = 1; i <= p.numKeys; i++) {
    if (linear) p.setInterpolationTypeAtKey(i, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
    else p.setTemporalEaseAtKey(i, [e], [e]);
  }
}
// o: { preset, group: in|out|loop, unit: 1 chars | 3 words | 4 lines, dur, spread (0..100), at: in|cti }
function mz_textAnim(o) {
  return mz_run('أنيميشن النص', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, i, j, L, n = 0, P = MZ_TA[o.preset];
    if (!P) return mz_err('EXC', 'preset ' + o.preset);
    if (!sel.length) return mz_err('NO_SEL');
    for (i = 0; i < sel.length; i++) {
      L = sel[i];
      if (!(L instanceof TextLayer)) continue;
      var fs = 60;
      try { fs = L.property('ADBE Text Properties').property('ADBE Text Document').value.fontSize; } catch (e0) {}
      var prefix = MZ_TA_GROUP[o.group];
      mz_taClear(L, prefix);
      var an = mz_animators(L).addProperty('ADBE Text Animator');
      an.name = prefix + ' · ' + o.label;
      var idx = an.propertyIndex;
      var AN = function () { return mz_animators(L).property(idx); };
      for (j = 0; j < P.p.length; j++) {
        var key = P.p[j][0], v = P.p[j][1];
        if (P.p[j][2] === 'f') v = v instanceof Array ? [v[0] * fs, v[1] * fs] : v * fs;
        AN().property('ADBE Text Animator Properties').addProperty(MZ_TA_PROP[key]);
        AN().property('ADBE Text Animator Properties').property(MZ_TA_PROP[key]).setValue(mz_taValue(key, v, fs));
      }
      var t0, t1;
      if (o.group === 'out') { t1 = o.at === 'cti' ? c.time + o.dur : L.outPoint; t0 = t1 - o.dur; }
      else { t0 = o.at === 'cti' ? c.time : L.inPoint; t1 = t0 + o.dur; }
      if (P.wiggle) {
        AN().property('ADBE Text Selectors').addProperty('ADBE Text Wiggly Selector');
        var w = AN().property('ADBE Text Selectors').property(1);
        try { w.property('ADBE Text Range Type2').setValue(o.unit); } catch (e1) {}
        try { w.property('ADBE Text Temporal Freq').setValue(P.wiggle.freq); } catch (e2) {}
        try { w.property('ADBE Text Character Correlation').setValue(P.wiggle.corr); } catch (e3) {}
        try { w.property('ADBE Text Wiggly Min Amount').setValue(P.wiggle.minA); } catch (e4) {}
      } else if (P.wave) {
        AN().property('ADBE Text Selectors').addProperty('ADBE Text Expressible Selector');
        var x = AN().property('ADBE Text Selectors').property(1);
        try { x.property('ADBE Text Range Type2').setValue(o.unit); } catch (e5) {}
        x.property('ADBE Text Expressible Amount').expression = 'var s=Math.sin(time*4 - textIndex*0.6)*100; [s, s, s];';
      } else {
        AN().property('ADBE Text Selectors').addProperty('ADBE Text Selector');
        var s = AN().property('ADBE Text Selectors').property(1);
        var adv = s.property('ADBE Text Range Advanced');
        try { adv.property('ADBE Text Range Type2').setValue(o.unit); } catch (e6) {}
        var square = P.shape === 'square', W = square ? 100 : Math.max(5, Math.min(100, o.spread));
        adv.property('ADBE Text Range Shape').setValue(square ? 1 : (o.group === 'out' ? 3 : 2));
        if (square) { try { adv.property('ADBE Text Selector Smoothness').setValue(0); } catch (e7) {} }
        if (P.rnd) { try { adv.property('ADBE Text Randomize Order').setValue(1); } catch (e8) {} }
        s.property('ADBE Text Percent Start').setValue(0);
        s.property('ADBE Text Percent End').setValue(W);
        var off = s.property('ADBE Text Percent Offset');
        off.setValuesAtTimes([t0, t1], square ? [0, 100] : [-W, 100]);
        if (o.group === 'out' && square) off.setValuesAtTimes([t0, t1], [100, 0]);
        mz_easeKeys(off, square);
      }
      n++;
    }
    if (!n) return mz_err('TEXT_ONLY');
    return mz_ok({ count: n });
  });
}
function mz_textAnimRemove() {
  return mz_run('شيل أنيميشن النص', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, i, n = 0;
    for (i = 0; i < sel.length; i++) if (sel[i] instanceof TextLayer) n += mz_taClear(sel[i], 'MIGZZ ');
    if (!sel.length) return mz_err('NO_SEL');
    return mz_ok({ count: n });
  });
}

// ───────────── speed ramp (time remap keyframes computed by the panel)
function mz_speedInfo(workOnly) {
  var c = mz_comp(); if (!c) return mz_err('NO_COMP');
  var sel = c.selectedLayers;
  if (sel.length !== 1) return mz_err('VID_ONE');
  var L = sel[0];
  if (!(L instanceof AVLayer) || !L.source || !L.canSetTimeRemapEnabled || L.source.duration <= 0) return mz_err('SPEED_KIND');
  if (Math.abs(L.stretch - 100) > 0.01) return mz_err('CAP_STRETCH');
  var a = L.inPoint, b = L.outPoint;
  if (workOnly) { a = Math.max(a, c.workAreaStart); b = Math.min(b, c.workAreaStart + c.workAreaDuration); }
  if (b - a < 0.2) return mz_err('CAP_EMPTY');
  var srcA, srcB;
  if (L.timeRemapEnabled) {
    var tr = L.property('ADBE Time Remapping');
    srcA = tr.valueAtTime(a, true); srcB = tr.valueAtTime(b, true);
  } else { srcA = a - L.startTime; srcB = b - L.startTime; }
  return mz_ok({ id: L.id, a: a, b: b, srcA: srcA, srcB: srcB, fps: 1 / c.frameDuration, layerIn: L.inPoint, layerOut: L.outPoint, name: L.name });
}
// o: { id, times: [comp times], values: [source times], oldB: end of the ramped part before, blend }
function mz_speedApply(o) {
  return mz_run('تسريع وتبطيء', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var L = mz_findLayerById(c, o.id); if (!L) return mz_err('CAP_GONE');
    var a = o.times[0], b = o.times[o.times.length - 1], oldB = o.oldB, oldOut = L.outPoint, i, kt;
    if (!L.timeRemapEnabled) L.timeRemapEnabled = true;
    var tr = L.property('ADBE Time Remapping');
    // keyframes before the ramp stay; the ones after it move by the change in length
    var T = [], V = [];
    for (i = 1; i <= tr.numKeys; i++) {
      kt = tr.keyTime(i);
      if (kt < a - 0.0005) { T.push(kt); V.push(tr.keyValue(i)); }
      else if (kt > oldB + 0.0005) { T.push(kt + (b - oldB)); V.push(tr.keyValue(i)); }
    }
    // Time Remap can't lose its last keyframe (it gets hidden): keep one, add the new ones, then drop it
    while (tr.numKeys > 1) tr.removeKey(tr.numKeys);
    var oldT = tr.keyTime(1);
    T = T.concat(o.times); V = V.concat(o.values);
    tr.setValuesAtTimes(T, V);
    var keepOld = false;
    for (i = 0; i < T.length; i++) if (Math.abs(T[i] - oldT) < 1e-4) keepOld = true;
    if (!keepOld) { i = tr.nearestKeyIndex(oldT); if (Math.abs(tr.keyTime(i) - oldT) < 1e-4) tr.removeKey(i); }
    for (i = 1; i <= tr.numKeys; i++) tr.setInterpolationTypeAtKey(i, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
    L.outPoint = oldOut > oldB + 0.001 ? oldOut + (b - oldB) : b;
    if (o.blend) { L.frameBlendingType = FrameBlendingType.PIXEL_MOTION; try { c.frameBlending = true; } catch (e) {} }
    return mz_ok({ len: b - a, keys: tr.numKeys });
  });
}
// back to normal speed: time remap off
function mz_speedReset() {
  return mz_run('رجّع السرعة', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, i, n = 0;
    for (i = 0; i < sel.length; i++) {
      if (sel[i] instanceof AVLayer && sel[i].timeRemapEnabled) {
        var L = sel[i];
        L.timeRemapEnabled = false;
        L.frameBlendingType = FrameBlendingType.NO_FRAME_BLEND;
        n++;
      }
    }
    if (!n) return mz_err('SPEED_NONE');
    return mz_ok({ count: n });
  });
}

MZ_FILE_ae_motion = 1;
