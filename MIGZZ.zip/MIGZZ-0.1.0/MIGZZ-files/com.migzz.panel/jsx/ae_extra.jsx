/*  MIGZZ — After Effects: liquid glass · image background cut-out · 3D text · 3D carousel (ExtendScript ES3). */

function mz_fxProp(fx, names, idx) {   // an effect parameter by its English name, else by index
  var i, j;
  for (j = 0; j < names.length; j++) for (i = 1; i <= fx.numProperties; i++) if (fx.property(i).name === names[j]) return fx.property(i);
  return idx ? fx.property(idx) : null;
}
function mz_q2(s) { return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"'; }

// ───────────── liquid glass: a control null + glass shape + refraction adjustment layer + rim light + soft shadow
// o: { kind: 'card'|'pill'|'circle', w, h, blur, refract, bevel, light, tint, useFx: matchName of an installed glass effect or '' }
function mz_glass(o) {
  return mz_run('زجاج سائل', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, above = sel.length ? sel[0] : null, i;
    var base = mz_uniqueLayerName(c, 'MIGZZ زجاج');
    var ctrlName = base + ' · تحكم', shapeName = base + ' · الشكل';
    // 1. control null: move / scale / rotate it, the sliders shape the glass
    var N = c.layers.addNull(); N.name = ctrlName; N.label = 9;
    N.property('ADBE Transform Group').property('ADBE Position').setValue([c.width / 2, c.height / 2]);
    var S = [['العرض', o.w], ['الارتفاع', o.h], ['الاستدارة', o.kind === 'card' ? Math.min(o.w, o.h) * 0.22 : Math.min(o.w, o.h) / 2],
      ['البلر', o.blur], ['الانكسار', o.refract], ['سُمك الحافة', o.bevel], ['اللمعة', o.light], ['الظل', 35]];
    for (i = 0; i < S.length; i++) {
      var sl = N.property('ADBE Effect Parade').addProperty('ADBE Slider Control');
      sl.name = S[i][0];
      N.property('ADBE Effect Parade').property(i + 1).property(1).setValue(S[i][1]);
    }
    var C = 'thisComp.layer(' + mz_q2(ctrlName) + ')', fx = function (n) { return C + '.effect(' + mz_q2(n) + ')(1)'; };
    var sizeX = '[' + fx('العرض') + ', ' + fx('الارتفاع') + ']';
    var follow = function (L) {   // shape contents follow the null (the layer itself stays put: effects read it untransformed)
      L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0, 0]);
      L.property('ADBE Transform Group').property('ADBE Position').setValue([0, 0]);
      var g = L.property('ADBE Root Vectors Group').property(1), t = g.property('ADBE Vector Transform Group');
      t.property('ADBE Vector Position').expression = C + '.toComp([0,0,0]).slice(0,2);';
      t.property('ADBE Vector Scale').expression = 'var s=' + C + '.transform.scale; [s[0], s[1]];';
      t.property('ADBE Vector Rotation').expression = C + '.transform.rotation;';
      var r = g.property('ADBE Vectors Group').property('ADBE Vector Shape - Rect');
      r.property('ADBE Vector Rect Size').expression = sizeX + ';';
      r.property('ADBE Vector Rect Roundness').expression = 'Math.min(' + fx('الاستدارة') + ', Math.min(' + fx('العرض') + ', ' + fx('الارتفاع') + ')/2);';
    };
    var makeShape = function (name) {
      var L = c.layers.addShape(); L.name = name;
      var g = L.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group');
      g.property('ADBE Vectors Group').addProperty('ADBE Vector Shape - Rect');
      return L;
    };
    // 2. the glass shape (hidden: used as matte and as the bump map)
    var SH = makeShape(shapeName);
    SH.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group').addProperty('ADBE Vector Graphic - Fill');
    follow(SH);
    // 2b. the user's own liquid-glass plugin works on the shape itself and reads the footage as its source
    if (o.useFx && /liquid/i.test(o.useFx)) return mz_glassPlugin(c, o, N, SH, above, fx, base);
    // 3. refraction: an adjustment layer matted to the shape
    var G = c.layers.addSolid([1, 1, 1], base, c.width, c.height, c.pixelAspect, c.duration);
    G.adjustmentLayer = true; G.label = 9;
    var E2 = G.property('ADBE Effect Parade'), usedFx = '';
    if (o.useFx) {
      try { E2.addProperty(o.useFx); usedFx = o.useFx; } catch (e0) { usedFx = ''; }
    }
    if (!usedFx) {
      var gl = E2.addProperty('CC Glass'); gl = E2.property(E2.numProperties);
      var bm = mz_fxProp(gl, ['Bump Map'], 1); try { bm.setValue(SH.index); } catch (e1) {}
      var pr = mz_fxProp(gl, ['Property'], 2); try { pr.setValue(4); } catch (e2) {}   // alpha
      var so = mz_fxProp(gl, ['Softness'], 3); so.expression = fx('سُمك الحافة') + ';';
      var he = mz_fxProp(gl, ['Height'], 4); try { he.setValue(100); } catch (e3) {}
      var di = mz_fxProp(gl, ['Displacement'], 5); di.expression = fx('الانكسار') + '*4;';   // slider 0..100 → 0..400
      try { var li = mz_fxProp(gl, ['Light Intensity'], 0); if (li) li.expression = fx('اللمعة') + ';'; } catch (e4) {}
      try { var am = mz_fxProp(gl, ['Ambient'], 0); if (am) am.setValue(85); } catch (e5) {}
      try { var dfu = mz_fxProp(gl, ['Diffuse'], 0); if (dfu) dfu.setValue(15); } catch (e6) {}
      try { var sp = mz_fxProp(gl, ['Specular'], 0); if (sp) sp.setValue(35); } catch (e7) {}
    }
    var bl = E2.addProperty('ADBE Gaussian Blur 2'); bl = E2.property(E2.numProperties);
    mz_fxProp(bl, ['Blurriness'], 1).expression = fx('البلر') + ';';
    try { mz_fxProp(bl, ['Repeat Edge Pixels'], 3).setValue(1); } catch (e8) {}   // repeat edge pixels
    var hs = E2.addProperty('ADBE HUE SATURATION'); hs = E2.property(E2.numProperties);
    try { mz_fxProp(hs, ['Master Saturation'], 4).setValue(12); mz_fxProp(hs, ['Master Lightness'], 5).setValue(4); } catch (e9) {}
    try { G.setTrackMatte(SH, TrackMatteType.ALPHA); SH.enabled = false; } catch (e10) { mz_placeAbove(c, SH, G); G.trackMatteType = TrackMatteType.ALPHA; }
    // 4. rim light: a thin gradient stroke on the edge
    var RL = makeShape(base + ' · لمعة');
    var st = RL.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group').addProperty('ADBE Vector Graphic - G-Stroke');
    st = RL.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group').property(2);
    try { st.property('ADBE Vector Stroke Width').setValue(2.5); } catch (e11) {}
    try { st.property('ADBE Vector Stroke Opacity').expression = 'Math.min(100, ' + fx('اللمعة') + '*1.6);'; } catch (e12) {}
    follow(RL);
    RL.blendingMode = BlendingMode.SCREEN; RL.label = 9;
    // 4b. inner glow: a wide soft white edge inside the glass (sells the thickness)
    var IG = makeShape(base + ' · توهج');
    var ist = IG.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group').addProperty('ADBE Vector Graphic - Stroke');
    ist = IG.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group').property(2);
    try { ist.property('ADBE Vector Stroke Color').setValue([1, 1, 1]); ist.property('ADBE Vector Stroke Width').expression = fx('سُمك الحافة') + '*0.9;'; } catch (e14) {}
    follow(IG);
    var igb = IG.property('ADBE Effect Parade').addProperty('ADBE Gaussian Blur 2'); IG.property('ADBE Effect Parade').property(1).property(1).expression = fx('سُمك الحافة') + '*0.6;';
    IG.property('ADBE Transform Group').property('ADBE Opacity').expression = 'Math.min(60, ' + fx('اللمعة') + '*0.45);';
    IG.blendingMode = BlendingMode.SCREEN; IG.label = 9;
    // 5. soft shadow under the glass
    var SD = makeShape(base + ' · ظل');
    var sf = SD.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group').addProperty('ADBE Vector Graphic - Fill');
    SD.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group').property(2).property('ADBE Vector Fill Color').setValue([0, 0, 0]);
    follow(SD);
    SD.property('ADBE Transform Group').property('ADBE Position').setValue([0, 12]);
    SD.property('ADBE Transform Group').property('ADBE Opacity').expression = fx('الظل') + ';';
    var sb = SD.property('ADBE Effect Parade').addProperty('ADBE Box Blur2'); SD.property('ADBE Effect Parade').property(1).property(1).setValue(18);
    SD.label = 9;
    // order (top → bottom): null, rim, glass(+matte), shadow, … the footage
    if (above) mz_placeAbove(c, SD, above);
    mz_placeAbove(c, G, SD);
    try { mz_placeAbove(c, SH, G); } catch (e13) {}
    mz_placeAbove(c, IG, G);
    mz_placeAbove(c, RL, IG);
    mz_placeAbove(c, N, RL);
    try { IG.setTrackMatte(SH, TrackMatteType.ALPHA); } catch (e15) {}
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    N.selected = true;
    return mz_ok({ name: base, fx: usedFx || 'CC Glass' });
  });
}
// glass made by a liquid-glass plugin (ToolsForMotion «Liquid Glass»): the effect sits on the glass shape,
// refracts the layer under it, and draws its own highlights, edge and shadow. The null's sliders still drive it.
function mz_glassPlugin(c, o, N, SH, above, fx, base) {
  var E = SH.property('ADBE Effect Parade'), L;
  try { L = E.addProperty(o.useFx); } catch (e0) { return mz_err('EXC', 'effect ' + o.useFx); }
  L = E.property(E.numProperties);
  var set = function (names, v, expr) { var p = mz_fxProp(L, names, 0); if (!p) return; try { if (expr) p.expression = expr; else p.setValue(v); } catch (e) {} };
  if (above) set(['Source Layer'], above.index);
  set(['Quality'], 3);
  set(['Strength'], 0, fx('الانكسار') + '*2.4;');
  set(['Thickness (Blur)'], 0, fx('البلر') + '/4;');
  set(['Edge Width'], 0, fx('سُمك الحافة') + '/3.5;');
  set(['Intensity'], 0, fx('اللمعة') + '*6.5;');
  set(['Enable'], 1);
  set(['Opacity'], 0, fx('الظل') + ';');
  SH.enabled = true; SH.label = 9; SH.name = base;
  if (above) mz_placeAbove(c, SH, above);
  mz_placeAbove(c, N, SH);
  var i; for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
  N.selected = true;
  return mz_ok({ name: base, fx: L.name });
}
// installed effects whose name looks like glass (so the panel can offer them)
function mz_findFx(pattern) {
  var re = new RegExp(pattern, 'i'), out = [], i;
  for (i = 0; i < app.effects.length; i++) { var e = app.effects[i]; if (re.test(e.displayName) || re.test(e.matchName)) out.push({ name: e.displayName, match: e.matchName, cat: e.category }); }
  return mz_ok({ list: out });
}

// ───────────── 3D text: extruded and bevelled (Advanced 3D renderer)
function mz_text3d(o) {
  return mz_run('نص 3D', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var rn = c.renderers, adv = '', i;
    for (i = 0; i < rn.length; i++) if (/advanced|mercury/i.test(rn[i])) adv = rn[i];
    if (!adv) return mz_err('AE_3D_OLD');
    c.renderer = adv;
    var sel = c.selectedLayers, L = null;
    for (i = 0; i < sel.length; i++) if (sel[i] instanceof TextLayer) { L = sel[i]; break; }
    if (!L) {
      L = c.layers.addText(o.text || 'MIGZZ');
      var d = L.property('ADBE Text Properties').property('ADBE Text Document').value; d.fontSize = Math.round(c.height * 0.14); d.fillColor = [1, 1, 1]; d.justification = ParagraphJustification.CENTER_JUSTIFY;
      L.property('ADBE Text Properties').property('ADBE Text Document').setValue(d);
      var r = L.sourceRectAtTime(c.time, false);
      L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([r.left + r.width / 2, r.top + r.height / 2]);
      L.property('ADBE Transform Group').property('ADBE Position').setValue([c.width / 2, c.height / 2]);
    }
    L.threeDLayer = true;
    // AE scripting keeps Geometry Options «hidden» under Advanced 3D, but they can be set under the
    // Cinema 4D renderer (ADBE Ernst) and the values stay when we switch back.
    var ernst = '';
    for (i = 0; i < rn.length; i++) if (/ernst|cinema/i.test(rn[i])) ernst = rn[i];
    if (ernst) { try { c.renderer = ernst; } catch (e0) {} }
    var g = L.property('ADBE Extrsn Options Group') || L.property('Geometry Options');
    try { g.property('ADBE Extrsn Depth').setValue(o.depth); } catch (e1) {}
    try { g.property('ADBE Bevel Styles').setValue(o.bevel > 0 ? 2 : 1); g.property('ADBE Bevel Depth').setValue(o.bevel); } catch (e2) {}
    if (c.renderer !== adv) c.renderer = adv;
    try { L.property('ADBE Transform Group').property('ADBE Orientation').setValue([-12, 22, 0]); } catch (e3) {}
    if (o.light) {
      var k = c.layers.addLight(mz_uniqueLayerName(c, 'MIGZZ نور النص'), [c.width / 2, c.height / 2]);
      try { k.lightType = LightType.POINT; } catch (e4) {}
      k.property('ADBE Transform Group').property('ADBE Position').setValue([c.width * 0.3, c.height * 0.25, -900]);
      try { var a = c.layers.addLight(mz_uniqueLayerName(c, 'MIGZZ نور عام'), [c.width / 2, c.height / 2]); a.lightType = LightType.AMBIENT; a.property('ADBE Light Options Group').property('ADBE Light Intensity').setValue(45); } catch (e5) {}
    }
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    var dv = -1; try { dv = g.property('ADBE Extrsn Depth').value; } catch (e6) {}
    return mz_ok({ name: L.name, depth: dv, renderer: c.renderer });
  });
}

// ───────────── 3D carousel: the selected layers on a ring that turns
function mz_carousel(o) {
  return mz_run('كاروسيل 3D', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, i, n = 0, list = [];
    for (i = 0; i < sel.length; i++) if (mz_isAV(sel[i])) list.push(sel[i]);
    if (list.length < 3) return mz_err('CAROUSEL_MIN');
    var N = c.layers.addNull(); N.name = mz_uniqueLayerName(c, 'MIGZZ كاروسيل'); N.threeDLayer = true; N.label = 11;
    N.property('ADBE Transform Group').property('ADBE Position').setValue([c.width / 2, c.height / 2, 0]);
    var R = o.radius || Math.min(c.width * 0.3, c.height * 0.42), t0 = c.time;   // the front card comes closer and grows: keep the ring inside the frame
    for (i = 0; i < list.length; i++) {
      var L = list[i], a = i / list.length * 2 * Math.PI;
      L.threeDLayer = true;
      L.parent = null;
      L.property('ADBE Transform Group').property('ADBE Position').setValue([c.width / 2 + R * Math.sin(a), c.height / 2, -R * Math.cos(a)]);
      L.property('ADBE Transform Group').property('ADBE Rotate Y').setValue(-a * 180 / Math.PI);
      L.parent = N;
      if (o.face) L.property('ADBE Transform Group').property('ADBE Rotate Y').expression = '// always face the viewer\nvar p = parent.transform.yRotation; -p;';
      n++;
    }
    var ry = N.property('ADBE Transform Group').property('ADBE Rotate Y'), dur = Math.max(2, Math.min(c.duration - t0, o.dur || 8));
    ry.setValuesAtTimes([t0, t0 + dur], [0, o.dir < 0 ? -360 : 360]);
    for (i = 1; i <= ry.numKeys; i++) ry.setInterpolationTypeAtKey(i, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
    try { N.property('ADBE Transform Group').property('ADBE Rotate X').setValue(o.tilt || 14); } catch (e) {}
    mz_placeAbove(c, N, list[0]);
    return mz_ok({ count: n, name: N.name });
  });
}

// ───────────── the cut-out image replaces the layer's picture on a copy (the original stays, hidden)
function mz_cutImageApply(file, id) {
  var c = mz_comp(), f = new File(file);
  if (!c) return mz_err('NO_COMP');
  if (!f.exists) return mz_err('FILE_MISSING');
  var L = mz_findLayerById(c, id); if (!L) return mz_err('CAP_GONE');
  return mz_run('شيل خلفية الصورة', function () {
    var it = app.project.importFile(new ImportOptions(f));
    it.parentFolder = mz_projectFolder('MIGZZ');
    var D = L.duplicate();
    D.replaceSource(it, false);
    D.name = L.name + ' · من غير خلفية';
    L.enabled = false;
    var i; for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    D.selected = true;
    return mz_ok({ name: D.name });
  });
}
function mz_stillInfo() {
  var c = mz_comp(); if (!c) return mz_err('NO_COMP');
  var sel = c.selectedLayers;
  if (sel.length !== 1) return mz_err('ONE_LAYER');
  var L = sel[0];
  if (!(L instanceof AVLayer) || !L.source || !L.source.file || !L.source.mainSource || !L.source.mainSource.isStill) return mz_err('IMG_ONLY');
  return mz_ok({ path: L.source.file.fsName, id: L.id, name: L.name });
}

// ───────────── transitions with sound: an adjustment layer around the playhead (+ a sound effect)
// kind: zoom | whipL | whipR | spin | flash | glitch
function mz_easeKey(p, k, inSp, outSp, inInf, outInf) {
  var dims = p.keyInTemporalEase(k).length, a = [], b = [], i;
  for (i = 0; i < dims; i++) { a.push(new KeyframeEase(inSp, inInf)); b.push(new KeyframeEase(outSp, outInf)); }
  p.setTemporalEaseAtKey(k, a, b);
}
function mz_transition(kind, dur, sfx) {
  return mz_run('ترانزيشن', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var t = c.time, f = c.frameDuration, t0 = Math.max(0, t - dur / 2), t1 = t + dur / 2, W = c.width, H = c.height, i;
    var A = c.layers.addSolid([1, 1, 1], mz_uniqueLayerName(c, 'MIGZZ ترانزيشن · ' + kind), W, H, c.pixelAspect, c.duration);
    A.adjustmentLayer = true; A.label = 14;
    A.inPoint = t0; A.outPoint = t1;
    var fx = A.property('ADBE Effect Parade');
    if (kind === 'zoom' || kind === 'whipL' || kind === 'whipR' || kind === 'spin') {
      var mt = fx.addProperty('ADBE Tile'); mt = fx.property(fx.numProperties);
      try { mz_fxProp(mt, ['Output Width'], 4).setValue(kind === 'zoom' || kind === 'spin' ? 300 : 500); mz_fxProp(mt, ['Output Height'], 5).setValue(300); mz_fxProp(mt, ['Mirror Edges'], 6).setValue(1); } catch (e0) {}   // output size, mirror edges
      var tf = fx.addProperty('ADBE Geometry2'); tf = fx.property(fx.numProperties);
      try { mz_fxProp(tf, ["Use Composition's Shutter Angle"], 10).setValue(0); mz_fxProp(tf, ['Shutter Angle'], 11).setValue(360); } catch (e1) {}   // own shutter angle → real motion blur
      var P;
      if (kind === 'zoom') { P = mz_fxProp(tf, ['Scale', 'Scale Height'], 4); P.setValuesAtTimes([t0, t - f, t, t1], [100, 320, 30, 100]); }
      else if (kind === 'spin') { P = mz_fxProp(tf, ['Rotation'], 8); P.setValuesAtTimes([t0, t - f, t, t1], [0, 160, -160, 0]); }
      else {
        var dx = kind === 'whipL' ? -W : W;
        P = mz_fxProp(tf, ['Position'], 2); P.setValuesAtTimes([t0, t - f, t, t1], [[W / 2, H / 2], [W / 2 + dx, H / 2], [W / 2 - dx, H / 2], [W / 2, H / 2]]);
      }
      // accelerate into the cut, jump, decelerate out of it
      P.setInterpolationTypeAtKey(2, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.HOLD);
      mz_easeKey(P, 1, 0, 0, 33, 85);
      mz_easeKey(P, 4, 0, 0, 85, 33);
    } else if (kind === 'flash') {
      var ex = fx.addProperty('ADBE Exposure2'); ex = fx.property(fx.numProperties);
      var e = mz_fxProp(ex, ['Exposure'], 3); e.setValuesAtTimes([t0, t, t1], [0, 4, 0]);
      mz_easeKey(e, 1, 0, 0, 33, 70); mz_easeKey(e, 3, 0, 0, 70, 33);
    } else {
      var ww = fx.addProperty('ADBE Wave Warp'); ww = fx.property(fx.numProperties);
      try { mz_fxProp(ww, ['Wave Type'], 1).setValue(2); mz_fxProp(ww, ['Wave Width'], 3).setValue(Math.round(W / 6)); mz_fxProp(ww, ['Wave Speed'], 5).setValue(0); } catch (e2) {}   // square waves, still
      var h = mz_fxProp(ww, ['Wave Height'], 2); h.setValuesAtTimes([t0, t - f, t, t + f * 2, t1], [0, 60, 120, 40, 0]);
      for (i = 1; i <= h.numKeys; i++) h.setInterpolationTypeAtKey(i, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);
      var sh = fx.addProperty('ADBE Geometry2'); sh = fx.property(fx.numProperties);
      mz_fxProp(sh, ['Position'], 2).expression = 'var on = Math.abs(time - ' + t + ') < ' + (dur / 2) + '; on ? value + [random(-30,30), random(-8,8)] : value;';
    }
    var S = null;
    if (sfx) {
      var it = app.project.importFile(new ImportOptions(new File(sfx)));
      it.parentFolder = mz_projectFolder('MIGZZ');
      S = c.layers.add(it);
      S.name = 'MIGZZ صوت ترانزيشن · ' + kind;
      S.startTime = Math.max(0, t - (kind === 'flash' ? 0.05 : 0.38));
      S.moveToEnd();
    }
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    A.selected = true;
    return mz_ok({ name: A.name, sound: !!S });
  });
}

// ───────────── text on a path: circle (spins), arc, or wave
function mz_textPath(o) {
  return mz_run('نص على مسار', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers;
    if (sel.length !== 1 || !(sel[0] instanceof TextLayer)) return mz_err('TEXT_ONLY');
    var L = sel[0], r = L.sourceRectAtTime(c.time, false), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    var len = Math.max(200, r.width), sh = new Shape(), k = 0.5523;
    if (o.shape === 'circle') {
      var R = Math.max(120, len / (2 * Math.PI) * 1.15);
      sh.vertices = [[cx, cy - R], [cx + R, cy], [cx, cy + R], [cx - R, cy]];
      sh.inTangents = [[-R * k, 0], [0, -R * k], [R * k, 0], [0, R * k]];
      sh.outTangents = [[R * k, 0], [0, R * k], [-R * k, 0], [0, -R * k]];
      sh.closed = true;
    } else if (o.shape === 'arc') {
      var R2 = len * 0.6;
      sh.vertices = [[cx - R2, cy + R2 * 0.3], [cx, cy - R2 * 0.35], [cx + R2, cy + R2 * 0.3]];
      sh.inTangents = [[0, 0], [-R2 * 0.55, 0], [0, -R2 * 0.3]];
      sh.outTangents = [[0, -R2 * 0.3], [R2 * 0.55, 0], [0, 0]];
      sh.closed = false;
    } else {
      var w = len * 1.1, a = r.height * 0.9;
      sh.vertices = [[cx - w / 2, cy], [cx - w / 6, cy - a], [cx + w / 6, cy + a], [cx + w / 2, cy]];
      sh.inTangents = [[0, 0], [-w / 10, 0], [-w / 10, 0], [-w / 10, 0]];
      sh.outTangents = [[w / 10, 0], [w / 10, 0], [w / 10, 0], [0, 0]];
      sh.closed = false;
    }
    var M = L.property('ADBE Mask Parade').addProperty('ADBE Mask Atom');
    M = L.property('ADBE Mask Parade').property(L.property('ADBE Mask Parade').numProperties);
    M.property('ADBE Mask Shape').setValue(sh);
    M.maskMode = MaskMode.NONE;
    M.name = 'MIGZZ مسار النص';
    var po = L.property('ADBE Text Properties').property('ADBE Text Path Options');
    po.property('ADBE Text Path').setValue(M.propertyIndex);
    if (o.animate) {
      var fm = po.property('ADBE Text First Margin'), t0 = c.time, d = o.dur || 5;
      fm.setValuesAtTimes([t0, t0 + d], o.shape === 'circle' ? [0, 2 * Math.PI * R] : [-len, len * 1.2]);
      fm.setInterpolationTypeAtKey(1, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
      fm.setInterpolationTypeAtKey(2, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
    }
    return mz_ok({ name: L.name });
  });
}

// ───────────── an icon (24×24 Lucide paths) as a shape layer, optionally drawn on
// o: { name, paths: [[closed, [x,y,inx,iny,outx,outy,...]]...], size, color [r,g,b], width, fill, draw, dur }
function mz_icon(o) {
  return mz_run('أيقونة', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, k = o.size / 24, i, j;
    var L = c.layers.addShape(); L.name = mz_uniqueLayerName(c, 'MIGZZ أيقونة · ' + o.name);
    var root = L.property('ADBE Root Vectors Group'), g = root.addProperty('ADBE Vector Group'); g.name = o.name;
    var gc = root.property(1).property('ADBE Vectors Group');
    for (i = 0; i < o.paths.length; i++) {
      var a = o.paths[i][1], v = [], ti = [], to = [];
      for (j = 0; j < a.length; j += 6) { v.push([(a[j] - 12) * k, (a[j + 1] - 12) * k]); ti.push([a[j + 2] * k, a[j + 3] * k]); to.push([a[j + 4] * k, a[j + 5] * k]); }
      var sh = new Shape(); sh.vertices = v; sh.inTangents = ti; sh.outTangents = to; sh.closed = !!o.paths[i][0];
      gc.addProperty('ADBE Vector Shape - Group');
      gc.property(gc.numProperties).property('ADBE Vector Shape').setValue(sh);
    }
    if (o.fill) { gc.addProperty('ADBE Vector Graphic - Fill'); gc.property(gc.numProperties).property('ADBE Vector Fill Color').setValue(o.color); }
    gc.addProperty('ADBE Vector Graphic - Stroke');
    var st = gc.property(gc.numProperties);
    st.property('ADBE Vector Stroke Color').setValue(o.color);
    st.property('ADBE Vector Stroke Width').setValue(o.width * k);
    try { st.property('ADBE Vector Stroke Line Cap').setValue(2); st.property('ADBE Vector Stroke Line Join').setValue(2); } catch (e) {}
    if (o.draw) {
      gc.addProperty('ADBE Vector Filter - Trim');
      var tr = gc.property(gc.numProperties).property('ADBE Vector Trim End'), t0 = c.time;
      tr.setValuesAtTimes([t0, t0 + (o.dur || 1)], [0, 100]);
      var e = new KeyframeEase(0, 70); tr.setTemporalEaseAtKey(1, [e], [e]); tr.setTemporalEaseAtKey(2, [e], [e]);
    }
    L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0, 0]);
    L.property('ADBE Transform Group').property('ADBE Position').setValue([c.width / 2, c.height / 2]);
    if (sel.length) mz_placeAbove(c, L, sel[0]);
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    return mz_ok({ name: L.name });
  });
}

// ───────────── the current frame as a PNG (for drawing / picking a box in the panel)
function mz_saveFrame(file) {
  var c = mz_comp(); if (!c) return mz_err('NO_COMP');
  if (!c.saveFrameToPng) return mz_err('AE_OLD_FRAME');
  var f = new File(file); if (f.exists) f.remove();
  c.saveFrameToPng(c.time, f);
  return mz_ok({ w: c.width, h: c.height, t: c.time });
}
// comp point → the clip's own pixels at time t (inverse of mz_srcToComp, 2D layers)
function mz_compToSrc(L, t, x, y) {
  var tr = L.property('ADBE Transform Group');
  var A = tr.property('ADBE Anchor Point').valueAtTime(t, false), P = tr.property('ADBE Position').valueAtTime(t, false);
  var S = tr.property('ADBE Scale').valueAtTime(t, false), r = -tr.property('ADBE Rotate Z').valueAtTime(t, false) * Math.PI / 180;
  var dx = x - P[0], dy = y - P[1], rx = dx * Math.cos(r) - dy * Math.sin(r), ry = dx * Math.sin(r) + dy * Math.cos(r);
  return [A[0] + rx * 100 / S[0], A[1] + ry * 100 / S[1]];
}
// the selected video + where the playhead is inside the clip's own time (for the source-frame grab)
function mz_trackSrc() {
  var r = eval('(' + mz_videoInfo(false) + ')');
  if (!r.ok) return mz_json(r);
  var c = mz_comp(), L = mz_findLayerById(c, r.id);
  r.t = Math.max(0, c.time - L.startTime);
  if (r.t < r.a - 0.01 || r.t > r.b) return mz_err('TRACK_PLAYHEAD');
  return mz_json(r);
}
function mz_trackPrep(box) {   // box in comp pixels at the playhead → video info + the box in the clip's pixels
  var r = eval('(' + mz_videoInfo(false) + ')');
  if (!r.ok) return mz_json(r);
  var c = mz_comp(), L = mz_findLayerById(c, r.id), t = c.time;
  var p0 = mz_compToSrc(L, t, box[0], box[1]), p1 = mz_compToSrc(L, t, box[0] + box[2], box[1] + box[3]);
  r.box = [Math.min(p0[0], p1[0]), Math.min(p0[1], p1[1]), Math.abs(p1[0] - p0[0]), Math.abs(p1[1] - p0[1])];
  r.a = Math.max(r.a, t - L.startTime);
  return mz_json(r);
}
// o: { id, t0, keys: [[t, x, y, conf]...], what: 'null'|'text' }
function mz_trackApply(o) {
  var c = mz_comp(); if (!c) return mz_err('NO_COMP');
  var L = mz_findLayerById(c, o.id); if (!L) return mz_err('CAP_GONE');
  return mz_run('تتبع الحركة', function () {
    var T = [], P = [], i;
    for (i = 0; i < o.keys.length; i++) { var t = o.t0 + o.keys[i][0]; T.push(t); P.push(mz_srcToComp(L, t, o.keys[i][1], o.keys[i][2])); }
    var N = c.layers.addNull(); N.name = mz_uniqueLayerName(c, 'MIGZZ تتبع'); N.label = 11;
    N.inPoint = Math.max(0, T[0]); N.outPoint = T[T.length - 1] + c.frameDuration;
    N.property('ADBE Transform Group').property('ADBE Position').setValuesAtTimes(T, P);
    mz_placeAbove(c, N, L);
    if (o.what === 'text') {
      var X = c.layers.addText('اكتب هنا'); X.name = 'MIGZZ نص التتبع';
      var d = X.property('ADBE Text Properties').property('ADBE Text Document').value; d.fontSize = Math.round(c.height * 0.035); d.fillColor = [1, 1, 1]; d.justification = ParagraphJustification.CENTER_JUSTIFY;
      try { d.applyStroke = true; d.strokeColor = [0, 0, 0]; d.strokeWidth = 4; d.strokeOverFill = false; } catch (e) {}
      X.property('ADBE Text Properties').property('ADBE Text Document').setValue(d);
      c.time = T[0];
      X.property('ADBE Transform Group').property('ADBE Position').setValue([P[0][0], P[0][1] - c.height * 0.06]);
      X.inPoint = N.inPoint; X.outPoint = N.outPoint;
      mz_placeAbove(c, X, N);
      X.parent = N;
    }
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    N.selected = true;
    return mz_ok({ name: N.name, keys: T.length });
  });
}
// drawing → a shape layer, each stroke drawn on one after the other
// o: { strokes: [[x,y,inx,iny,outx,outy,...]...] (comp px), color, width, draw, dur, arrow }
function mz_drawApply(o) {
  return mz_run('رسم على الفريم', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var L = c.layers.addShape(); L.name = mz_uniqueLayerName(c, 'MIGZZ رسم');
    var root = L.property('ADBE Root Vectors Group'), i, j, n = o.strokes.length, t0 = c.time, each = (o.dur || 1) / Math.max(1, n);
    for (i = 0; i < n; i++) {
      root.addProperty('ADBE Vector Group');
      var g = root.property(root.numProperties); g.name = 'خط ' + (i + 1);
      var gc = g.property('ADBE Vectors Group'), a = o.strokes[i], v = [], ti = [], to = [];
      for (j = 0; j < a.length; j += 6) { v.push([a[j], a[j + 1]]); ti.push([a[j + 2], a[j + 3]]); to.push([a[j + 4], a[j + 5]]); }
      var sh = new Shape(); sh.vertices = v; sh.inTangents = ti; sh.outTangents = to; sh.closed = false;
      gc.addProperty('ADBE Vector Shape - Group'); gc.property(1).property('ADBE Vector Shape').setValue(sh);
      if (o.arrow && v.length > 1) {
        var e = v[v.length - 1], b = v[Math.max(0, v.length - 3)], ang = Math.atan2(e[1] - b[1], e[0] - b[0]), hl = o.width * 4.5, h = new Shape();
        h.vertices = [[e[0] - hl * Math.cos(ang - 0.5), e[1] - hl * Math.sin(ang - 0.5)], [e[0], e[1]], [e[0] - hl * Math.cos(ang + 0.5), e[1] - hl * Math.sin(ang + 0.5)]];
        h.inTangents = [[0, 0], [0, 0], [0, 0]]; h.outTangents = [[0, 0], [0, 0], [0, 0]]; h.closed = false;
        gc.addProperty('ADBE Vector Shape - Group'); gc.property(gc.numProperties).property('ADBE Vector Shape').setValue(h);
      }
      gc.addProperty('ADBE Vector Graphic - Stroke');
      var st = gc.property(gc.numProperties);
      st.property('ADBE Vector Stroke Color').setValue(o.color); st.property('ADBE Vector Stroke Width').setValue(o.width);
      try { st.property('ADBE Vector Stroke Line Cap').setValue(2); st.property('ADBE Vector Stroke Line Join').setValue(2); } catch (e1) {}
      if (o.draw) {
        gc.addProperty('ADBE Vector Filter - Trim');
        var te = gc.property(gc.numProperties).property('ADBE Vector Trim End');
        te.setValuesAtTimes([t0 + i * each, t0 + (i + 1) * each], [0, 100]);
        var ez = new KeyframeEase(0, 60); te.setTemporalEaseAtKey(1, [ez], [ez]); te.setTemporalEaseAtKey(2, [ez], [ez]);
      }
    }
    L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0, 0]);
    L.property('ADBE Transform Group').property('ADBE Position').setValue([0, 0]);
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    return mz_ok({ name: L.name, strokes: n });
  });
}

MZ_FILE_ae_extra = 1;
