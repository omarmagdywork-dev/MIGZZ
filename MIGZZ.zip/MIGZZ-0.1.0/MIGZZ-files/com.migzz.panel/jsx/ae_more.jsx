/*  MIGZZ — After Effects: relight · presets library · importing files (ExtendScript ES3). */

// ───────────── relight: a radial light (solid + Gradient Ramp) driven by a null you drag around
var MZ_LIGHT = 'MIGZZ إضاءة';
// o: { color [r,g,b] 0..1, intensity 0..100, size (px), mode 'screen'|'add'|'soft', subject: bool }
function mz_relight(o) {
  return mz_run('إضاءة بعد التصوير', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers;
    if (sel.length !== 1 || !(sel[0] instanceof AVLayer) || (sel[0] instanceof CameraLayer) || (sel[0] instanceof LightLayer)) return mz_err('ONE_LAYER');
    var L = sel[0], i;
    var nm = mz_uniqueLayerName(c, MZ_LIGHT);
    // where the light starts: on the layer's center
    var r = L.sourceRectAtTime(c.time, false), p;
    try { p = L.sourcePointToComp([r.left + r.width / 2, r.top + r.height / 2]); } catch (e) { p = [c.width / 2, c.height / 2]; }
    var nul = c.layers.addNull();
    nul.name = nm + ' · المكان';
    nul.property('ADBE Transform Group').property('ADBE Position').setValue([p[0], p[1]]);
    nul.label = 2;
    var sol = c.layers.addSolid([0, 0, 0], nm, c.width, c.height, c.pixelAspect, c.duration);
    sol.inPoint = L.inPoint; sol.outPoint = L.outPoint;
    mz_placeAbove(c, sol, L);
    mz_placeAbove(c, nul, sol);
    var fx = sol.property('ADBE Effect Parade');
    var lc = fx.addProperty('ADBE Layer Control'); lc.name = 'MIGZZ إضاءة · المصدر';
    fx.property('MIGZZ إضاءة · المصدر').property(1).setValue(nul.index);
    var sz = fx.addProperty('ADBE Slider Control'); sz.name = 'MIGZZ إضاءة · الحجم';
    fx.property('MIGZZ إضاءة · الحجم').property(1).setValue(o.size);
    var rp = fx.addProperty('ADBE Ramp');
    rp = fx.property(fx.numProperties);
    rp.property('ADBE Ramp-0005').setValue(2);          // radial
    rp.property('ADBE Ramp-0002').setValue(o.color);    // start color
    rp.property('ADBE Ramp-0004').setValue([0, 0, 0]);  // end color
    rp.property('ADBE Ramp-0001').expression = 'var l=effect("MIGZZ إضاءة · المصدر")(1); fromComp(l.toComp(l.anchorPoint));';
    // the effect's own name can be localised: point to it by index
    rp.property('ADBE Ramp-0003').expression = 'effect(' + fx.numProperties + ')(1)+[effect("MIGZZ إضاءة · الحجم")(1),0];';
    sol.blendingMode = o.mode === 'add' ? BlendingMode.ADD : (o.mode === 'soft' ? BlendingMode.SOFT_LIGHT : BlendingMode.SCREEN);
    sol.property('ADBE Transform Group').property('ADBE Opacity').setValue(o.intensity);
    sol.label = 2;
    if (o.subject) {
      try { sol.setTrackMatte(L, TrackMatteType.ALPHA); }
      catch (e2) { return mz_ok({ name: nm, noMatte: true }); }
    }
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    nul.selected = true;
    return mz_ok({ name: nm });
  });
}

// ───────────── presets: the selected layer's effects / animation / text style ⇄ JSON
function mz_skipType(t) {
  return t === PropertyValueType.NO_VALUE || t === PropertyValueType.CUSTOM_VALUE || t === PropertyValueType.MARKER ||
    t === PropertyValueType.LAYER_INDEX || t === PropertyValueType.MASK_INDEX || t === PropertyValueType.TEXT_DOCUMENT;
}
function mz_serVal(p, v) {
  if (p.propertyValueType === PropertyValueType.SHAPE) {
    return { shape: 1, vt: v.vertices, it: v.inTangents, ot: v.outTangents, cl: v.closed };
  }
  return v;
}
function mz_deserVal(v) {
  if (v && v.shape) { var s = new Shape(); s.vertices = v.vt; s.inTangents = v.it; s.outTangents = v.ot; s.closed = v.cl; return s; }
  return v;
}
function mz_easeOut(arr) { var o = [], i; for (i = 0; i < arr.length; i++) o.push([arr[i].speed, arr[i].influence]); return o; }
function mz_easeIn(arr) { var o = [], i; for (i = 0; i < arr.length; i++) o.push(new KeyframeEase(arr[i][0], arr[i][1])); return o; }
// one property → {m, v} or {m, k:[...]} (keys relative to t0); null when nothing worth saving
function mz_serProp(p, t0, rel) {
  if (mz_skipType(p.propertyValueType)) return null;
  var o = { m: p.matchName }, i, base = null;
  if (p.canSetExpression && p.expressionEnabled && p.expression) o.x = p.expression;
  if (p.numKeys) {
    if (rel && p.keyValue(1) instanceof Array) base = p.keyValue(1);
    o.k = [];
    for (i = 1; i <= p.numKeys; i++) {
      var v = p.keyValue(i), kk;
      if (base) { var d = [], j; for (j = 0; j < v.length; j++) d.push(v[j] - base[j]); v = d; }
      kk = { t: p.keyTime(i) - t0, v: mz_serVal(p, v), ii: p.keyInInterpolationType(i), oi: p.keyOutInterpolationType(i) };
      try { kk.ie = mz_easeOut(p.keyInTemporalEase(i)); kk.oe = mz_easeOut(p.keyOutTemporalEase(i)); } catch (e1) {}
      try { if (p.isSpatial) { kk.si = p.keyInSpatialTangent(i); kk.so = p.keyOutSpatialTangent(i); } } catch (e2) {}
      o.k.push(kk);
    }
    if (base) o.rel = 1;
  } else {
    if (rel) return o.x ? o : null;
    try { o.v = mz_serVal(p, p.value); } catch (e3) { return null; }
  }
  return o;
}
function mz_serGroup(g, t0) {
  var out = [], i, p, r;
  for (i = 1; i <= g.numProperties; i++) {
    p = g.property(i);
    if (p.propertyType === PropertyType.PROPERTY) { r = mz_serProp(p, t0, false); out.push(r); }
    else out.push({ m: p.matchName, c: mz_serGroup(p, t0) });
  }
  return out;
}
function mz_firstKeyTime(g, t) {
  var i, p;
  for (i = 1; i <= g.numProperties; i++) {
    p = g.property(i);
    if (p.propertyType === PropertyType.PROPERTY) { if (p.numKeys && p.keyTime(1) < t) t = p.keyTime(1); }
    else t = mz_firstKeyTime(p, t);
  }
  return t;
}
var MZ_ANIM_PROPS = ['ADBE Anchor Point', 'ADBE Position', 'ADBE Position_0', 'ADBE Position_1', 'ADBE Scale', 'ADBE Rotate Z', 'ADBE Opacity'];
// o: { fx, anim, text }
function mz_presetGet(o) {
  var c = mz_comp(); if (!c) return mz_err('NO_COMP');
  var sel = c.selectedLayers;
  if (sel.length !== 1) return mz_err('ONE_LAYER');
  var L = sel[0], out = { v: 1, kinds: [] }, i, fxg, tr;
  if (!mz_isAV(L)) return mz_err('STYLE_KIND');
  fxg = L.property('ADBE Effect Parade'); tr = L.property('ADBE Transform Group');
  var t0 = 1e9;
  if (o.fx) t0 = mz_firstKeyTime(fxg, t0);
  if (o.anim) t0 = mz_firstKeyTime(tr, t0);
  if (t0 > 1e8) t0 = 0;
  if (o.fx && fxg.numProperties) {
    out.fx = [];
    for (i = 1; i <= fxg.numProperties; i++) {
      var e = fxg.property(i);
      out.fx.push({ m: e.matchName, n: e.name, on: e.enabled, c: mz_serGroup(e, t0) });
    }
    out.kinds.push('fx');
  }
  if (o.anim) {
    var a = [];
    for (i = 0; i < MZ_ANIM_PROPS.length; i++) {
      var p = tr.property(MZ_ANIM_PROPS[i]);
      if (!p || (MZ_ANIM_PROPS[i] === 'ADBE Position' && p.dimensionsSeparated)) continue;
      if (!p.numKeys && !(p.expressionEnabled && p.expression)) continue;   // only what moves
      var r = mz_serProp(p, t0, /Position|Anchor/.test(MZ_ANIM_PROPS[i]));
      if (r) a.push(r);
    }
    if (a.length) { out.anim = a; out.kinds.push('anim'); }
  }
  if (o.text && (L instanceof TextLayer)) {
    var d = L.property('ADBE Text Properties').property('ADBE Text Document').value;
    var t = { font: d.font, size: d.fontSize, just: d.justification, track: d.tracking };
    try { t.fill = d.applyFill ? d.fillColor : null; } catch (e4) {}
    try { if (d.applyStroke) { t.stroke = d.strokeColor; t.sw = d.strokeWidth; t.over = d.strokeOverFill; } } catch (e5) {}
    try { t.lead = d.autoLeading ? null : d.leading; } catch (e6) {}
    try { t.caps = d.allCaps; t.fb = d.fauxBold; t.fi = d.fauxItalic; } catch (e7) {}
    out.text = t; out.kinds.push('text');
  }
  if (!out.kinds.length) return mz_err('PRESET_EMPTY');
  out.name = L.name;
  return mz_ok({ preset: out });
}
function mz_applyProp(p, d, t0, base) {
  var i, k;
  if (!d || !p || p.propertyType !== PropertyType.PROPERTY) return 0;
  try {
    if (d.k) {
      while (p.numKeys) p.removeKey(1);
      var T = [], V = [];
      for (i = 0; i < d.k.length; i++) {
        var v = mz_deserVal(d.k[i].v);
        if (d.rel && base) { var x = [], j; for (j = 0; j < v.length; j++) x.push(v[j] + base[j]); v = x; }
        T.push(t0 + d.k[i].t); V.push(v);
      }
      p.setValuesAtTimes(T, V);
      for (i = 0; i < d.k.length; i++) {
        k = d.k[i];
        try { p.setInterpolationTypeAtKey(i + 1, k.ii, k.oi); } catch (e1) {}
        try { if (k.ie && k.oe) p.setTemporalEaseAtKey(i + 1, mz_easeIn(k.ie), mz_easeIn(k.oe)); } catch (e2) {}
        try { if (k.si) p.setSpatialTangentsAtKey(i + 1, k.si, k.so); } catch (e3) {}
      }
    } else if (d.v !== undefined && p.canSetValue !== false) p.setValue(mz_deserVal(d.v));
  } catch (e) { return 1; }
  try { if (d.x !== undefined && p.canSetExpression) p.expression = d.x; } catch (e4) {}
  return 0;
}
function mz_applyGroup(g, list, t0) {
  var i, bad = 0, p;
  for (i = 0; i < list.length && i < g.numProperties; i++) {
    if (!list[i]) continue;
    p = g.property(i + 1);
    if (list[i].c) { if (p.propertyType !== PropertyType.PROPERTY) bad += mz_applyGroup(p, list[i].c, t0); }
    else if (p.matchName === list[i].m) bad += mz_applyProp(p, list[i], t0, null);
  }
  return bad;
}
function mz_presetApply(P) {
  return mz_run('تطبيق بريسيت', function () {
    var c = mz_comp(); if (!c) return mz_err('NO_COMP');
    var sel = c.selectedLayers, i, j, L, n = 0, bad = 0, t0 = c.time;
    if (!sel.length) return mz_err('NO_SEL');
    for (i = 0; i < sel.length; i++) {
      L = sel[i];
      if (!mz_isAV(L)) continue;
      if (P.fx) {
        for (j = 0; j < P.fx.length; j++) {
          var fxg = L.property('ADBE Effect Parade');
          if (!fxg.canAddProperty(P.fx[j].m)) { bad++; continue; }
          var e = fxg.addProperty(P.fx[j].m);
          var idx = e.propertyIndex;
          try { L.property('ADBE Effect Parade').property(idx).name = P.fx[j].n; } catch (e1) {}
          bad += mz_applyGroup(L.property('ADBE Effect Parade').property(idx), P.fx[j].c, t0);
          if (P.fx[j].on === false) L.property('ADBE Effect Parade').property(idx).enabled = false;
        }
      }
      if (P.anim) {
        var tr = L.property('ADBE Transform Group');
        for (j = 0; j < P.anim.length; j++) {
          var p = tr.property(P.anim[j].m);
          if (!p) continue;
          if (P.anim[j].m === 'ADBE Position' && p.dimensionsSeparated) { bad++; continue; }
          bad += mz_applyProp(p, P.anim[j], t0, P.anim[j].rel ? p.valueAtTime(t0, true) : null);
        }
      }
      if (P.text && (L instanceof TextLayer)) {
        var tp = L.property('ADBE Text Properties').property('ADBE Text Document'), d = tp.value, t = P.text;
        try { d.font = t.font; } catch (e2) { bad++; }
        d.fontSize = t.size; d.tracking = t.track;
        try { d.justification = t.just; } catch (e3) {}
        if (t.fill) { d.applyFill = true; d.fillColor = t.fill; } else d.applyFill = false;
        if (t.stroke) { d.applyStroke = true; d.strokeColor = t.stroke; d.strokeWidth = t.sw; try { d.strokeOverFill = t.over; } catch (e4) {} } else d.applyStroke = false;
        try { if (t.lead) { d.autoLeading = false; d.leading = t.lead; } else d.autoLeading = true; } catch (e5) {}
        try { d.allCaps = t.caps; d.fauxBold = t.fb; d.fauxItalic = t.fi; } catch (e6) {}
        if (tp.numKeys) tp.setValueAtTime(t0, d); else tp.setValue(d);
      }
      n++;
    }
    if (!n) return mz_err('NO_SEL');
    return mz_ok({ count: n, skipped: bad });
  });
}
// an Adobe .ffx animation preset on every selected layer
function mz_applyFfx(file) {
  var c = mz_comp(), f = new File(file), sel, i, n = 0;
  if (!c) return mz_err('NO_COMP');
  if (!f.exists) return mz_err('FILE_MISSING');
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  return mz_run('تطبيق بريسيت', function () {
    for (i = 0; i < sel.length; i++) { try { sel[i].applyPreset(f); n++; } catch (e) {} }
    if (!n) return mz_err('PRESET_FAIL');
    return mz_ok({ count: n });
  });
}

// ───────────── import any file (video, image, audio) into the comp at the playhead
function mz_importMedia(file, name) {
  var f = new File(file), it, L, c = mz_comp(), s, sel, i;
  if (!f.exists) return mz_err('FILE_MISSING');
  return mz_run('Import', function () {
    it = app.project.importFile(new ImportOptions(f));
    it.parentFolder = mz_projectFolder('MIGZZ');
    if (name) { try { it.name = name; } catch (e0) {} }
    if (!c) return mz_ok({ name: it.name, comp: false });
    sel = c.selectedLayers;
    L = c.layers.add(it);
    if (sel.length) mz_placeAbove(c, L, sel[0]);
    L.startTime = c.time;
    if (it.hasVideo && it.width && it.height) {
      s = Math.min(1, c.width / it.width, c.height / it.height) * 100;
      if (it.mainSource.isStill || s < 100) L.property('ADBE Transform Group').property('ADBE Scale').setValue([s, s]);
    }
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    return mz_ok({ name: L.name, comp: true });
  });
}

// ───────────── AI results into the comp
function mz_deselectAll(c) { var i; for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false; }
// person matte: the clip gets a luma track matte from the AI matte (the original stays untouched)
function mz_maskApply(file, id, compTime, invert) {
  var c = mz_comp(), f = new File(file);
  if (!c) return mz_err('NO_COMP');
  if (!f.exists) return mz_err('FILE_MISSING');
  var L = mz_findLayerById(c, id); if (!L) return mz_err('CAP_GONE');
  return mz_run('قص الشخص', function () {
    var it = app.project.importFile(new ImportOptions(f));
    it.parentFolder = mz_projectFolder('MIGZZ');
    var M = c.layers.add(it);
    M.startTime = compTime;
    M.name = 'MIGZZ ماسك · ' + L.name;
    mz_placeAbove(c, M, L);
    var type = invert ? TrackMatteType.LUMA_INVERTED : TrackMatteType.LUMA, modern = true;
    try { L.setTrackMatte(M, type); M.enabled = false; }
    catch (e) { modern = false; L.trackMatteType = type; }
    M.label = 13;
    mz_deselectAll(c); L.selected = true;
    return mz_ok({ name: M.name, modern: modern });
  });
}
// speech / music split: two audio layers under the clip, the clip's own sound off
function mz_voiceApply(voice, music, id, compTime) {
  var c = mz_comp();
  if (!c) return mz_err('NO_COMP');
  var L = mz_findLayerById(c, id); if (!L) return mz_err('CAP_GONE');
  if (!new File(voice).exists || !new File(music).exists) return mz_err('FILE_MISSING');
  return mz_run('فصل الصوت', function () {
    var out = [], pair = [[voice, 'صوت الكلام'], [music, 'المزيكا والدوشة']], i;
    for (i = 0; i < pair.length; i++) {
      var it = app.project.importFile(new ImportOptions(new File(pair[i][0])));
      it.parentFolder = mz_projectFolder('MIGZZ');
      var A = c.layers.add(it);
      A.startTime = compTime;
      A.name = 'MIGZZ ' + pair[i][1] + ' · ' + L.name;
      A.moveAfter(i ? out[0] : L);
      A.label = 8;
      out.push(A);
    }
    try { L.audioEnabled = false; } catch (e) {}
    mz_deselectAll(c); out[0].selected = true;
    return mz_ok({ count: 2 });
  });
}
// a point of the clip's own pixels → comp coordinates at time t (2D layers)
function mz_srcToComp(L, t, x, y) {
  var tr = L.property('ADBE Transform Group');
  var A = tr.property('ADBE Anchor Point').valueAtTime(t, false), P = tr.property('ADBE Position').valueAtTime(t, false);
  var S = tr.property('ADBE Scale').valueAtTime(t, false), r = tr.property('ADBE Rotate Z').valueAtTime(t, false) * Math.PI / 180;
  var dx = (x - A[0]) * S[0] / 100, dy = (y - A[1]) * S[1] / 100;
  return [P[0] + dx * Math.cos(r) - dy * Math.sin(r), P[1] + dx * Math.sin(r) + dy * Math.cos(r)];
}
// face track → a Null that follows the face (+ text above the head, or a blur on the face)
// o: { id, t0 (comp time of the first key), keys: [[t, cx, cy, w, h, rot]...], what: 'null'|'text'|'blur' }
function mz_faceApply(o) {
  var c = mz_comp();
  if (!c) return mz_err('NO_COMP');
  var L = mz_findLayerById(c, o.id); if (!L) return mz_err('CAP_GONE');
  return mz_run('تتبع الوش', function () {
    var K = o.keys, i, T = [], P = [], S = [], R = [], sc = L.property('ADBE Transform Group').property('ADBE Scale').valueAtTime(o.t0, false)[0] / 100;
    var w0 = K[0][3], r0 = K[0][5];
    for (i = 0; i < K.length; i++) {
      var t = o.t0 + K[i][0];
      T.push(t);
      P.push(mz_srcToComp(L, t, K[i][1], K[i][2]));
      S.push([K[i][3] / w0 * 100, K[i][3] / w0 * 100]);
      R.push(K[i][5] - r0);
    }
    var N = c.layers.addNull();
    N.name = mz_uniqueLayerName(c, 'MIGZZ وش');
    N.label = 11;
    N.inPoint = Math.max(0, T[0]); N.outPoint = T[T.length - 1] + c.frameDuration;
    var tr = N.property('ADBE Transform Group');
    tr.property('ADBE Position').setValuesAtTimes(T, P);
    tr.property('ADBE Scale').setValuesAtTimes(T, S);
    tr.property('ADBE Rotate Z').setValuesAtTimes(T, R);
    mz_placeAbove(c, N, L);
    var fw = w0 * sc, fh = K[0][4] * sc, extra = null;
    if (o.what === 'text') {
      extra = c.layers.addText('اكتب هنا');
      var d = extra.property('ADBE Text Properties').property('ADBE Text Document').value;
      d.fontSize = Math.max(24, Math.round(fw * 0.32)); d.fillColor = [1, 1, 1]; d.justification = ParagraphJustification.CENTER_JUSTIFY;
      try { d.applyStroke = true; d.strokeColor = [0, 0, 0]; d.strokeWidth = Math.max(2, Math.round(d.fontSize / 12)); d.strokeOverFill = false; } catch (e1) {}
      extra.property('ADBE Text Properties').property('ADBE Text Document').setValue(d);
      c.time = T[0];
      extra.property('ADBE Transform Group').property('ADBE Position').setValue([P[0][0], P[0][1] - fh * 0.85]);
      extra.name = 'MIGZZ نص الوش';
    } else if (o.what === 'blur') {
      extra = c.layers.addSolid([1, 1, 1], 'MIGZZ بلر الوش', c.width, c.height, c.pixelAspect, c.duration);
      extra.adjustmentLayer = true;
      var m = extra.property('ADBE Mask Parade').addProperty('ADBE Mask Atom');
      var sh = new Shape(), cx = P[0][0], cy = P[0][1], rx = fw * 0.62, ry = fh * 0.72, kk = 0.5523;
      sh.vertices = [[cx, cy - ry], [cx + rx, cy], [cx, cy + ry], [cx - rx, cy]];
      sh.inTangents = [[-rx * kk, 0], [0, -ry * kk], [rx * kk, 0], [0, ry * kk]];
      sh.outTangents = [[rx * kk, 0], [0, ry * kk], [-rx * kk, 0], [0, -ry * kk]];
      sh.closed = true;
      m = extra.property('ADBE Mask Parade').property(1);
      m.property('ADBE Mask Shape').setValue(sh);
      m.property('ADBE Mask Feather').setValue([fw * 0.12, fw * 0.12]);
      var b = extra.property('ADBE Effect Parade').addProperty('ADBE Gaussian Blur 2');
      extra.property('ADBE Effect Parade').property(1).property(1).setValue(Math.max(20, fw * 0.15));
      try { extra.property('ADBE Effect Parade').property(1).property(3).setValue(1); } catch (e2) {}   // repeat edge pixels
    }
    if (extra) {
      extra.inPoint = N.inPoint; extra.outPoint = N.outPoint;
      mz_placeAbove(c, extra, N);
      c.time = T[0];
      extra.parent = N;
    }
    mz_deselectAll(c); N.selected = true;
    return mz_ok({ name: N.name, keys: T.length });
  });
}

// ───────────── a .glb model into the comp (Advanced 3D renderer) with a camera that can orbit it
function mz_selectedStill() {
  var c = mz_comp(); if (!c) return mz_err('NO_COMP');
  var sel = c.selectedLayers;
  if (sel.length === 1 && sel[0].source && sel[0].source.file && sel[0].source.mainSource && sel[0].source.mainSource.isStill) return mz_ok({ path: sel[0].source.file.fsName, name: sel[0].name });
  return mz_ok({ path: '' });
}
function mz_import3d(file, name, o) {
  var f = new File(file);
  if (!f.exists) return mz_err('FILE_MISSING');
  return mz_run('موديل 3D', function () {
    var c = mz_comp(), made = false, i;
    if (!c) { c = app.project.items.addComp(mz_uniqueName('MIGZZ 3D · ' + name), 1920, 1080, 1, 10, 30); made = true; }
    var rn = c.renderers, adv = '';
    for (i = 0; i < rn.length; i++) if (/advanced|mercury/i.test(rn[i])) adv = rn[i];
    if (!adv) return mz_err('AE_3D_OLD');
    if (c.renderer !== adv) c.renderer = adv;
    var it = app.project.importFile(new ImportOptions(f));
    it.parentFolder = mz_projectFolder('MIGZZ');
    try { it.name = name; } catch (e0) {}
    var L = c.layers.add(it);
    L.name = 'MIGZZ 3D · ' + name;
    var tr = L.property('ADBE Transform Group'), s = Math.min(c.width, c.height) * (o.size || 0.55);
    // size and centre from the model's own bounds (AE reports them for 3D model layers; 1 glTF unit ≈ 512 px at 100%)
    var k = s / 512, ox = 0, oy = -0.48 * 512;
    try { var rc = L.sourceRectAtTime(0, false); if (rc.width > 0 && rc.height > 0) { k = s / Math.max(rc.width, rc.height); ox = rc.left + rc.width / 2; oy = rc.top + rc.height / 2; } } catch (e0) {}
    try { tr.property('ADBE Scale').setValue([k * 100, k * 100, k * 100]); } catch (e2) {}
    try { tr.property('ADBE Position').setValue([c.width / 2 - ox * k, c.height / 2 - oy * k, 0]); } catch (e1) {}
    if (o.camera) {
      var N = c.layers.addNull(); N.name = mz_uniqueLayerName(c, 'MIGZZ 3D · لف الكاميرا'); N.threeDLayer = true;
      N.property('ADBE Transform Group').property('ADBE Position').setValue([c.width / 2, c.height / 2, 0]);
      var cam = c.layers.addCamera(mz_uniqueLayerName(c, 'MIGZZ 3D · كاميرا'), [c.width / 2, c.height / 2]);
      // a one-node camera on the null's −Z axis looks straight at the null; when the null turns, it orbits.
      // (a two-node camera keeps its point of interest in world space, so the model drifts out of frame)
      try { cam.autoOrient = AutoOrientType.NO_AUTO_ORIENT; } catch (e4) {}
      var zoom = 0; try { zoom = cam.property('ADBE Camera Options Group').property('ADBE Camera Zoom').value; } catch (e9) {}
      if (!(zoom > 0)) zoom = s * 3;
      cam.parent = N;
      cam.property('ADBE Transform Group').property('ADBE Position').setValue([0, 0, -zoom * 1.05]);   // at distance = zoom, 1 px = 1 px
      try { cam.property('ADBE Transform Group').property('ADBE Orientation').setValue([0, 0, 0]); } catch (e8) {}
      if (o.orbit) {
        var ry = N.property('ADBE Transform Group').property('ADBE Rotate Y'), t0 = c.time;
        ry.setValuesAtTimes([t0, t0 + Math.max(2, Math.min(c.duration - t0, 8))], [0, 360]);
        for (i = 1; i <= ry.numKeys; i++) ry.setInterpolationTypeAtKey(i, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
      }
    }
    if (o.light) {
      try { var env = c.layers.addLight(mz_uniqueLayerName(c, 'MIGZZ 3D · إضاءة البيئة'), [c.width / 2, c.height / 2]); env.lightType = LightType.ENVIRONMENT; } catch (e5) {}
      var key = c.layers.addLight(mz_uniqueLayerName(c, 'MIGZZ 3D · نور'), [c.width / 2, c.height / 2]);
      try { key.lightType = LightType.PARALLEL; } catch (e6) {}
      key.property('ADBE Transform Group').property('ADBE Position').setValue([c.width * 0.2, c.height * 0.1, -s * 2]);
      try { key.property('ADBE Light Options Group').property('ADBE Light Intensity').setValue(90); } catch (e7) {}
    }
    if (made) c.openInViewer();
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    return mz_ok({ name: L.name, comp: c.name, renderer: adv });
  });
}

// ───────────── AE preset (.ffx) → Premiere Motion Graphics Template (.mogrt), one at a time
// o: { ffx, out, name, w, h, text, size, minDur, kind: 'text'|'shape' }
function mz_lastKey(g, t) {
  var i, p;
  for (i = 1; i <= g.numProperties; i++) {
    p = g.property(i);
    if (p.propertyType === PropertyType.PROPERTY) { if (p.numKeys) t = Math.max(t, p.keyTime(p.numKeys)); }
    else t = mz_lastKey(p, t);
  }
  return t;
}
function mz_mogrtMake(o) {
  var f = new File(o.ffx);
  if (!f.exists) return mz_err('FILE_MISSING');
  var c = null, bin = null;
  app.beginSuppressDialogs();
  try {
    bin = mz_projectFolder('MIGZZ MOGRT');
    c = app.project.items.addComp(o.name, o.w, o.h, 1, 20, 30);
    c.parentFolder = bin;
    c.bgColor = [0, 0, 0];
    var L;
    if (o.kind === 'shape') {
      L = c.layers.addShape(); L.name = o.name;
      var g = L.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group');
      var r = g.property('ADBE Vectors Group').addProperty('ADBE Vector Shape - Rect');
      r.property('ADBE Vector Rect Size').setValue([o.w * 0.4, o.h * 0.12]);
      g.property('ADBE Vectors Group').addProperty('ADBE Vector Graphic - Fill');
      L.property('ADBE Transform Group').property('ADBE Position').setValue([o.w / 2, o.h / 2]);
      L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0, 0]);
    } else {
      L = c.layers.addText(o.text);
      var td = L.property('ADBE Text Properties').property('ADBE Text Document'), d = td.value;
      d.fontSize = o.size; d.fillColor = [1, 1, 1]; d.justification = ParagraphJustification.CENTER_JUSTIFY;
      try { if (o.font) d.font = o.font; } catch (e0) {}
      td.setValue(d);
      var rc = L.sourceRectAtTime(0, false);
      L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([rc.left + rc.width / 2, rc.top + rc.height / 2]);
      L.property('ADBE Transform Group').property('ADBE Position').setValue([o.w / 2, o.h / 2]);
    }
    c.time = 0;
    var before = mz_lastKey(L, -1), nfx = L.property('ADBE Effect Parade').numProperties;
    L.applyPreset(f);
    var last = mz_lastKey(L, -1);
    var changed = last > before || L.property('ADBE Effect Parade').numProperties > nfx;
    if (!changed && o.kind !== 'shape') {
      var A = L.property('ADBE Text Properties').property('ADBE Text Animators');
      changed = A && A.numProperties > 0;
    }
    if (!changed) { c.remove(); app.endSuppressDialogs(false); return mz_err('MOGRT_NOTHING'); }
    var dur = Math.max(o.minDur, last + 1.2);
    c.duration = dur; L.outPoint = dur;
    var label = o.kind === 'shape' ? '' : 'النص';
    if (label) {
      var st = L.property('ADBE Text Properties').property('ADBE Text Document');
      if (st.canAddToMotionGraphicsTemplate(c)) st.addToMotionGraphicsTemplateAs(c, label);
    }
    try { var op = L.property('ADBE Transform Group').property('ADBE Position'); if (op.canAddToMotionGraphicsTemplate(c) && !op.numKeys) op.addToMotionGraphicsTemplateAs(c, 'المكان'); } catch (e1) {}
    try { var sc = L.property('ADBE Transform Group').property('ADBE Scale'); if (sc.canAddToMotionGraphicsTemplate(c) && !sc.numKeys) sc.addToMotionGraphicsTemplateAs(c, 'الحجم'); } catch (e2) {}
    c.motionGraphicsTemplateName = o.name;
    try { app.project.save(); } catch (e4) {}   // MOGRT export wants a saved project
    var out = new File(o.out);
    if (!out.parent.exists) out.parent.create();
    // the 2nd argument is the FOLDER; the file is named after motionGraphicsTemplateName
    var ok = c.exportAsMotionGraphicsTemplate(true, out.parent.fsName);
    try { c.remove(); } catch (e5) {}
    app.endSuppressDialogs(false);
    if (!ok && !out.exists) return mz_err('MOGRT_FAIL');
    return mz_ok({ dur: dur });
  } catch (e) {
    try { if (c) c.remove(); } catch (e3) {}
    app.endSuppressDialogs(false);
    return mz_err('EXC', String(e) + (e.line ? ' (line ' + e.line + ')' : ''));
  }
}
function mz_aePaths() {
  var v = parseInt(app.version, 10);
  return mz_ok({ app: Folder.appPackage.fsName, docs: Folder.myDocuments.fsName, year: v >= 20 ? 2000 + v : 2000 + v, version: app.version });
}
// MOGRT export needs a saved project. The converter only starts when the project is saved (or empty);
// it adds one temp comp per preset, exports it, removes it, and saves at the end, so the project is left as it was.
function mz_mogrtBegin(tmp) {
  var P = app.project;
  if (!P.file) {
    if (P.numItems > 0) return mz_err('MOGRT_SAVE_FIRST');
    var f = new File(tmp); if (!f.parent.exists) f.parent.create();
    P.save(f);   // an empty untitled project: give it a temp home
  } else if (P.dirty) return mz_err('MOGRT_SAVE_FIRST');
  return mz_ok({});
}
function mz_mogrtEnd() {
  try { mz_mogrtCleanup(); if (app.project.file) app.project.save(); } catch (e) {}
  return mz_ok({});
}
function mz_projectSave() {
  if (!app.project.file) return mz_err('NO_FILE');
  app.project.save();
  return mz_ok({});
}
function mz_mogrtCleanup() {
  var i, it;
  for (i = app.project.numItems; i >= 1; i--) { it = app.project.item(i); if (it instanceof FolderItem && it.name === 'MIGZZ MOGRT' && it.numItems === 0) it.remove(); }
  return mz_ok({});
}

// opens a project file (no dialog); used by the test runner
function mz_openProject(file) {
  var f = new File(file);
  if (!f.exists) return mz_err('FILE_MISSING');
  app.open(f);
  return mz_ok({ name: app.project.file ? app.project.file.name : '' });
}

MZ_FILE_ae_more = 1;
