/*  MIGZZ — After Effects side (ExtendScript, ES3 only: no let/const/arrows).
    Every public function returns a JSON string: {"ok":true,...} or {"ok":false,"code":"...","error":"..."}.
    Every action that changes the project runs inside one undo group, so one Ctrl+Z undoes it. */

var MZ = (typeof MZ !== 'undefined' && MZ) ? MZ : {};

// ───────────── JSON (ExtendScript has no native JSON)
function mz_json(v) {
  var t = typeof v, i, a, k;
  if (v === null || t === 'undefined') return 'null';
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') {
    return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
  }
  if (v instanceof Array) {
    a = [];
    for (i = 0; i < v.length; i++) a.push(mz_json(v[i]));
    return '[' + a.join(',') + ']';
  }
  a = [];
  for (k in v) { if (v.hasOwnProperty(k)) a.push(mz_json(String(k)) + ':' + mz_json(v[k])); }
  return '{' + a.join(',') + '}';
}
function mz_ok(o) { o = o || {}; o.ok = true; return mz_json(o); }
function mz_err(code, extra) { return mz_json({ ok: false, code: code, error: extra ? String(extra) : '' }); }

function mz_comp() {
  var c = (app.project) ? app.project.activeItem : null;
  return (c && (c instanceof CompItem)) ? c : null;
}

// Runs fn inside one undo group; any exception becomes {"ok":false,"code":"EXC"}.
function mz_run(undoName, fn) {
  app.beginUndoGroup('MIGZZ: ' + undoName);
  try {
    return fn();
  } catch (e) {
    return mz_err('EXC', String(e) + (e.line ? ' (line ' + e.line + ')' : ''));
  } finally {
    app.endUndoGroup();
  }
}

function mz_nameTaken(n) {
  var i;
  for (i = 1; i <= app.project.numItems; i++) { if (app.project.item(i).name === n) return true; }
  return false;
}
function mz_uniqueName(base) {
  var n = base, i = 2;
  while (mz_nameTaken(n)) { n = base + ' ' + i; i++; }
  return n;
}
function mz_isAV(L) { return (L instanceof AVLayer) || (L instanceof ShapeLayer) || (L instanceof TextLayer); }
function mz_near(a, b) { return Math.abs(a - b) < 0.01; }

// ───────────── status (polled by the panel)
function mz_status() {
  var c = mz_comp();
  if (!c) return mz_ok({ comp: '', sel: 0 });
  return mz_ok({ comp: c.name, sel: c.selectedLayers.length });
}

// ───────────── precompose the selected layers into one precomp
function mz_precompose() {
  var c = mz_comp(), sel, idx = [], i, name, nc;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  return mz_run('Precompose', function () {
    for (i = 0; i < sel.length; i++) idx.push(sel[i].index);
    idx.sort(function (a, b) { return a - b; });
    name = mz_uniqueName(c.layer(idx[0]).name + ' Comp');
    nc = c.layers.precompose(idx, name, true);
    return mz_ok({ name: nc.name, count: idx.length });
  });
}

// ───────────── each selected layer into its own precomp
function mz_precomposeEach() {
  var c = mz_comp(), sel, idx = [], i, n = 0;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  return mz_run('Precompose each', function () {
    for (i = 0; i < sel.length; i++) idx.push(sel[i].index);
    // highest index first: precomposing one layer keeps its index, so the others never shift
    idx.sort(function (a, b) { return b - a; });
    for (i = 0; i < idx.length; i++) {
      c.layers.precompose([idx[i]], mz_uniqueName(c.layer(idx[i]).name + ' Comp'), true);
      n++;
    }
    return mz_ok({ count: n });
  });
}

// ───────────── decompose: is this precomp layer a "neutral" container?
function mz_whyNotNeutral(L, c) {
  var src = L.source, tr = L.property('ADBE Transform Group'), p, v, i, names;
  if (!(src instanceof CompItem)) return 'NOT_PRECOMP';
  if (src.width !== c.width || src.height !== c.height) return 'SIZE';
  if (!mz_near(L.stretch, 100)) return 'STRETCH';
  if (L.timeRemapEnabled) return 'TIMEREMAP';
  if (L.threeDLayer) return 'THREE_D';
  if (L.property('ADBE Effect Parade').numProperties > 0) return 'EFFECTS';
  if (L.property('ADBE Mask Parade').numProperties > 0) return 'MASKS';
  if (L.blendingMode !== BlendingMode.NORMAL) return 'BLEND';
  names = ['ADBE Anchor Point', 'ADBE Scale', 'ADBE Rotate Z', 'ADBE Opacity'];
  for (i = 0; i < names.length; i++) {
    p = tr.property(names[i]);
    if (p.numKeys > 0 || (p.expressionEnabled && p.expression !== '')) return 'ANIMATED';
  }
  v = tr.property('ADBE Anchor Point').value;
  if (!mz_near(v[0], src.width / 2) || !mz_near(v[1], src.height / 2)) return 'MOVED';
  v = tr.property('ADBE Scale').value;
  if (!mz_near(v[0], 100) || !mz_near(v[1], 100)) return 'MOVED';
  if (!mz_near(tr.property('ADBE Rotate Z').value, 0)) return 'MOVED';
  if (!mz_near(tr.property('ADBE Opacity').value, 100)) return 'MOVED';
  p = tr.property('ADBE Position');
  if (p.dimensionsSeparated) {
    var px = tr.property('ADBE Position_0'), py = tr.property('ADBE Position_1');
    if (px.numKeys > 0 || py.numKeys > 0 || px.expressionEnabled || py.expressionEnabled) return 'ANIMATED';
    if (!mz_near(px.value, c.width / 2) || !mz_near(py.value, c.height / 2)) return 'MOVED';
  } else {
    if (p.numKeys > 0 || (p.expressionEnabled && p.expression !== '')) return 'ANIMATED';
    v = p.value;
    if (!mz_near(v[0], c.width / 2) || !mz_near(v[1], c.height / 2)) return 'MOVED';
  }
  if (L.parent) return 'PARENTED';
  return '';
}

// copyToComp doesn't say where the copy lands: find it as the one layer id that wasn't there before
function mz_copyLayerTo(layer, c) {
  var before = {}, j, L;
  for (j = 1; j <= c.numLayers; j++) before[c.layer(j).id] = true;
  layer.copyToComp(c);
  for (j = 1; j <= c.numLayers; j++) {
    L = c.layer(j);
    if (!before[L.id]) return L;
  }
  return null;
}

// puts layer a directly above layer t, and checks that it really is there
function mz_placeAbove(c, a, t) {
  if (a.index === t.index - 1) return true;
  a.moveBefore(t);
  if (a.index === t.index - 1) return true;
  if (t.index === 1) a.moveToBeginning(); else a.moveAfter(c.layer(t.index - 1));
  return a.index === t.index - 1;
}

function mz_decompOne(c, L) {
  var src = L.source, n = src.numLayers, off = L.startTime, map = {}, i, inner, nl, tm, target;
  for (i = 1; i <= n; i++) {
    inner = src.layer(i);
    nl = mz_copyLayerTo(inner, c);
    if (!nl) throw new Error('copy failed: ' + inner.name);
    try { nl.setParentWithJump(null); } catch (e1) { /* had no parent */ }
    nl.startTime = inner.startTime + off;
    map[i] = nl;
  }
  // stack them back in the precomp's order, bottom layer first, each directly above the one below it
  target = L;
  for (i = n; i >= 1; i--) {
    if (!mz_placeAbove(c, map[i], target)) throw new Error('could not restore layer order: ' + map[i].name);
    target = map[i];
  }
  // parents and track mattes point at layers by index inside the precomp: re-link them to the new copies
  for (i = 1; i <= n; i++) {
    inner = src.layer(i);
    if (inner.parent) map[i].setParentWithJump(map[inner.parent.index]);
    try {
      tm = inner.trackMatteLayer;
      if (tm) map[i].setTrackMatte(map[tm.index], inner.trackMatteType);
    } catch (e2) { /* older AE: track matte is the layer above, order is kept */ }
  }
  // what was outside the precomp layer's trim was never visible: keep it that way
  for (i = n; i >= 1; i--) {
    nl = map[i];
    if (nl.outPoint <= L.inPoint || nl.inPoint >= L.outPoint) { nl.remove(); continue; }
    if (nl.inPoint < L.inPoint) nl.inPoint = L.inPoint;
    if (nl.outPoint > L.outPoint) nl.outPoint = L.outPoint;
  }
  L.remove();
  return n;
}

function mz_decompose() {
  var c = mz_comp(), sel, list = [], i, why, total = 0;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  for (i = 0; i < sel.length; i++) {
    why = mz_whyNotNeutral(sel[i], c);
    if (why) return mz_err('DECOMP_' + why, sel[i].name);
    list.push(sel[i]);
  }
  return mz_run('Decompose', function () {
    for (i = 0; i < list.length; i++) total += mz_decompOne(c, list[i]);
    return mz_ok({ count: total });
  });
}

// ───────────── copy / paste effects (rebuilt property by property: the clipboard is never touched)
function mz_fxSelected(L) {
  var props = L.selectedProperties, out = [], i;
  for (i = 0; i < props.length; i++) {
    if (props[i].parentProperty && props[i].parentProperty.matchName === 'ADBE Effect Parade') out.push(props[i].propertyIndex);
  }
  return out;
}

function mz_copyFx() {
  var c = mz_comp(), sel, L, fx, idx, i;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (sel.length !== 1) return mz_err('ONE_LAYER');
  L = sel[0];
  if (!mz_isAV(L)) return mz_err('NO_FX');
  fx = L.property('ADBE Effect Parade');
  if (fx.numProperties === 0) return mz_err('NO_FX');
  idx = mz_fxSelected(L);
  if (!idx.length) { for (i = 1; i <= fx.numProperties; i++) idx.push(i); }
  MZ.fx = { layer: L, idx: idx };
  return mz_ok({ count: idx.length, name: L.name });
}

function mz_copyValue(sp, dp, shift, stats) {
  var k, t, ni, inT, outT;
  if (sp.propertyValueType === PropertyValueType.NO_VALUE) return;
  if (sp.propertyValueType === PropertyValueType.CUSTOM_VALUE) { stats.skipped++; return; }
  try {
    if (sp.numKeys > 0) {
      for (k = 1; k <= sp.numKeys; k++) {
        t = sp.keyTime(k) + shift;
        ni = dp.addKey(t);
        dp.setValueAtKey(ni, sp.keyValue(k));
      }
      for (k = 1; k <= sp.numKeys; k++) {
        ni = dp.nearestKeyIndex(sp.keyTime(k) + shift);
        inT = sp.keyInInterpolationType(k); outT = sp.keyOutInterpolationType(k);
        if (sp.isInterpolationTypeValid(KeyframeInterpolationType.BEZIER)) {
          try { dp.setTemporalEaseAtKey(ni, sp.keyInTemporalEase(k), sp.keyOutTemporalEase(k)); } catch (e1) {}
        }
        try { dp.setInterpolationTypeAtKey(ni, inT, outT); } catch (e2) {}
        if (sp.isSpatial) {
          try { dp.setSpatialTangentsAtKey(ni, sp.keyInSpatialTangent(k), sp.keyOutSpatialTangent(k)); } catch (e3) {}
        }
      }
    } else {
      dp.setValue(sp.value);
    }
  } catch (e) { stats.skipped++; }
  try {
    if (sp.canSetExpression && sp.expression !== '') { dp.expression = sp.expression; dp.expressionEnabled = sp.expressionEnabled; }
  } catch (e4) { stats.skipped++; }
}

function mz_copyGroup(sg, dg, shift, stats) {
  var i, sp, dp;
  for (i = 1; i <= sg.numProperties; i++) {
    sp = sg.property(i);
    dp = null;
    try { dp = dg.property(i); } catch (e) { dp = null; }
    if (!dp || dp.matchName !== sp.matchName) continue;
    if (sp.propertyType === PropertyType.PROPERTY) mz_copyValue(sp, dp, shift, stats);
    else mz_copyGroup(sp, dp, shift, stats);
  }
}

function mz_pasteFx() {
  var c = mz_comp(), sel, src, i, j, se, de, T, shift, stats = { skipped: 0 }, added = 0;
  if (!c) return mz_err('NO_COMP');
  if (!MZ.fx) return mz_err('NOTHING_COPIED');
  try { src = MZ.fx.layer; src.name; } catch (e) { MZ.fx = null; return mz_err('SOURCE_GONE'); }
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  return mz_run('Paste effects', function () {
    for (j = 0; j < sel.length; j++) {
      T = sel[j];
      if (T === src || !mz_isAV(T)) continue;
      shift = T.inPoint - src.inPoint; // animated effects start with the target layer
      for (i = 0; i < MZ.fx.idx.length; i++) {
        se = src.property('ADBE Effect Parade').property(MZ.fx.idx[i]);
        if (!se) continue;
        de = T.property('ADBE Effect Parade').addProperty(se.matchName);
        de.name = se.name;
        de.enabled = se.enabled;
        mz_copyGroup(se, de, shift, stats);
        added++;
      }
    }
    if (!added) return mz_err('NO_TARGET');
    return mz_ok({ count: added, skipped: stats.skipped });
  });
}

// ───────────── move the anchor point to a corner / edge / center without moving the layer
function mz_shiftProp(p, d) {
  var k, v;
  if (p.numKeys > 0) {
    for (k = 1; k <= p.numKeys; k++) { v = p.keyValue(k); p.setValueAtKey(k, mz_addVec(v, d)); }
  } else {
    p.setValue(mz_addVec(p.value, d));
  }
}
function mz_addVec(v, d) {
  if (typeof v === 'number') return v + d[0];
  var o = [], i;
  for (i = 0; i < v.length; i++) o.push(v[i] + (i < d.length ? d[i] : 0));
  return o;
}
function mz_anchorWhyNot(L) {
  var tr = L.property('ADBE Transform Group'), names = ['ADBE Anchor Point', 'ADBE Scale', 'ADBE Rotate Z'], i, p;
  if ((L instanceof CameraLayer) || (L instanceof LightLayer)) return 'ANCHOR_KIND';
  for (i = 0; i < names.length; i++) {
    p = tr.property(names[i]);
    if (p.numKeys > 0 || (p.expressionEnabled && p.expression !== '')) return 'ANCHOR_ANIMATED';
  }
  if (L.threeDLayer) {
    if (!mz_near(tr.property('ADBE Rotate X').value, 0) || !mz_near(tr.property('ADBE Rotate Y').value, 0)) return 'ANCHOR_3D';
    var o = tr.property('ADBE Orientation').value;
    if (!mz_near(o[0], 0) || !mz_near(o[1], 0) || !mz_near(o[2], 0)) return 'ANCHOR_3D';
  }
  return '';
}
function mz_anchor(where) {
  var c = mz_comp(), sel, i, L, why, done = 0, skipped = 0, lastWhy = '';
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  return mz_run('Move anchor point', function () {
    for (i = 0; i < sel.length; i++) {
      L = sel[i];
      why = mz_anchorWhyNot(L);
      if (why) { skipped++; lastWhy = why; continue; }
      var r = L.sourceRectAtTime(c.time, false);
      var ax = where.indexOf('l') >= 0 ? r.left : (where.indexOf('r') >= 0 ? r.left + r.width : r.left + r.width / 2);
      var ay = where.indexOf('t') >= 0 ? r.top : (where.indexOf('b') >= 0 ? r.top + r.height : r.top + r.height / 2);
      var tr = L.property('ADBE Transform Group');
      var ap = tr.property('ADBE Anchor Point'), a = ap.value;
      var dx = ax - a[0], dy = ay - a[1];
      var s = tr.property('ADBE Scale').value, sx = s[0] / 100, sy = s[1] / 100;
      var rad = tr.property('ADBE Rotate Z').value * Math.PI / 180;
      var px = dx * sx * Math.cos(rad) - dy * sy * Math.sin(rad);
      var py = dx * sx * Math.sin(rad) + dy * sy * Math.cos(rad);
      ap.setValue(a.length > 2 ? [ax, ay, a[2]] : [ax, ay]);
      var pos = tr.property('ADBE Position');
      if (pos.dimensionsSeparated) {
        mz_shiftProp(tr.property('ADBE Position_0'), [px]);
        mz_shiftProp(tr.property('ADBE Position_1'), [py]);
      } else {
        mz_shiftProp(pos, [px, py]);
      }
      done++;
    }
    if (!done) return mz_err(lastWhy || 'NO_SEL');
    return mz_ok({ count: done, skipped: skipped, why: lastWhy });
  });
}

// ───────────── new layers above the selected one
function mz_newLayer(kind, hex) {
  var c = mz_comp(), sel, L, col, r;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  return mz_run('New layer', function () {
    if (kind === 'text') {
      L = c.layers.addText('نص');
      r = L.sourceRectAtTime(c.time, false);
      L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([r.left + r.width / 2, r.top + r.height / 2]);
      L.property('ADBE Transform Group').property('ADBE Position').setValue([c.width / 2, c.height / 2]);
    } else if (kind === 'null') {
      L = c.layers.addNull();
    } else if (kind === 'solid' || kind === 'adjust') {
      col = kind === 'adjust' ? [1, 1, 1] : mz_hex(hex);
      L = c.layers.addSolid(col, kind === 'adjust' ? 'Adjustment Layer' : 'Solid', c.width, c.height, c.pixelAspect);
      if (kind === 'adjust') L.adjustmentLayer = true;
    } else if (kind === 'camera') {
      L = c.layers.addCamera('Camera', [c.width / 2, c.height / 2]);
    } else if (kind === 'light') {
      L = c.layers.addLight('Light', [c.width / 2, c.height / 2]);
    } else {
      return mz_err('BAD_KIND');
    }
    if (sel.length) L.moveBefore(sel[0]);
    var i;
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    return mz_ok({ name: L.name });
  });
}
function mz_hex(h) {
  h = String(h || '#ffffff').replace('#', '');
  if (h.length !== 6) return [1, 1, 1];
  return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255];
}
function mz_uniqueLayerName(c, base) {
  var n = base, k = 2, i, taken;
  do {
    taken = false;
    for (i = 1; i <= c.numLayers; i++) { if (c.layer(i).name === n) { taken = true; break; } }
    if (taken) { n = base + ' ' + k; k++; }
  } while (taken);
  return n;
}

// ───────────── auto captions
var MZ_STYLE_NAME = 'Caption style';

// the selected clip with sound: its file and the part of it that is used
function mz_captionInfo(workOnly) {
  var c = mz_comp(), sel, L, src, a, b;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (sel.length !== 1) return mz_err('CAP_ONE');
  L = sel[0];
  if (!(L instanceof AVLayer) || !(L.source instanceof FootageItem) || !L.source.file) return mz_err('CAP_FOOTAGE');
  src = L.source;
  if (!src.hasAudio) return mz_err('CAP_NO_AUDIO');
  if (L.timeRemapEnabled || !mz_near(L.stretch, 100)) return mz_err('CAP_STRETCH');
  if (!src.file.exists) return mz_err('CAP_MISSING');
  a = Math.max(0, L.inPoint); b = Math.min(c.duration, L.outPoint);   // only the part that is inside the comp
  if (workOnly) {
    a = Math.max(a, c.workAreaStart);
    b = Math.min(b, c.workAreaStart + c.workAreaDuration);
  }
  if (b - a < 0.2) return mz_err('CAP_EMPTY');
  return mz_ok({ path: src.file.fsName, a: a - L.startTime, b: b - L.startTime, start: L.startTime, id: L.id, name: L.name, h: c.height, w: c.width });
}

function mz_findLayerById(c, id) {
  var i;
  for (i = 1; i <= c.numLayers; i++) { if (c.layer(i).id === id) return c.layer(i); }
  return null;
}
function mz_styleLayer(c) {
  var i;
  for (i = 1; i <= c.numLayers; i++) { if (c.layer(i).name === MZ_STYLE_NAME && (c.layer(i) instanceof TextLayer)) return c.layer(i); }
  return null;
}
function mz_setInOut(L, a, b) {
  if (a >= L.outPoint) { L.outPoint = b; L.inPoint = a; } else { L.inPoint = a; L.outPoint = b; }
}
function mz_isArabic(s) { return /[؀-ۿ]/.test(s); }

// default look: bold white with a dark outline, sized for the comp
function mz_defaultCaptionDoc(td, c, text) {
  td.text = text;
  td.resetCharStyle();
  td.resetParagraphStyle();
  td.fontSize = Math.round(Math.min(c.height, c.width * 1.78) * 0.05);
  try { td.font = 'Arial-BoldMT'; } catch (e1) {}
  td.applyFill = true;
  td.fillColor = [1, 1, 1];
  td.applyStroke = true;
  td.strokeColor = [0, 0, 0];
  td.strokeWidth = Math.max(2, Math.round(c.height * 0.004));
  td.strokeOverFill = false;
  td.justification = ParagraphJustification.CENTER_JUSTIFY;
  return td;
}
function mz_setRtl(td, text) {
  if (!mz_isArabic(text)) return td;
  try { td.direction = ParagraphDirection.DIRECTION_RIGHT_TO_LEFT; } catch (e) {}
  return td;
}
function mz_centerAnchor(L, c, y) {
  var r = L.sourceRectAtTime(L.inPoint, false), tr = L.property('ADBE Transform Group');
  tr.property('ADBE Anchor Point').setValue([r.left + r.width / 2, r.top + r.height / 2]);
  tr.property('ADBE Position').setValue([c.width / 2, y]);
}

// a text layer the user styles (font, size, glow...): every caption copies it
function mz_captionStyleNew() {
  var c = mz_comp(), L, p, td, i;
  if (!c) return mz_err('NO_COMP');
  L = mz_styleLayer(c);
  return mz_run('Caption style', function () {
    if (!L) {
      L = c.layers.addText('اكتب هنا');
      L.name = MZ_STYLE_NAME;
      p = L.property('ADBE Text Properties').property('ADBE Text Document');
      td = mz_setRtl(mz_defaultCaptionDoc(p.value, c, 'ستايل الكابشن'), 'س');
      p.setValue(td);
      mz_centerAnchor(L, c, c.height * 0.68);
    }
    L.enabled = true;
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    return mz_ok({ name: L.name });
  });
}

// items: [{t, s, e}] times in the clip's own time (seconds); opts: {id, start, pos}
function mz_captionsApply(items, opts) {
  var c = mz_comp(), srcL, style, i, it, nl, p, td, target, y, n = 0;
  if (!c) return mz_err('NO_COMP');
  if (!items || !items.length) return mz_err('CAP_NOTHING');
  srcL = mz_findLayerById(c, opts.id);
  if (!srcL) return mz_err('CAP_GONE');
  style = mz_styleLayer(c);
  y = opts.pos === 'center' ? c.height / 2 : c.height * 0.68;
  return mz_run('Auto captions', function () {
    target = srcL;
    for (i = 0; i < items.length; i++) {
      it = items[i];
      if (style) {
        nl = style.duplicate();
        nl.enabled = true;
        p = nl.property('ADBE Text Properties').property('ADBE Text Document');
        td = p.value;
        td.text = it.t;
        p.setValue(mz_setRtl(td, it.t));
      } else {
        nl = c.layers.addText(it.t);
        p = nl.property('ADBE Text Properties').property('ADBE Text Document');
        p.setValue(mz_setRtl(mz_defaultCaptionDoc(p.value, c, it.t), it.t));
      }
      nl.name = 'Caption ' + (i + 1);
      // the layer starts with its caption, so animations made on the style play on every caption
      nl.startTime = opts.start + it.s;
      mz_setInOut(nl, opts.start + it.s, opts.start + it.e);
      if (!style) mz_centerAnchor(nl, c, y);
      mz_placeAbove(c, nl, target);
      target = nl;
      n++;
    }
    if (style) { style.enabled = false; style.moveToBeginning(); }
    return mz_ok({ count: n });
  });
}

// ───────────── beats: markers, and layers that follow them (times arrive in comp seconds)
var MZ_BEAT_CUE = 'migzz-beat';

function mz_isBeatMarker(mp, k) {
  try { return mp.keyValue(k).cuePointName === MZ_BEAT_CUE; } catch (e) { return false; }
}
function mz_clearBeatMarkers(mp) {
  var k, n = 0;
  for (k = mp.numKeys; k >= 1; k--) { if (mz_isBeatMarker(mp, k)) { mp.removeKey(k); n++; } }
  return n;
}
// opts: {id, onComp, replace, number}
function mz_beatMarkers(times, opts) {
  var c = mz_comp(), L, mp, i, mv;
  if (!c) return mz_err('NO_COMP');
  if (!times || !times.length) return mz_err('BEAT_NONE');
  if (opts.onComp) mp = c.markerProperty;
  else {
    L = mz_findLayerById(c, opts.id);
    if (!L) return mz_err('CAP_GONE');
    mp = L.property('ADBE Marker');
  }
  return mz_run('Beat markers', function () {
    if (opts.replace) mz_clearBeatMarkers(mp);
    for (i = 0; i < times.length; i++) {
      mv = new MarkerValue(opts.number ? String(i + 1) : '');
      mv.cuePointName = MZ_BEAT_CUE;
      mp.setValueAtTime(times[i], mv);
    }
    return mz_ok({ count: times.length });
  });
}
function mz_beatClear(opts) {
  var c = mz_comp(), L, n = 0;
  if (!c) return mz_err('NO_COMP');
  return mz_run('Clear beat markers', function () {
    n += mz_clearBeatMarkers(c.markerProperty);
    L = opts && opts.id ? mz_findLayerById(c, opts.id) : null;
    if (L) n += mz_clearBeatMarkers(L.property('ADBE Marker'));
    return mz_ok({ count: n });
  });
}
function mz_nearest(times, t) {
  var i, best = times[0];
  for (i = 1; i < times.length; i++) { if (Math.abs(times[i] - t) < Math.abs(best - t)) best = times[i]; }
  return best;
}
// the selected layers except the music itself, earliest first
function mz_beatTargets(c, excludeId) {
  var sel = c.selectedLayers, out = [], i;
  for (i = 0; i < sel.length; i++) { if (sel[i].id !== excludeId) out.push(sel[i]); }
  out.sort(function (a, b) { return a.inPoint - b.inPoint || a.index - b.index; });
  return out;
}
// each selected layer starts on the nearest beat
function mz_beatSnap(times, excludeId) {
  var c = mz_comp(), list, i, d;
  if (!c) return mz_err('NO_COMP');
  if (!times || !times.length) return mz_err('BEAT_NONE');
  list = mz_beatTargets(c, excludeId);
  if (!list.length) return mz_err('BEAT_SEL');
  return mz_run('Snap to beats', function () {
    for (i = 0; i < list.length; i++) {
      d = mz_nearest(times, list[i].inPoint) - list[i].inPoint;
      list[i].startTime += d;
    }
    return mz_ok({ count: list.length });
  });
}
// the selected layers one after another, each from one beat to the next
function mz_beatSequence(times, excludeId) {
  var c = mz_comp(), list, i, k = 0, L, a, b, d;
  if (!c) return mz_err('NO_COMP');
  if (!times || times.length < 2) return mz_err('BEAT_NONE');
  list = mz_beatTargets(c, excludeId);
  if (!list.length) return mz_err('BEAT_SEL');
  while (k < times.length - 1 && times[k] < list[0].inPoint - 0.001) k++;
  return mz_run('Sequence on beats', function () {
    var placed = 0;
    for (i = 0; i < list.length && k < times.length - 1; i++, k++) {
      L = list[i]; a = times[k]; b = times[k + 1];
      d = a - L.inPoint;
      L.startTime += d;
      // a clip can't get longer than its footage: then it keeps its own end
      try { L.outPoint = b; } catch (e) { /* shorter than the gap */ }
      placed++;
    }
    return mz_ok({ count: placed });
  });
}
// the selected clip is cut into pieces at every beat inside it
function mz_beatCut(times, excludeId) {
  var c = mz_comp(), list, L, cuts = [], i, piece, a, b, n = 0;
  if (!c) return mz_err('NO_COMP');
  if (!times || !times.length) return mz_err('BEAT_NONE');
  list = mz_beatTargets(c, excludeId);
  if (list.length !== 1) return mz_err('BEAT_ONE');
  L = list[0];
  for (i = 0; i < times.length; i++) { if (times[i] > L.inPoint + 0.02 && times[i] < L.outPoint - 0.02) cuts.push(times[i]); }
  if (!cuts.length) return mz_err('BEAT_NONE_IN');
  return mz_run('Cut on beats', function () {
    var bounds = [L.inPoint].concat(cuts).concat([L.outPoint]);
    // pieces 2..n are duplicates; the original keeps the first piece
    for (i = bounds.length - 2; i >= 1; i--) {
      piece = L.duplicate();
      a = bounds[i]; b = bounds[i + 1];
      mz_setInOut(piece, a, b);
      n++;
    }
    L.outPoint = bounds[1];
    return mz_ok({ count: n + 1 });
  });
}

// ───────────── video clip info (for tools that render a new clip) and importing the result
function mz_videoInfo(workOnly) {
  var c = mz_comp(), sel, L, src, a, b;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (sel.length !== 1) return mz_err('VID_ONE');
  L = sel[0];
  if (!(L instanceof AVLayer) || !(L.source instanceof FootageItem) || !L.source.file || !L.source.hasVideo || L.source.mainSource.isStill) return mz_err('VID_FOOTAGE');
  src = L.source;
  if (L.timeRemapEnabled || !mz_near(L.stretch, 100)) return mz_err('CAP_STRETCH');
  if (!src.file.exists) return mz_err('CAP_MISSING');
  a = L.inPoint; b = L.outPoint;
  if (workOnly) {
    a = Math.max(a, c.workAreaStart);
    b = Math.min(b, c.workAreaStart + c.workAreaDuration);
  }
  if (b - a < 0.1) return mz_err('CAP_EMPTY');
  return mz_ok({ path: src.file.fsName, a: a - L.startTime, b: b - L.startTime, start: L.startTime, id: L.id, name: L.name,
    fps: src.frameRate, w: src.width, h: src.height, compFps: c.frameRate });
}

function mz_projectFolder(name) {
  var i, it;
  for (i = 1; i <= app.project.numItems; i++) {
    it = app.project.item(i);
    if ((it instanceof FolderItem) && it.name === name && it.parentFolder === app.project.rootFolder) return it;
  }
  return app.project.items.addFolder(name);
}

// imports a rendered file and puts it right above the clip it came from, starting at compTime
function mz_importAbove(file, id, compTime, name) {
  var c = mz_comp(), L, it, nl, f = new File(file);
  if (!c) return mz_err('NO_COMP');
  if (!f.exists) return mz_err('FILE_MISSING');
  L = mz_findLayerById(c, id);
  return mz_run('Import result', function () {
    it = app.project.importFile(new ImportOptions(f));
    it.parentFolder = mz_projectFolder('MIGZZ');
    nl = c.layers.add(it);
    nl.startTime = compTime;
    if (L) mz_placeAbove(c, nl, L);
    nl.name = name;
    var i;
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    nl.selected = true;
    return mz_ok({ name: nl.name, dur: it.duration });
  });
}

// ───────────── social media safe-zone guides (guide layer: shows in the viewer, never in renders)
var MZ_GUIDE_PREFIX = 'MIGZZ guide';
// unsafe bands as fractions of the frame: top, bottom, right, left (approximate, phone UI overlays)
var MZ_ZONES = {
  reels: { name: 'Reels', top: 0.13, bottom: 0.22, right: 0.11, left: 0.03 },
  tiktok: { name: 'TikTok', top: 0.08, bottom: 0.25, right: 0.13, left: 0.05 },
  shorts: { name: 'Shorts', top: 0.08, bottom: 0.25, right: 0.12, left: 0.03 }
};
function mz_findGuide(c) {
  var i;
  for (i = 1; i <= c.numLayers; i++) { if (c.layer(i).name.indexOf(MZ_GUIDE_PREFIX) === 0) return c.layer(i); }
  return null;
}
function mz_addRect(contents, cx, cy, w, h, color, opacity) {
  var g = contents.addProperty('ADBE Vector Group');
  var gc = g.property('ADBE Vectors Group');
  var r = gc.addProperty('ADBE Vector Shape - Rect');
  r.property('ADBE Vector Rect Size').setValue([w, h]);
  r.property('ADBE Vector Rect Position').setValue([cx, cy]);
  var f = gc.addProperty('ADBE Vector Graphic - Fill');
  f.property('ADBE Vector Fill Color').setValue(color);
  f.property('ADBE Vector Fill Opacity').setValue(opacity);
}
function mz_safeGuide(platform) {
  var c = mz_comp(), old, Z, L, W, H, ct, t, b, r, l;
  if (!c) return mz_err('NO_COMP');
  old = mz_findGuide(c);
  Z = MZ_ZONES[platform];
  return mz_run('Safe-zone guide', function () {
    var was = old ? old.name : '';
    if (old) { old.locked = false; old.remove(); }
    if (!Z || was === MZ_GUIDE_PREFIX + ' · ' + Z.name) return mz_ok({ removed: true });
    W = c.width; H = c.height;
    L = c.layers.addShape();
    L.name = MZ_GUIDE_PREFIX + ' · ' + Z.name;
    // the shape layer sits at the comp center with its anchor at 0,0: rectangles are placed relative to the center
    L.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0, 0]);
    L.property('ADBE Transform Group').property('ADBE Position').setValue([W / 2, H / 2]);
    ct = L.property('ADBE Root Vectors Group');
    t = H * Z.top; b = H * Z.bottom; r = W * Z.right; l = W * Z.left;
    var red = [1, 0.25, 0.2];
    mz_addRect(ct, 0, -H / 2 + t / 2, W, t, red, 35);
    mz_addRect(ct, 0, H / 2 - b / 2, W, b, red, 35);
    mz_addRect(ct, W / 2 - r / 2, (t - b) / 2, r, H - t - b, red, 25);
    mz_addRect(ct, -W / 2 + l / 2, (t - b) / 2, l, H - t - b, red, 25);
    L.guideLayer = true;
    L.label = 1;
    L.locked = true;
    return mz_ok({ name: L.name });
  });
}

// ───────────── an image file (from the clipboard) into the comp, fitted inside the frame
function mz_addImage(file) {
  var c = mz_comp(), f = new File(file), it, L, s, sel;
  if (!c) return mz_err('NO_COMP');
  if (!f.exists) return mz_err('FILE_MISSING');
  sel = c.selectedLayers;
  return mz_run('Paste image', function () {
    it = app.project.importFile(new ImportOptions(f));
    it.parentFolder = mz_projectFolder('MIGZZ');
    L = c.layers.add(it);
    if (sel.length) mz_placeAbove(c, L, sel[0]);
    s = Math.min(1, c.width / it.width, c.height / it.height) * 100;
    L.property('ADBE Transform Group').property('ADBE Scale').setValue([s, s]);
    L.startTime = c.time;
    var i;
    for (i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
    L.selected = true;
    return mz_ok({ name: L.name });
  });
}

// ───────────── tidy the project panel: loose items go into folders by kind
function mz_kindOf(it) {
  if (it instanceof CompItem) return 'Comps';
  if (it instanceof FootageItem) {
    if (it.mainSource instanceof SolidSource) return '';
    if (it.mainSource instanceof PlaceholderSource) return '';
    if (it.mainSource.isStill) return 'Images';
    if (it.hasVideo) return 'Video';
    if (it.hasAudio) return 'Audio';
    return 'Other';
  }
  return '';
}
function mz_organizePlan(deep) {
  var plan = { Comps: 0, Video: 0, Images: 0, Audio: 0, Other: 0 }, i, it, k, n = 0;
  for (i = 1; i <= app.project.numItems; i++) {
    it = app.project.item(i);
    if (it instanceof FolderItem) continue;
    if (!deep && it.parentFolder !== app.project.rootFolder) continue;
    k = mz_kindOf(it);
    if (!k || (it.parentFolder.name === k && it.parentFolder.parentFolder === app.project.rootFolder)) continue;
    plan[k]++; n++;
  }
  return { plan: plan, n: n };
}
function mz_organizeInfo(deep) { var p = mz_organizePlan(deep); return mz_ok({ plan: p.plan, n: p.n }); }
function mz_organize(deep) {
  if (!app.project) return mz_err('NO_PROJECT');
  return mz_run('Organize project', function () {
    var list = [], i, it, k, n = 0, folders = {};
    for (i = 1; i <= app.project.numItems; i++) {
      it = app.project.item(i);
      if (it instanceof FolderItem) continue;
      if (!deep && it.parentFolder !== app.project.rootFolder) continue;
      k = mz_kindOf(it);
      if (!k || (it.parentFolder.name === k && it.parentFolder.parentFolder === app.project.rootFolder)) continue;
      list.push([it, k]);
    }
    for (i = 0; i < list.length; i++) {
      k = list[i][1];
      if (!folders[k]) folders[k] = mz_projectFolder(k);
      list[i][0].parentFolder = folders[k];
      n++;
    }
    return mz_ok({ count: n });
  });
}

// ───────────── copy the look and motion of a layer onto others
function mz_copyStyle() {
  var c = mz_comp(), sel;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (sel.length !== 1) return mz_err('ONE_LAYER');
  if (!mz_isAV(sel[0])) return mz_err('STYLE_KIND');
  MZ.style = { layer: sel[0] };
  return mz_ok({ name: sel[0].name });
}
// position moves relative to where each target already is; everything else is copied as it is
function mz_pasteStyle(opts) {
  var c = mz_comp(), sel, src, j, T, shift, stats = { skipped: 0 }, n = 0, i, se, de;
  if (!c) return mz_err('NO_COMP');
  if (!MZ.style) return mz_err('NOTHING_COPIED');
  try { src = MZ.style.layer; src.name; } catch (e) { MZ.style = null; return mz_err('SOURCE_GONE'); }
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  return mz_run('Paste style', function () {
    var sTr = src.property('ADBE Transform Group'), names = ['ADBE Scale', 'ADBE Rotate Z', 'ADBE Opacity'];
    for (j = 0; j < sel.length; j++) {
      T = sel[j];
      if (T === src || !mz_isAV(T)) continue;
      shift = T.inPoint - src.inPoint;
      var tTr = T.property('ADBE Transform Group');
      if (opts.motion) {
        for (i = 0; i < names.length; i++) {
          var dp = tTr.property(names[i]);
          while (dp.numKeys > 0) dp.removeKey(1);
          mz_copyValue(sTr.property(names[i]), dp, shift, stats);
        }
        // position: the source's movement, added to the target's own spot
        var sp = sTr.property('ADBE Position'), tp = tTr.property('ADBE Position');
        if (!sp.dimensionsSeparated && !tp.dimensionsSeparated && sp.numKeys > 0) {
          var base = tp.valueAtTime(T.inPoint, false), ref = sp.valueAtTime(src.inPoint, false), k, ni, v;
          while (tp.numKeys > 0) tp.removeKey(1);
          for (k = 1; k <= sp.numKeys; k++) {
            v = sp.keyValue(k);
            ni = tp.addKey(sp.keyTime(k) + shift);
            tp.setValueAtKey(ni, mz_addVec(base, [v[0] - ref[0], v[1] - ref[1], (v.length > 2 ? v[2] - ref[2] : 0)]));
          }
          for (k = 1; k <= sp.numKeys; k++) {
            ni = tp.nearestKeyIndex(sp.keyTime(k) + shift);
            try { tp.setTemporalEaseAtKey(ni, sp.keyInTemporalEase(k), sp.keyOutTemporalEase(k)); } catch (e1) {}
            try { tp.setInterpolationTypeAtKey(ni, sp.keyInInterpolationType(k), sp.keyOutInterpolationType(k)); } catch (e2) {}
            try { tp.setSpatialTangentsAtKey(ni, sp.keyInSpatialTangent(k), sp.keyOutSpatialTangent(k)); } catch (e3) {}
          }
        }
      }
      if (opts.fx) {
        var sfx = src.property('ADBE Effect Parade');
        for (i = 1; i <= sfx.numProperties; i++) {
          se = sfx.property(i);
          de = T.property('ADBE Effect Parade').addProperty(se.matchName);
          de.name = se.name; de.enabled = se.enabled;
          mz_copyGroup(se, de, shift, stats);
        }
      }
      if (opts.blend) {
        try { T.blendingMode = src.blendingMode; } catch (e4) {}
        try { T.motionBlur = src.motionBlur; } catch (e5) {}
      }
      n++;
    }
    if (!n) return mz_err('NO_TARGET');
    return mz_ok({ count: n, skipped: stats.skipped });
  });
}

// ───────────── background render: what aerender needs to render the active comp
function mz_renderInfo(workOnly) {
  var c = mz_comp(), f;
  if (!c) return mz_err('NO_COMP');
  if (!app.project.file) return mz_err('RENDER_UNSAVED');
  app.project.save();
  f = app.project.file;
  var a = workOnly ? c.workAreaStart : 0, d = workOnly ? c.workAreaDuration : c.duration, fr = c.frameRate;
  var aer = new File(Folder.appPackage.fsName + '/aerender.exe');
  if (!aer.exists) return mz_err('RENDER_NO_AER');
  var ds = Math.round(c.displayStartTime * fr);
  return mz_ok({ project: f.fsName, comp: c.name, aerender: aer.fsName, start: ds + Math.round(a * fr), end: ds + Math.round((a + d) * fr) - 1,
    frames: Math.round(d * fr), fps: fr, unique: mz_compNameUnique(c.name) });
}
function mz_compNameUnique(n) {
  var i, k = 0;
  for (i = 1; i <= app.project.numItems; i++) { if ((app.project.item(i) instanceof CompItem) && app.project.item(i).name === n) k++; }
  return k === 1;
}

// ───────────── independent copy: a precomp gets its own copy of the source comp
function mz_duplicateIndependent() {
  var c = mz_comp(), sel, i, L, d, nc, n = 0;
  if (!c) return mz_err('NO_COMP');
  sel = c.selectedLayers;
  if (!sel.length) return mz_err('NO_SEL');
  return mz_run('Independent duplicate', function () {
    for (i = 0; i < sel.length; i++) {
      L = sel[i];
      d = L.duplicate();
      if ((L instanceof AVLayer) && (L.source instanceof CompItem)) {
        nc = L.source.duplicate();
        nc.name = mz_uniqueName(L.source.name + ' copy');
        d.replaceSource(nc, false);
      }
      n++;
    }
    return mz_ok({ count: n });
  });
}

MZ_FILE_ae = 1;
