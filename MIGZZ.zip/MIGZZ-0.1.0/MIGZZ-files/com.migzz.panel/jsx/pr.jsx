/*  MIGZZ — Premiere Pro side (ExtendScript, ES3 only).
    Every public function returns a JSON string: {"ok":true,...} or {"ok":false,"code":"...","error":"..."}. */

function mz_json(v) {
  var t = typeof v, i, a, k;
  if (v === null || t === 'undefined') return 'null';
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') {
    return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
  }
  if (v instanceof Array) {
    a = [];
    for (i = 0; i < v.length; i++) a.push(mz_json(v[i]));
    return '[' + a.join(',') + ']';
  }
  a = [];
  for (k in v) { if (v.hasOwnProperty(k)) a.push(mz_json(String(k)) + ':' + mz_json(v[k])); }
  return '{' + a.join(',') + '}';
}
function mz_ok(o) { o = o || {}; o.ok = true; return mz_json(o); }
function mz_err(code, extra) { return mz_json({ ok: false, code: code, error: extra ? String(extra) : '' }); }
function mz_try(fn) { try { return fn(); } catch (e) { return mz_err('EXC', String(e) + (e.line ? ' (line ' + e.line + ')' : '')); } }

var MZ_TPS = 254016000000;     // Premiere ticks per second
function mz_seq() { return (app.project) ? app.project.activeSequence : null; }
function mz_secs(t) { return Number(t.ticks) / MZ_TPS; }
function mz_time(s) { var t = new Time(); t.seconds = s; return t; }
function mz_fps(seq) { return MZ_TPS / Number(seq.timebase); }

function mz_status() {
  var s = mz_seq(), n = 0;
  if (s) { try { n = s.getSelection().length; } catch (e) {} }
  return mz_ok({ comp: s ? s.name : '', sel: n });
}

// ───────────── bins and project items
function mz_bin(name) {
  var r = app.project.rootItem, i;
  for (i = 0; i < r.children.numItems; i++) if (r.children[i].type === ProjectItemType.BIN && r.children[i].name === name) return r.children[i];
  return r.createBin(name);
}
function mz_samePath(a, b) { return String(a).replace(/\\/g, '/').toLowerCase() === String(b).replace(/\\/g, '/').toLowerCase(); }
function mz_findItemByPath(bin, file) {
  var i, it;
  for (i = bin.children.numItems - 1; i >= 0; i--) {
    it = bin.children[i];
    if (it.type === ProjectItemType.BIN) { var r = mz_findItemByPath(it, file); if (r) return r; }
    else { try { if (mz_samePath(it.getMediaPath(), file)) return it; } catch (e) {} }
  }
  return null;
}
function mz_import(file) {
  var bin = mz_bin('MIGZZ');
  if (!new File(file).exists) return null;
  app.project.importFiles([file], true, bin, false);
  return mz_findItemByPath(bin, file);
}

// ───────────── the selected clip (video first) with its track
function mz_where(seq, item) {
  var g, i, j, tracks;
  for (g = 0; g < 2; g++) {
    tracks = g ? seq.audioTracks : seq.videoTracks;
    for (i = 0; i < tracks.numTracks; i++) for (j = 0; j < tracks[i].clips.numItems; j++) if (tracks[i].clips[j].nodeId === item.nodeId) return { video: !g, track: i };
  }
  return null;
}
function mz_selClip(seq) {
  var sel = seq.getSelection(), i, v = null, a = null;
  for (i = 0; i < sel.length; i++) {
    if (!sel[i].projectItem) continue;
    if (sel[i].mediaType === 'Video' && !v) v = sel[i];
    if (sel[i].mediaType === 'Audio' && !a) a = sel[i];
  }
  return v || a;
}
// same shape as the After Effects info: path, a/b (seconds inside the source), start (timeline time of source second 0)
function mz_clipInfo(workOnly, needVideo) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var it = mz_selClip(seq); if (!it) return mz_err(needVideo ? 'VID_ONE' : 'CAP_ONE');
    if (needVideo && it.mediaType !== 'Video') return mz_err('VID_FOOTAGE');
    var sp = 1;
    try { sp = it.getSpeed(); if (it.isSpeedReversed()) sp = -1; } catch (e0) {}
    if (Math.abs(sp - 1) > 0.001) return mz_err('CAP_STRETCH');
    var path = it.projectItem.getMediaPath();
    if (!path || !new File(path).exists) return mz_err('CAP_MISSING');
    var s0 = mz_secs(it.start), e0 = mz_secs(it.end), inP = mz_secs(it.inPoint);
    var a = s0, b = e0;
    if (workOnly) {
      var io = seq.getInPointAsTime ? mz_secs(seq.getInPointAsTime()) : Number(seq.getInPoint());
      var oo = seq.getOutPointAsTime ? mz_secs(seq.getOutPointAsTime()) : Number(seq.getOutPoint());
      if (oo > io) { a = Math.max(a, io); b = Math.min(b, oo); }
    }
    if (b - a < 0.1) return mz_err('CAP_EMPTY');
    var w = mz_where(seq, it), fr = 0, W = 0, H = 0;
    try { fr = 1 / it.projectItem.getFootageInterpretation().frameRate; } catch (e1) {}
    try { var md = it.projectItem.getProjectMetadata(); } catch (e2) {}
    return mz_ok({ path: path, a: inP + (a - s0), b: inP + (b - s0), start: s0 - inP, id: it.nodeId, name: it.name,
      video: it.mediaType === 'Video', track: w ? w.track : 0, fps: fr ? 1 / fr : mz_fps(seq), seqFps: mz_fps(seq),
      w: seq.frameSizeHorizontal, h: seq.frameSizeVertical });
  });
}
function mz_captionInfo(workOnly) { return mz_clipInfo(workOnly, false); }
function mz_videoInfo(workOnly) { return mz_clipInfo(workOnly, true); }

// a track that is empty between t0 and t1 (video: above `from`; audio: from `from` up)
function mz_freeTrack(tracks, from, t0, t1) {
  var i, j, c, ok;
  for (i = from; i < tracks.numTracks; i++) {
    ok = true;
    for (j = 0; j < tracks[i].clips.numItems; j++) {
      c = tracks[i].clips[j];
      if (mz_secs(c.start) < t1 - 0.001 && mz_secs(c.end) > t0 + 0.001) { ok = false; break; }
    }
    if (ok) return tracks[i];
  }
  // none free: add one on top (QE), so results never fail just because the timeline is full
  try {
    var isVideo = tracks.numTracks && String(tracks[0].mediaType) === 'Video';
    var isAudio = tracks.numTracks && String(tracks[0].mediaType) === 'Audio';
    if (!isVideo && !isAudio) return null;
    app.enableQE();
    var q = qe.project.getActiveSequence(), n0 = tracks.numTracks;
    if (isVideo) q.addTracks(1, n0, 0); else q.addTracks(0, 0, 1, 1, n0);
    var s = mz_seq(), T = isVideo ? s.videoTracks : s.audioTracks;
    if (T.numTracks > n0) return T[T.numTracks - 1];
  } catch (e) {}
  return null;
}
function mz_place(item, t, videoFrom, audioFrom) {
  var seq = mz_seq(), dur = 1, out = mz_secs(item.getOutPoint()), inn = mz_secs(item.getInPoint());
  if (out > inn) dur = out - inn;
  var isAudioOnly = false;
  try { isAudioOnly = !item.getFootageInterpretation().frameRate && /\.(wav|mp3|m4a|aac|aif+|flac|ogg)$/i.test(item.getMediaPath()); } catch (e) {}
  if (/\.(wav|mp3|m4a|aac|aif+|flac|ogg)$/i.test(item.getMediaPath())) isAudioOnly = true;
  var tr = isAudioOnly ? mz_freeTrack(seq.audioTracks, audioFrom || 0, t, t + dur) : mz_freeTrack(seq.videoTracks, videoFrom || 0, t, t + dur);
  if (!tr) return false;
  tr.overwriteClip(item, t);
  return true;
}

// ───────────── import a file at the playhead (link import, pasted image)
function mz_importMedia(file, name) {
  return mz_try(function () {
    var seq = mz_seq(), it = mz_import(file);
    if (!it) return mz_err('FILE_MISSING');
    if (name) { try { it.name = name; } catch (e0) {} }
    if (!seq) return mz_ok({ name: it.name, comp: false });
    var t = mz_secs(seq.getPlayerPosition());
    if (!mz_place(it, t, 0, 0)) return mz_err('NO_TRACK');
    return mz_ok({ name: it.name, comp: true });
  });
}
function mz_addImage(file) { return mz_importMedia(file); }

// a rendered result goes on a free track above the source clip, starting at the timeline time of its first frame
function mz_importAbove(file, id, t, name) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var it = mz_import(file); if (!it) return mz_err('FILE_MISSING');
    if (name) { try { it.name = name; } catch (e) {} }
    var from = 1, i, j;
    for (i = 0; i < seq.videoTracks.numTracks; i++) for (j = 0; j < seq.videoTracks[i].clips.numItems; j++) if (seq.videoTracks[i].clips[j].nodeId === id) from = i + 1;
    if (!mz_place(it, t, from, 0)) return mz_err('NO_TRACK');
    return mz_ok({ name: it.name });
  });
}
function mz_maskApply(file, id, t) { return mz_importAbove(file, id, t, 'MIGZZ قص الشخص'); }

// speech / music split: two audio tracks, the clip's own sound off
function mz_voiceApply(voice, music, id, t) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var v = mz_import(voice), m = mz_import(music);
    if (!v || !m) return mz_err('FILE_MISSING');
    v.name = 'MIGZZ صوت الكلام'; m.name = 'MIGZZ المزيكا والدوشة';
    if (!mz_place(v, t, 0, 0) || !mz_place(m, t, 0, 0)) return mz_err('NO_TRACK');
    var g, i, j, c, links;
    for (g = 0; g < 2; g++) {
      var tracks = g ? seq.audioTracks : seq.videoTracks;
      for (i = 0; i < tracks.numTracks; i++) for (j = 0; j < tracks[i].clips.numItems; j++) {
        c = tracks[i].clips[j];
        if (c.nodeId !== id) continue;
        if (g) { try { c.disabled = true; } catch (e0) {} }
        else { try { links = c.getLinkedItems(); var k; for (k = 0; k < links.numItems; k++) if (links[k].mediaType === 'Audio') links[k].disabled = true; } catch (e1) {} }
      }
    }
    return mz_ok({ count: 2 });
  });
}

// ───────────── captions: an SRT (timeline times) becomes a caption track
function mz_captionsSrt(file) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var it = mz_import(file); if (!it) return mz_err('FILE_MISSING');
    if (!seq.createCaptionTrack) return mz_err('PR_OLD');
    seq.createCaptionTrack(it, 0, Sequence.CAPTION_FORMAT_SUBTITLE);
    return mz_ok({ name: it.name });
  });
}

// captions from the speech engine: written as SRT (timeline times), then a caption track
function mz_srtTime(t) {
  var ms = Math.max(0, Math.round(t * 1000)), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60;
  function p(x, l) { x = String(x); while (x.length < l) x = '0' + x; return x; }
  return p(h, 2) + ':' + p(m, 2) + ':' + p(s, 2) + ',' + p(ms % 1000, 3);
}
function mz_captionsApply(caps, opts) {
  return mz_try(function () {
    var i, txt = '';
    for (i = 0; i < caps.length; i++) txt += (i + 1) + '\r\n' + mz_srtTime(caps[i].s + opts.start) + ' --> ' + mz_srtTime(caps[i].e + opts.start) + '\r\n' + caps[i].t + '\r\n\r\n';
    var dir = new Folder(Folder.userData.fsName + '/MIGZZ/captions');
    if (!dir.exists) dir.create();
    var f = new File(dir.fsName + '/captions ' + (new Date().getTime() % 1000000) + '.srt');
    f.encoding = 'UTF-8';
    f.open('w'); f.write('﻿' + txt); f.close();
    var r = eval('(' + mz_captionsSrt(f.fsName) + ')');
    if (!r || !r.ok) return mz_json(r || { ok: false, code: 'EXC' });
    return mz_ok({ count: caps.length });
  });
}

// cut the selected clip (and its linked audio) on the beats
function mz_beatCut(times) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var it = mz_selClip(seq); if (!it) return mz_err('BEAT_ONE');
    var s0 = mz_secs(it.start), e0 = mz_secs(it.end), fps = mz_fps(seq), fr = seq.getSettings().videoFrameRate;
    var tracks = [], w = mz_where(seq, it), i, k;
    if (w) tracks.push(w);
    try { var L = it.getLinkedItems(); for (i = 0; i < L.numItems; i++) { var x = mz_where(seq, L[i]); if (x) tracks.push(x); } } catch (e) {}
    app.enableQE();
    var qs = qe.project.getActiveSequence(), n = 0;
    for (i = 0; i < times.length; i++) {
      var t = Math.round(times[i] * fps) / fps;
      if (t <= s0 + 1 / fps || t >= e0 - 1 / fps) continue;
      var tc = mz_time(t).getFormatted(fr, seq.videoDisplayFormat);
      for (k = 0; k < tracks.length; k++) (tracks[k].video ? qs.getVideoTrackAt(tracks[k].track) : qs.getAudioTrackAt(tracks[k].track)).razor(tc);
      n++;
    }
    if (!n) return mz_err('BEAT_NONE_IN');
    return mz_ok({ count: n + 1 });
  });
}

// ───────────── beat markers on the sequence
var MZ_BEAT = 'MIGZZ beat';
function mz_beatClear() {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var m = seq.markers.getFirstMarker(), del = [], i;
    while (m) { if (m.name === MZ_BEAT || /^MIGZZ beat/.test(m.name)) del.push(m); m = seq.markers.getNextMarker(m); }
    for (i = 0; i < del.length; i++) seq.markers.deleteMarker(del[i]);
    return mz_ok({ count: del.length });
  });
}
function mz_beatMarkers(times, opts) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    if (opts.replace) mz_beatClear();
    var i, m;
    for (i = 0; i < times.length; i++) {
      m = seq.markers.createMarker(times[i]);
      m.name = opts.number ? MZ_BEAT + ' ' + (i + 1) : MZ_BEAT;
      try { m.setColorByIndex(3); } catch (e) {}
    }
    return mz_ok({ count: times.length });
  });
}

// ───────────── silence cut: a new sequence with only the parts that have speech
// keep: [[a, b], ...] in source seconds of the selected clip
function mz_silenceCut(keep, id) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var it = mz_selClip(seq); if (!it) return mz_err('CAP_ONE');
    var pi = it.projectItem, bin = mz_bin('MIGZZ');
    var ns = app.project.createNewSequenceFromClips(seq.name + ' · بدون سكتات', [pi], bin);
    if (!ns) return mz_err('EXC', 'new sequence');
    var g, i, tracks;
    for (g = 0; g < 2; g++) {   // empty it: the full clip was placed
      tracks = g ? ns.audioTracks : ns.videoTracks;
      for (i = 0; i < tracks.numTracks; i++) while (tracks[i].clips.numItems) tracks[i].clips[0].remove(false, false);
    }
    var fps = mz_fps(ns), t = 0, oldIn = mz_secs(pi.getInPoint()), oldOut = mz_secs(pi.getOutPoint()), n = 0;
    for (i = 0; i < keep.length; i++) {
      var a = Math.round(keep[i][0] * fps) / fps, b = Math.round(keep[i][1] * fps) / fps;
      if (b - a < 1 / fps) continue;
      pi.setInPoint(a, 4); pi.setOutPoint(b, 4);
      ns.videoTracks[0].overwriteClip(pi, t);
      t += b - a; n++;
    }
    try { pi.setInPoint(oldIn, 4); pi.setOutPoint(oldOut, 4); } catch (e) { try { pi.clearInPoint(); pi.clearOutPoint(); } catch (e2) {} }
    app.project.openSequence(ns.sequenceID);
    return mz_ok({ name: ns.name, parts: n, len: t });
  });
}

// ───────────── podcast: cams on video tracks, one mic per speaker; cut + disable on a copy of the sequence
function mz_podcastInfo() {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var v = [], a = [], i, c;
    for (i = 0; i < seq.videoTracks.numTracks; i++) { c = seq.videoTracks[i].clips; if (c.numItems) v.push({ track: i, name: c[0].name, n: c.numItems }); }
    for (i = 0; i < seq.audioTracks.numTracks; i++) {
      c = seq.audioTracks[i].clips;
      if (!c.numItems) continue;
      var x = c[0];
      a.push({ track: i, name: x.name, n: c.numItems, path: x.projectItem ? x.projectItem.getMediaPath() : '', start: mz_secs(x.start), inP: mz_secs(x.inPoint), end: mz_secs(x.end) });
    }
    return mz_ok({ video: v, audio: a, end: Number(seq.end) / MZ_TPS, name: seq.name });
  });
}
// segs: [[t0, t1, videoTrack]...] (timeline seconds) · cams: the video tracks that take part
function mz_podcastApply(segs, cams) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var srcName = seq.name;
    seq.clone();
    var ns = null, i, j, k;
    for (i = 0; i < app.project.sequences.numSequences; i++) {
      var s = app.project.sequences[i];
      if (s.sequenceID !== seq.sequenceID && s.name.indexOf(srcName) === 0 && s.name !== srcName) ns = s;
    }
    if (!ns) return mz_err('EXC', 'copy');
    ns.name = srcName + ' · بودكاست';
    app.project.openSequence(ns.sequenceID);
    app.enableQE();
    var qs = qe.project.getActiveSequence(), fps = mz_fps(ns);
    var cuts = [];
    for (i = 1; i < segs.length; i++) cuts.push(segs[i][0]);
    var fr = ns.getSettings().videoFrameRate;
    for (k = 0; k < cams.length; k++) {
      var qt = qs.getVideoTrackAt(cams[k]);
      for (i = 0; i < cuts.length; i++) {
        var tm = mz_time(Math.round(cuts[i] * fps) / fps);
        qt.razor(tm.getFormatted(fr, ns.videoDisplayFormat));
      }
    }
    var changed = 0;
    for (k = 0; k < cams.length; k++) {
      var cl = ns.videoTracks[cams[k]].clips;
      for (j = 0; j < cl.numItems; j++) {
        var mid = (mz_secs(cl[j].start) + mz_secs(cl[j].end)) / 2, who = -1;
        for (i = 0; i < segs.length; i++) if (mid >= segs[i][0] && mid < segs[i][1]) { who = segs[i][2]; break; }
        var off = who !== cams[k];
        if (cl[j].disabled !== off) { cl[j].disabled = off; changed++; }
      }
    }
    return mz_ok({ name: ns.name, cuts: cuts.length, changed: changed });
  });
}

// ───────────── safe-zone guide: a transparent PNG (made by the panel) on the top free track
function mz_seqSize() {
  var s = mz_seq(); if (!s) return mz_err('NO_SEQ');
  return mz_ok({ w: s.frameSizeHorizontal, h: s.frameSizeVertical, end: Number(s.end) / MZ_TPS });
}
function mz_safeGuidePr(file, platform) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var i, j, c, removed = 0, was = '';
    for (i = 0; i < seq.videoTracks.numTracks; i++) for (j = seq.videoTracks[i].clips.numItems - 1; j >= 0; j--) {
      c = seq.videoTracks[i].clips[j];
      if (/^MIGZZ guide/.test(c.name)) { was = c.name; c.remove(false, false); removed++; }
    }
    if (!file || was === 'MIGZZ guide · ' + platform) return mz_ok({ removed: true });
    var it = mz_import(file); if (!it) return mz_err('FILE_MISSING');
    it.name = 'MIGZZ guide · ' + platform;
    var end = Number(seq.end) / MZ_TPS;
    it.setOutPoint(Math.max(1, end), 4);
    if (!mz_place(it, 0, 0, 0)) return mz_err('NO_TRACK');
    return mz_ok({ name: it.name });
  });
}

// ───────────── organise the project panel into bins by kind
function mz_prKind(it) {
  if (it.type === ProjectItemType.BIN) return '';
  if (it.isSequence && it.isSequence()) return 'Sequences';
  var p = '';
  try { p = it.getMediaPath(); } catch (e) {}
  if (/\.(mp4|mov|mxf|avi|mkv|m4v|webm|mts|m2ts|wmv|r3d|braw)$/i.test(p)) return 'Video';
  if (/\.(png|jpe?g|gif|bmp|tiff?|webp|psd|ai|svg|heic|exr)$/i.test(p)) return 'Images';
  if (/\.(wav|mp3|m4a|aac|aif+|flac|ogg)$/i.test(p)) return 'Audio';
  if (/\.(mogrt|aep|prproj|srt)$/i.test(p)) return 'Graphics';
  return p ? 'Other' : '';
}
function mz_organizePlan(deep) {
  var plan = { Sequences: 0, Video: 0, Images: 0, Audio: 0, Graphics: 0, Other: 0 }, moves = [], names = { Sequences: 1, Video: 1, Images: 1, Audio: 1, Graphics: 1, Other: 1, MIGZZ: 1 };
  function walk(bin, depth) {
    var i, it, k;
    for (i = 0; i < bin.children.numItems; i++) {
      it = bin.children[i];
      if (it.type === ProjectItemType.BIN) { if (deep && !names[it.name]) walk(it, depth + 1); continue; }
      k = mz_prKind(it);
      if (k && !(depth === 0 && false)) { plan[k]++; moves.push([it, k]); }
    }
  }
  walk(app.project.rootItem, 0);
  return { plan: plan, moves: moves, n: moves.length };
}
function mz_organizeInfo(deep) { return mz_try(function () { var p = mz_organizePlan(deep); return mz_ok({ plan: p.plan, n: p.n }); }); }
function mz_organize(deep) {
  return mz_try(function () {
    var p = mz_organizePlan(deep), i, bins = {};
    for (i = 0; i < p.moves.length; i++) {
      var k = p.moves[i][1];
      if (!bins[k]) bins[k] = mz_bin(k);
      p.moves[i][0].moveBin(bins[k]);
    }
    return mz_ok({ count: p.moves.length });
  });
}

// ───────────── a .mogrt at the playhead, on the first free video track
function mz_mogrtInsert(file, text) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    if (!seq.importMGT) return mz_err('PR_OLD');
    var t = seq.getPlayerPosition(), i, tr = -1, dur = 5;
    var ft = mz_freeTrack(seq.videoTracks, 0, mz_secs(t), mz_secs(t) + dur);   // adds a track when all are busy
    if (ft) { seq = mz_seq(); for (i = 0; i < seq.videoTracks.numTracks; i++) if (seq.videoTracks[i].id === ft.id) tr = i; }
    if (tr < 0) return mz_err('NO_TRACK');
    var item = seq.importMGT(file, t.ticks, tr, 0);
    if (!item) return mz_err('MOGRT_FAIL');
    if (text) {
      try {
        var comp = item.getMGTComponent(), p = comp ? comp.properties.getParamForDisplayName('النص') : null;
        if (p) {
          var v = p.getValue(), o = null;
          try { o = JSON.parse(v); } catch (e1) {}
          if (o && o.textEditValue !== undefined) { o.textEditValue = text; p.setValue(JSON.stringify(o), true); } else p.setValue(text, true);
        }
      } catch (e2) {}
    }
    return mz_ok({ name: item.name, track: tr + 1 });
  });
}

// ───────────── motion tracking in Premiere: frame at the playhead, then keys on the clip above
function mz_prFrame(file) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    app.enableQE();
    var q = qe.project.getActiveSequence(), t = seq.getPlayerPosition();
    var tc = t.getFormatted(seq.getSettings().videoFrameRate, seq.videoDisplayFormat);
    q.exportFramePNG(tc, file.replace(/\.png$/i, ''));
    return mz_ok({ w: seq.frameSizeHorizontal, h: seq.frameSizeVertical, t: mz_secs(t) });
  });
}
function mz_motion(item) {   // the clip's Motion: position (normalised), scale (%)
  var i, c, comps = item.components;
  for (i = 0; i < comps.numItems; i++) { c = comps[i]; if (c.matchName === 'AE.ADBE Motion' || c.displayName === 'Motion') return c; }
  return null;
}
function mz_param(comp, names) {
  var i, j, p = comp.properties;
  for (j = 0; j < names.length; j++) for (i = 0; i < p.numItems; i++) if (p[i].displayName === names[j]) return p[i];
  return null;
}
function mz_trackInfoPr() {
  var r = eval('(' + mz_clipInfo(false, true) + ')');
  if (!r.ok) return mz_json(r);
  var seq = mz_seq(), it = mz_selClip(seq), m = mz_motion(it), pos = [0.5, 0.5], sc = 100;
  try { pos = mz_param(m, ['Position']).getValue(); sc = mz_param(m, ['Scale']).getValue(); } catch (e) {}
  r.pos = pos; r.scale = sc; r.t = mz_secs(seq.getPlayerPosition());
  r.a = Math.max(r.a, r.t - r.start);
  return mz_json(r);
}
// keys: [[seqTime, x, y]...] in sequence pixels → the topmost clip above the source that covers the time
function mz_trackApplyPr(srcId, keys) {
  return mz_try(function () {
    var seq = mz_seq(); if (!seq) return mz_err('NO_SEQ');
    var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, from = 0, i, j, tgt = null, t0 = keys[0][0], t1 = keys[keys.length - 1][0];
    for (i = 0; i < seq.videoTracks.numTracks; i++) for (j = 0; j < seq.videoTracks[i].clips.numItems; j++) if (seq.videoTracks[i].clips[j].nodeId === srcId) from = i + 1;
    for (i = seq.videoTracks.numTracks - 1; i >= from && !tgt; i--) for (j = 0; j < seq.videoTracks[i].clips.numItems; j++) {
      var c = seq.videoTracks[i].clips[j];
      if (mz_secs(c.start) <= t0 + 0.05 && mz_secs(c.end) >= Math.min(t1, mz_secs(c.end))) { tgt = c; break; }
    }
    if (!tgt) return mz_err('TRACK_NO_TARGET');
    var m = mz_motion(tgt), P = m ? mz_param(m, ['Position']) : null;
    if (!P) return mz_err('EXC', 'no Motion');
    P.setTimeVarying(true);
    var s0 = mz_secs(tgt.start), in0 = mz_secs(tgt.inPoint), n = 0;
    for (i = 0; i < keys.length; i++) {
      if (keys[i][0] < s0 || keys[i][0] > mz_secs(tgt.end)) continue;
      var tm = mz_time(keys[i][0] - s0 + in0);
      P.addKey(tm);
      P.setValueAtKey(tm, [keys[i][1] / W, keys[i][2] / H], i === keys.length - 1);
      n++;
    }
    return mz_ok({ name: tgt.name, keys: n });
  });
}

// opens a project file (test runner)
function mz_openProject(file) { return mz_try(function () { app.openDocument(file, true, true, true); return mz_ok({ name: app.project.name }); }); }

MZ_FILE_pr = 1;
