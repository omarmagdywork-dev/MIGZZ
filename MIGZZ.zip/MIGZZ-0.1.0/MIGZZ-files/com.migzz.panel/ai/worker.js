/* MIGZZ — AI worker. Runs in its own Node process (so the panel never freezes):
     node worker.js job.json
   Prints "P <percent>" lines while working, then "DONE <json>" or "ERR <message>".
   Tasks: mask (person cut-out matte, RobustVideoMatting) · voice (speech / music split, MDX-Net) · face (face track, YuNet). */
'use strict';
const fs = require('fs'), path = require('path'), cp = require('child_process');
const job = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const ort = require(job.ort);
const say = (s) => process.stdout.write(s + '\n');
let lastP = -1;
const prog = (p) => { p = Math.max(0, Math.min(100, Math.round(p))); if (p !== lastP) { lastP = p; say('P ' + p); } };

async function session(model) {
  const eps = job.cpuOnly ? [['cpu']] : (process.platform === 'win32' ? [['dml', 'cpu'], ['cpu']] : [['cpu']]);
  let err;
  for (const ep of eps) {
    try {
      const s = await ort.InferenceSession.create(model, { executionProviders: ep, graphOptimizationLevel: 'all' });
      say('EP ' + ep[0]);
      return s;
    } catch (e) { err = e; }
  }
  throw err;
}

// ffmpeg → fixed-size raw frames, read one at a time (the decoder pauses while we work)
function frameReader(args, frameBytes) {
  const p = cp.spawn(job.ff, args, { windowsHide: true });
  let chunks = [], have = 0, ended = false, waiting = null, errText = '';
  p.stderr.on('data', (d) => { errText = (errText + d).slice(-4000); });
  p.stdout.on('data', (d) => {
    chunks.push(d); have += d.length;
    if (have >= frameBytes * 2) p.stdout.pause();
    if (waiting && have >= frameBytes) { const w = waiting; waiting = null; w(); }
  });
  const fin = () => { ended = true; if (waiting) { const w = waiting; waiting = null; w(); } };
  p.stdout.on('end', fin);
  p.on('close', () => setTimeout(fin, 50));   // belt and braces: the process is gone, so no more frames are coming
  return {
    proc: p,
    err: () => errText,
    next: () => new Promise((resolve) => {
      const take = () => {
        if (have < frameBytes) {
          if (ended) return resolve(null);
          p.stdout.resume(); waiting = take; return;
        }
        const all = chunks.length === 1 ? chunks[0] : Buffer.concat(chunks, have);
        const f = Buffer.from(all.subarray(0, frameBytes));
        const rest = all.subarray(frameBytes);
        chunks = rest.length ? [rest] : []; have = rest.length;
        if (have < frameBytes * 2) p.stdout.resume();
        resolve(f);
      };
      take();
    })
  };
}
function writer(args) {
  const p = cp.spawn(job.ff, args, { windowsHide: true });
  let errText = '';
  p.stderr.on('data', (d) => { errText = (errText + d).slice(-4000); });
  const done = new Promise((resolve) => p.on('close', (code) => resolve(code)));
  let broken = null;
  p.stdin.on('error', (e) => { broken = e; });
  return {
    write: (buf) => new Promise((resolve, reject) => {
      if (broken) return reject(new Error('encoder stopped: ' + errText.slice(-600)));
      if (p.stdin.write(buf)) return resolve();
      // wait until the encoder took the frame; if it dies meanwhile, fail instead of waiting forever
      const onClose = () => reject(new Error('encoder stopped: ' + errText.slice(-600)));
      p.once('close', onClose);
      p.stdin.once('drain', () => { p.removeListener('close', onClose); resolve(); });
    }),
    // after the last frame: wait for the encoder to finish the file. If it never closes, stop it after a while
    // and keep the file when it is there (a stuck encoder must not freeze the panel)
    end: async () => {
      say('L enc end');
      p.stdin.end();
      let timer = null;
      const code = await Promise.race([done, new Promise((r) => { timer = setTimeout(() => r('timeout'), 120000); })]);
      clearTimeout(timer);
      say('L enc closed ' + code);
      if (code === 'timeout') { try { p.kill(); } catch (e) {} if (!fs.existsSync(args[args.length - 1])) throw new Error('encoder timeout'); return; }
      if (code !== 0) throw new Error('encoder: ' + errText.slice(-600));
    },
    proc: p
  };
}

// ───────── person matte (RobustVideoMatting, recurrent: each frame uses the memory of the previous ones)
async function mask() {
  const s = await session(job.model);
  const W0 = job.w, H0 = job.h, lim = 1920, k = Math.min(1, lim / Math.max(W0, H0));
  const W = Math.round(W0 * k / 2) * 2, H = Math.round(H0 * k / 2) * 2;
  const ratio = Math.min(1, 512 / Math.max(W, H));
  const total = Math.max(1, Math.round(job.dur * job.fps));
  const rd = frameReader(['-hide_banner', '-loglevel', 'error', '-ss', String(job.a), '-t', String(job.dur), '-i', job.src,
    '-vf', 'scale=' + W + ':' + H + ':flags=bicubic', '-r', String(job.fps), '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], W * H * 3);
  // matte (AE: used as a Track Matte) or a ready cut-out with transparency (Premiere)
  const enc = job.rgba
    ? writer(['-hide_banner', '-loglevel', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', W + 'x' + H, '-r', String(job.fps), '-i', '-',
      '-vf', 'scale=' + W0 + ':' + H0 + ':flags=bicubic,format=yuva444p10le', '-c:v', 'prores_ks', '-profile:v', '4', '-alpha_bits', '16', '-vendor', 'apl0', job.out])
    : writer(['-hide_banner', '-loglevel', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'gray', '-s', W + 'x' + H, '-r', String(job.fps), '-i', '-',
      '-vf', 'scale=' + W0 + ':' + H0 + ':flags=bicubic,format=yuv422p10le', '-c:v', 'prores_ks', '-profile:v', '3', job.out]);
  let r = [1, 2, 3, 4].map(() => new ort.Tensor('float32', new Float32Array(1), [1, 1, 1, 1]));
  const dr = new ort.Tensor('float32', new Float32Array([ratio]), [1]);
  const src = new Float32Array(3 * W * H), out = Buffer.alloc(W * H * (job.rgba ? 4 : 1));
  let n = 0, f;
  while ((f = await rd.next())) {
    const N = W * H;
    for (let i = 0, j = 0; i < N; i++, j += 3) { src[i] = f[j] / 255; src[N + i] = f[j + 1] / 255; src[2 * N + i] = f[j + 2] / 255; }
    const o = await s.run({ src: new ort.Tensor('float32', src, [1, 3, H, W]), r1i: r[0], r2i: r[1], r3i: r[2], r4i: r[3], downsample_ratio: dr });
    r = [o.r1o, o.r2o, o.r3o, o.r4o];
    const a = o.pha.data;
    if (job.rgba) {
      for (let i = 0, j = 0, q = 0; i < N; i++, j += 3, q += 4) { const v = a[i] * 255; out[q] = f[j]; out[q + 1] = f[j + 1]; out[q + 2] = f[j + 2]; out[q + 3] = v < 0 ? 0 : (v > 255 ? 255 : v + 0.5); }
    } else for (let i = 0; i < N; i++) { const v = a[i] * 255; out[i] = v < 0 ? 0 : (v > 255 ? 255 : v + 0.5); }
    await enc.write(out);
    n++; prog(n / total * 100);
  }
  say('L loop done ' + n + '/' + total);
  await enc.end();
  if (!n) throw new Error('no frames: ' + rd.err());
  return { frames: n };
}

// ───────── FFT for any size made of 2, 3 and 5 (7680 = 2^9·3·5), complex in place via scratch
function makeFFT(N) {
  const fac = [];
  let m = N;
  for (const p of [4, 2, 3, 5]) while (m % p === 0) { fac.push(p); m /= p; }
  if (m !== 1) throw new Error('fft size ' + N);
  const cos = new Float64Array(N), sin = new Float64Array(N);
  for (let i = 0; i < N; i++) { cos[i] = Math.cos(2 * Math.PI * i / N); sin[i] = -Math.sin(2 * Math.PI * i / N); }
  const tr = new Float64Array(N), ti = new Float64Array(N);
  // recursive decimation in time over the factor list (stride trick), writes to (or, oi)
  function rec(xr, xi, off, stride, n, or, oi, oo, fi) {
    if (n === 1) { or[oo] = xr[off]; oi[oo] = xi[off]; return; }
    const p = fac[fi], m = n / p;
    for (let q = 0; q < p; q++) rec(xr, xi, off + q * stride, stride * p, m, or, oi, oo + q * m, fi + 1);
    const tw = N / n;
    for (let k = 0; k < m; k++) {
      // gather the p sub-results for this k, twiddle, then a size-p DFT
      const ar = [], ai = [];
      for (let q = 0; q < p; q++) {
        const idx = oo + q * m + k, w = (q * k * tw) % N;
        const xr0 = or[idx], xi0 = oi[idx];
        ar.push(xr0 * cos[w] - xi0 * sin[w]); ai.push(xr0 * sin[w] + xi0 * cos[w]);
      }
      for (let s = 0; s < p; s++) {
        let sr = 0, si = 0;
        for (let q = 0; q < p; q++) { const w = (q * s * m * tw) % N; sr += ar[q] * cos[w] - ai[q] * sin[w]; si += ar[q] * sin[w] + ai[q] * cos[w]; }
        tr[s] = sr; ti[s] = si;
      }
      for (let s = 0; s < p; s++) { or[oo + s * m + k] = tr[s]; oi[oo + s * m + k] = ti[s]; }
    }
  }
  return function (xr, xi, or, oi, inverse) {
    if (inverse) { for (let i = 0; i < N; i++) xi[i] = -xi[i]; }
    rec(xr, xi, 0, 1, N, or, oi, 0, 0);
    if (inverse) { for (let i = 0; i < N; i++) { or[i] /= N; oi[i] = -oi[i] / N; } }
  };
}

// ───────── speech / music split (MDX-Net, same framing as the reference code)
async function voice() {
  const s = await session(job.model);
  const NFFT = 7680, HOP = 1024, DIMF = 3072, DIMT = 256, NB = NFFT / 2 + 1, COMP = job.compensate || 1.009;
  const TRIM = NFFT / 2, CHUNK = HOP * (DIMT - 1), GEN = CHUNK - 2 * TRIM;
  // decode stereo 44.1 kHz
  const raw = await new Promise((resolve, reject) => {
    const p = cp.spawn(job.ff, ['-hide_banner', '-loglevel', 'error', '-ss', String(job.a), '-t', String(job.dur), '-i', job.src, '-vn', '-ac', '2', '-ar', '44100', '-f', 'f32le', '-'], { windowsHide: true });
    const ch = []; let err = '';
    p.stdout.on('data', (d) => ch.push(d)); p.stderr.on('data', (d) => { err += d; });
    p.on('close', (c) => c === 0 ? resolve(Buffer.concat(ch)) : reject(new Error('decode: ' + err.slice(-500))));
  });
  const n = raw.length / 8;
  if (n < 4410) throw new Error('audio too short');
  const L = new Float32Array(n), R = new Float32Array(n);
  for (let i = 0; i < n; i++) { L[i] = raw.readFloatLE(i * 8); R[i] = raw.readFloatLE(i * 8 + 4); }
  const pad = GEN - (n % GEN), padded = TRIM + n + pad + TRIM;
  const mL = new Float32Array(padded), mR = new Float32Array(padded);
  mL.set(L, TRIM); mR.set(R, TRIM);
  const win = new Float64Array(NFFT);
  for (let i = 0; i < NFFT; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / NFFT);   // periodic Hann
  const fft = makeFFT(NFFT);
  const xr = new Float64Array(NFFT), xi = new Float64Array(NFFT), or = new Float64Array(NFFT), oi = new Float64Array(NFFT);
  const vL = new Float32Array(n + pad), vR = new Float32Array(n + pad);
  const nChunks = (n + pad) / GEN;
  const half = NFFT / 2;
  const reflect = (arr, start, i) => { // reflect padding of one chunk (center=True)
    let j = i - half;
    if (j < 0) j = -j; else if (j >= CHUNK) j = 2 * (CHUNK - 1) - j;
    return arr[start + j];
  };
  for (let c = 0; c < nChunks; c++) {
    const st = c * GEN;
    const spec = new Float32Array(4 * DIMF * DIMT);
    for (let t = 0; t < DIMT; t++) {
      for (let i = 0; i < NFFT; i++) { const k = t * HOP + i; xr[i] = reflect(mL, st, k) * win[i]; xi[i] = reflect(mR, st, k) * win[i]; }
      fft(xr, xi, or, oi, false);
      for (let f = 0; f < DIMF; f++) {
        const g = f === 0 ? 0 : NFFT - f;
        // two real signals in one complex FFT: L = (Z_f + conj Z_-f)/2, R = (Z_f − conj Z_-f)/2i
        const Lr = (or[f] + or[g]) / 2, Li = (oi[f] - oi[g]) / 2, Rr = (oi[f] + oi[g]) / 2, Ri = -(or[f] - or[g]) / 2;
        spec[(0 * DIMF + f) * DIMT + t] = Lr; spec[(1 * DIMF + f) * DIMT + t] = Li;
        spec[(2 * DIMF + f) * DIMT + t] = Rr; spec[(3 * DIMF + f) * DIMT + t] = Ri;
      }
    }
    const y = job.identity ? spec : (await s.run({ input: new ort.Tensor('float32', spec, [1, 4, DIMF, DIMT]) })).output.data;   // identity: self-test of the STFT
    // inverse STFT (overlap-add, window² normalisation), centre trimmed
    const len = HOP * (DIMT - 1) + NFFT, accL = new Float64Array(len), accR = new Float64Array(len), wsum = new Float64Array(len);
    for (let t = 0; t < DIMT; t++) {
      xr.fill(0); xi.fill(0);
      // spectrum of z = l + i·r  is  Lspec + i·Rspec ; bins ≥ DIMF are zero
      for (let f = 0; f < DIMF; f++) {
        const Lr = y[(0 * DIMF + f) * DIMT + t], Li = y[(1 * DIMF + f) * DIMT + t], Rr = y[(2 * DIMF + f) * DIMT + t], Ri = y[(3 * DIMF + f) * DIMT + t];
        xr[f] += Lr - Ri; xi[f] += Li + Rr;
        if (f > 0) { const g = NFFT - f; xr[g] += Lr + Ri; xi[g] += -Li + Rr; }
      }
      fft(xr, xi, or, oi, true);
      const b = t * HOP;
      for (let i = 0; i < NFFT; i++) { accL[b + i] += or[i] * win[i]; accR[b + i] += oi[i] * win[i]; wsum[b + i] += win[i] * win[i]; }
    }
    // chunk sample k ↔ acc index k + half; keep [TRIM, CHUNK − TRIM)
    for (let k = TRIM; k < CHUNK - TRIM; k++) {
      const a = k + half, w = wsum[a] > 1e-11 ? wsum[a] : 1, o2 = st + k - TRIM;
      vL[o2] = accL[a] / w * COMP; vR[o2] = accR[a] / w * COMP;
    }
    prog((c + 1) / nChunks * 95);
  }
  // voice.wav and background.wav (16-bit)
  const wav = (file, a, b2) => {
    const d = Buffer.alloc(44 + n * 4);
    d.write('RIFF', 0); d.writeUInt32LE(36 + n * 4, 4); d.write('WAVEfmt ', 8); d.writeUInt32LE(16, 16); d.writeUInt16LE(1, 20); d.writeUInt16LE(2, 22);
    d.writeUInt32LE(44100, 24); d.writeUInt32LE(44100 * 4, 28); d.writeUInt16LE(4, 32); d.writeUInt16LE(16, 34); d.write('data', 36); d.writeUInt32LE(n * 4, 40);
    for (let i = 0; i < n; i++) {
      d.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(a(i) * 32767))), 44 + i * 4);
      d.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(b2(i) * 32767))), 46 + i * 4);
    }
    fs.writeFileSync(file, d);
  };
  wav(job.outVoice, (i) => vL[i], (i) => vR[i]);
  wav(job.outMusic, (i) => L[i] - vL[i], (i) => R[i] - vR[i]);
  prog(100);
  return { samples: n };
}

// ───────── face track (YuNet on every frame, letterboxed into 640×640)
function decodeYunet(o, thr) {
  const faces = [];
  for (const st of [8, 16, 32]) {
    const cls = o['cls_' + st].data, obj = o['obj_' + st].data, box = o['bbox_' + st].data, kps = o['kps_' + st].data, cols = 640 / st;
    for (let i = 0; i < cls.length; i++) {
      const sc = Math.sqrt(Math.min(1, Math.max(0, cls[i])) * Math.min(1, Math.max(0, obj[i])));
      if (sc < thr) continue;
      const r = Math.floor(i / cols), c = i % cols;
      const cx = (c + box[i * 4]) * st, cy = (r + box[i * 4 + 1]) * st, w = Math.exp(box[i * 4 + 2]) * st, h = Math.exp(box[i * 4 + 3]) * st;
      const lm = [];
      for (let k = 0; k < 5; k++) lm.push([(c + kps[i * 10 + 2 * k]) * st, (r + kps[i * 10 + 2 * k + 1]) * st]);
      faces.push({ x: cx - w / 2, y: cy - h / 2, w, h, s: sc, lm });
    }
  }
  faces.sort((a, b) => b.s - a.s);
  const keep = [];
  const iou = (a, b) => {
    const x1 = Math.max(a.x, b.x), y1 = Math.max(a.y, b.y), x2 = Math.min(a.x + a.w, b.x + b.w), y2 = Math.min(a.y + a.h, b.y + b.h);
    const i = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
    return i / (a.w * a.h + b.w * b.h - i);
  };
  for (const f of faces) if (keep.every((k) => iou(k, f) < 0.3)) keep.push(f);
  return keep;
}
async function face() {
  const s = await session(job.model);
  const S = 640, k = Math.min(S / job.w, S / job.h);
  const total = Math.max(1, Math.round(job.dur * job.fps));
  const rd = frameReader(['-hide_banner', '-loglevel', 'error', '-ss', String(job.a), '-t', String(job.dur), '-i', job.src,
    '-vf', 'scale=' + Math.round(job.w * k) + ':' + Math.round(job.h * k) + ',pad=640:640:0:0', '-r', String(job.fps), '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-'], S * S * 3);
  const inp = new Float32Array(3 * S * S), N = S * S, track = [];
  let prev = null, f, n = 0, found = 0;
  while ((f = await rd.next())) {
    for (let i = 0, j = 0; i < N; i++, j += 3) { inp[i] = f[j]; inp[N + i] = f[j + 1]; inp[2 * N + i] = f[j + 2]; }
    const o = await s.run({ input: new ort.Tensor('float32', inp, [1, 3, S, S]) });
    const faces = decodeYunet(o, 0.6);
    let pick = null;
    if (faces.length) {
      if (!prev) pick = faces.reduce((a, b) => (b.w * b.h > a.w * a.h ? b : a));
      else pick = faces.reduce((a, b) => {
        const da = Math.hypot(a.x + a.w / 2 - prev.cx, a.y + a.h / 2 - prev.cy), db = Math.hypot(b.x + b.w / 2 - prev.cx, b.y + b.h / 2 - prev.cy);
        return db < da ? b : a;
      });
    }
    if (pick) {
      const e1 = pick.lm[0], e2 = pick.lm[1];   // right eye, left eye (image coordinates)
      prev = { cx: pick.x + pick.w / 2, cy: pick.y + pick.h / 2 };
      track.push([n, prev.cx / k, prev.cy / k, pick.w / k, pick.h / k, Math.atan2(e2[1] - e1[1], e2[0] - e1[0]) * 180 / Math.PI]);
      found++;
    } else track.push([n, null]);
    n++; prog(n / total * 100);
  }
  if (!found) return { frames: n, found: 0, keys: [] };
  // fill gaps by holding / interpolating, then smooth with a centred window (keeps the motion, drops the jitter)
  const pts = track.filter((t) => t[1] !== null);
  const full = track.map((t) => {
    if (t[1] !== null) return t.slice(1);
    let a = null, b = null;
    for (const p of pts) { if (p[0] < t[0]) a = p; else { b = p; break; } }
    if (!a) return b.slice(1); if (!b) return a.slice(1);
    const u = (t[0] - a[0]) / (b[0] - a[0]);
    return a.slice(1).map((v, i) => v + (b[i + 1] - v) * u);
  });
  const R = job.smooth || 2, keys = [];
  for (let i = 0; i < full.length; i++) {
    const acc = [0, 0, 0, 0, 0]; let c = 0;
    for (let j = Math.max(0, i - R); j <= Math.min(full.length - 1, i + R); j++) { for (let q = 0; q < 5; q++) acc[q] += full[j][q]; c++; }
    keys.push([i / job.fps].concat(acc.map((v) => Math.round(v / c * 100) / 100)));
  }
  return { frames: n, found, keys };
}

// ───────── image → textured 3D model (background removal → TripoSR → surface → baked texture → .glb)
function resize(src, sw, sh, ch, dw, dh) {   // bilinear, Float32 in/out
  const out = new Float32Array(dw * dh * ch);
  for (let y = 0; y < dh; y++) {
    const fy = Math.min(sh - 1, Math.max(0, (y + 0.5) * sh / dh - 0.5)), y0 = Math.floor(fy), y1 = Math.min(sh - 1, y0 + 1), wy = fy - y0;
    for (let x = 0; x < dw; x++) {
      const fx = Math.min(sw - 1, Math.max(0, (x + 0.5) * sw / dw - 0.5)), x0 = Math.floor(fx), x1 = Math.min(sw - 1, x0 + 1), wx = fx - x0;
      for (let c = 0; c < ch; c++) {
        const a = src[(y0 * sw + x0) * ch + c], b = src[(y0 * sw + x1) * ch + c], d = src[(y1 * sw + x0) * ch + c], e = src[(y1 * sw + x1) * ch + c];
        out[(y * dw + x) * ch + c] = (a * (1 - wx) + b * wx) * (1 - wy) + (d * (1 - wx) + e * wx) * wy;
      }
    }
  }
  return out;
}
async function readImage(file) {
  const info = await new Promise((resolve) => {
    const p = cp.spawn(job.ff, ['-hide_banner', '-i', file], { windowsHide: true }); let e = '';
    p.stderr.on('data', (d) => { e += d; }); p.on('close', () => resolve(e));
  });
  const m = /Video:.*?(\d{2,5})x(\d{2,5})/.exec(info);
  if (!m) throw new Error('not an image');
  const w = Number(m[1]), h = Number(m[2]);
  const raw = await new Promise((resolve, reject) => {
    const p = cp.spawn(job.ff, ['-hide_banner', '-loglevel', 'error', '-i', file, '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-'], { windowsHide: true });
    const ch = []; p.stdout.on('data', (d) => ch.push(d)); p.on('close', (c) => c === 0 ? resolve(Buffer.concat(ch)) : reject(new Error('decode image')));
  });
  return { w, h, rgba: raw };
}
async function to3d() {
  const M = require('./mesh.js');
  const img = await readImage(job.src), W = img.w, H = img.h, N0 = W * H;
  const rgb = new Float32Array(N0 * 3), alpha = new Float32Array(N0);
  let hasAlpha = false;
  for (let i = 0; i < N0; i++) {
    rgb[i * 3] = img.rgba[i * 4] / 255; rgb[i * 3 + 1] = img.rgba[i * 4 + 1] / 255; rgb[i * 3 + 2] = img.rgba[i * 4 + 2] / 255;
    alpha[i] = img.rgba[i * 4 + 3] / 255; if (alpha[i] < 0.95) hasAlpha = true;
  }
  prog(2);
  // 1. the object alone: the picture's own transparency, or the background remover (IS-Net)
  if (!hasAlpha || job.forceCut) {
    const s = await session(job.segModel), S = 1024;
    const r = resize(rgb, W, H, 3, S, S);
    let mx = 1e-6; for (let i = 0; i < r.length; i++) mx = Math.max(mx, r[i]);
    const t = new Float32Array(3 * S * S), mean = [0.485, 0.456, 0.406];
    for (let i = 0; i < S * S; i++) for (let c = 0; c < 3; c++) t[c * S * S + i] = r[i * 3 + c] / mx - mean[c];
    const o = await s.run({ [s.inputNames[0]]: new ort.Tensor('float32', t, [1, 3, S, S]) });
    const pred = o[s.outputNames[0]].data;
    let lo = Infinity, hi = -Infinity; for (let i = 0; i < pred.length; i++) { lo = Math.min(lo, pred[i]); hi = Math.max(hi, pred[i]); }
    const m = new Float32Array(S * S); for (let i = 0; i < m.length; i++) m[i] = (pred[i] - lo) / Math.max(1e-6, hi - lo);
    const a = resize(m, S, S, 1, W, H);
    for (let i = 0; i < N0; i++) alpha[i] = Math.min(alpha[i], a[i]);
    if (typeof s.release === 'function') await s.release();
  }
  prog(8);
  // 2. TripoSR input: the object centred, filling 85 % of a square, over mid grey, 512×512
  let x0 = W, y0 = H, x1 = -1, y1 = -1;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (alpha[y * W + x] > 0.5) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  if (x1 < 0) throw new Error('NO_OBJECT');
  const side = Math.ceil(Math.max(x1 - x0 + 1, y1 - y0 + 1) / 0.85), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
  const sq = new Float32Array(side * side * 3).fill(0.5);
  for (let y = 0; y < side; y++) for (let x = 0; x < side; x++) {
    const sx = Math.round(cx - side / 2 + x), sy = Math.round(cy - side / 2 + y);
    if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
    const a = alpha[sy * W + sx], j = (sy * W + sx) * 3, k = (y * side + x) * 3;
    for (let c = 0; c < 3; c++) sq[k + c] = rgb[j + c] * a + 0.5 * (1 - a);
  }
  const inp = resize(sq, side, side, 3, 512, 512);
  if (job.preview) {   // the prepared picture, for the "my models" list
    const pv = resize(inp, 512, 512, 3, 256, 256), b = new Uint8Array(256 * 256 * 3);
    for (let i = 0; i < b.length; i++) b[i] = Math.round(Math.min(1, Math.max(0, pv[i])) * 255);
    fs.writeFileSync(job.preview, M.png(b, 256, 256, 3));
  }
  const t512 = new Float32Array(3 * 512 * 512);
  for (let i = 0; i < 512 * 512; i++) for (let c = 0; c < 3; c++) t512[c * 512 * 512 + i] = inp[i * 3 + c];
  // 3. the encoder makes the triplane (the object's 3D "memory"); the decoder answers density/colour at any point
  const enc = await session(job.encModel);
  const sc = (await enc.run({ [enc.inputNames[0]]: new ort.Tensor('float32', t512, [1, 3, 512, 512]) }))[enc.outputNames[0]];
  if (typeof enc.release === 'function') await enc.release();
  prog(25);
  const dec = await session(job.decModel), R = 0.87, TH = 25;
  const dIn = dec.inputNames, dOut = dec.outputNames;
  const nameOf = (re, list, d) => list.find((n) => re.test(n)) || list[d];
  const inCodes = nameOf(/scene|code|triplane/i, dIn, 0), inPts = nameOf(/point|xyz/i, dIn, 1);
  const outDen = nameOf(/dens/i, dOut, 0), outCol = nameOf(/col/i, dOut, 1);
  const CH = 131072;
  const query = async (pts, want) => {   // pts: Float32Array k*3 → density or colour
    const k = pts.length / 3, res = new Float32Array(want === 'col' ? k * 3 : k);
    for (let i = 0; i < k; i += CH) {
      const n = Math.min(CH, k - i);
      const o = await dec.run({ [inCodes]: sc, [inPts]: new ort.Tensor('float32', pts.subarray(i * 3, (i + n) * 3), [1, n, 3]) });
      if (want === 'col') res.set(o[outCol].data.subarray(0, n * 3), i * 3); else res.set(o[outDen].data.subarray(0, n), i);
    }
    return res;
  };
  const N = job.res || 160, grid = new Float32Array(N * N * N), P = (i) => -R + 2 * R * i / (N - 1);
  const slab = new Float32Array(N * N * 3);
  for (let z = 0; z < N; z++) {
    let q = 0;
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { slab[q++] = P(x); slab[q++] = P(y); slab[q++] = P(z); }
    const d = await query(slab, 'den');
    for (let i = 0; i < N * N; i++) grid[z * N * N + i] = d[i] - TH;
    prog(25 + 40 * (z + 1) / N);
  }
  // 4. surface, clean-up, smoothing (in model units)
  let m = M.surfaceNets(grid, N);
  if (!m.tri.length) throw new Error('NO_SHAPE');
  m = M.keepLargest(m);
  for (let i = 0; i < m.pos.length; i++) m.pos[i] = P(m.pos[i]);
  M.smooth(m, 2);
  if (M.signedVolume(m.pos, m.tri) < 0) for (let t = 0; t < m.tri.length; t += 3) { const a = m.tri[t + 1]; m.tri[t + 1] = m.tri[t + 2]; m.tri[t + 2] = a; }
  prog(70);
  // 5. texture: every texel asks the colour field at its 3D point
  const TS = job.tex || 2048, A = M.atlas(m, TS);
  const cols = await query(A.tex.length ? (() => { const p = new Float32Array(A.tex.length / 5 * 3); for (let i = 0, j = 0; i < A.tex.length; i += 5) { p[j++] = A.tex[i + 2]; p[j++] = A.tex[i + 3]; p[j++] = A.tex[i + 4]; } return p; })() : new Float32Array(0), 'col');
  let cmin = Infinity, cmax = -Infinity; for (let i = 0; i < cols.length; i++) { cmin = Math.min(cmin, cols[i]); cmax = Math.max(cmax, cols[i]); }
  const logits = cmin < -0.2 || cmax > 1.2;   // some exports leave out the final sigmoid
  const rgbT = new Float32Array(TS * TS * 3), filled = new Uint8Array(TS * TS);
  for (let i = 0, j = 0; i < A.tex.length; i += 5, j += 3) {
    const k = A.tex[i + 1] * TS + A.tex[i];
    for (let c = 0; c < 3; c++) { let v = cols[j + c]; if (logits) v = 1 / (1 + Math.exp(-v)); rgbT[k * 3 + c] = v; }
    filled[k] = 1;
  }
  prog(88);
  M.dilate(rgbT, filled, TS, 4);
  const px = new Uint8Array(TS * TS * 3);
  for (let i = 0; i < px.length; i++) px[i] = Math.round(Math.min(1, Math.max(0, rgbT[i])) * 255);
  // 6. upright (the model space has Z up): (x, y, z) → (−y, z, −x), smooth normals from the welded surface
  const rot = (arr) => { for (let i = 0; i < arr.length; i += 3) { const x = arr[i], y = arr[i + 1], z = arr[i + 2]; arr[i] = -y; arr[i + 1] = z; arr[i + 2] = -x; } };
  const wn = M.normals(m.pos, m.tri), nrm = new Float32Array(A.pos.length);
  for (let t = 0; t < m.tri.length; t++) nrm.set(wn.subarray(m.tri[t] * 3, m.tri[t] * 3 + 3), t * 3);
  rot(A.pos); rot(nrm);
  // sit on the ground: lowest point at y = 0, centred in x/z
  let ymin = Infinity, xs = 0, zs = 0; for (let i = 0; i < A.pos.length; i += 3) { ymin = Math.min(ymin, A.pos[i + 1]); xs += A.pos[i]; zs += A.pos[i + 2]; }
  xs /= A.pos.length / 3; zs /= A.pos.length / 3;
  for (let i = 0; i < A.pos.length; i += 3) { A.pos[i] -= xs; A.pos[i + 1] -= ymin; A.pos[i + 2] -= zs; }
  fs.writeFileSync(job.out, M.glb(A.pos, nrm, A.uv, A.tri, M.png(px, TS, TS, 3), job.name || 'MIGZZ'));
  prog(100);
  return { tris: m.tri.length / 3, verts: m.pos.length / 3, tex: TS };
}

// ───────── still image → PNG with the background removed (IS-Net)
async function cutimg() {
  const M = require('./mesh.js');
  const img = await readImage(job.src), W = img.w, H = img.h, N0 = W * H, S = 1024;
  const rgb = new Float32Array(N0 * 3);
  for (let i = 0; i < N0; i++) { rgb[i * 3] = img.rgba[i * 4] / 255; rgb[i * 3 + 1] = img.rgba[i * 4 + 1] / 255; rgb[i * 3 + 2] = img.rgba[i * 4 + 2] / 255; }
  prog(10);
  const s = await session(job.model);
  const r = resize(rgb, W, H, 3, S, S);
  let mx = 1e-6; for (let i = 0; i < r.length; i++) mx = Math.max(mx, r[i]);
  const t = new Float32Array(3 * S * S), mean = [0.485, 0.456, 0.406];
  for (let i = 0; i < S * S; i++) for (let c = 0; c < 3; c++) t[c * S * S + i] = r[i * 3 + c] / mx - mean[c];
  const o = await s.run({ [s.inputNames[0]]: new ort.Tensor('float32', t, [1, 3, S, S]) });
  prog(70);
  const pred = o[s.outputNames[0]].data;
  let lo = Infinity, hi = -Infinity; for (let i = 0; i < pred.length; i++) { lo = Math.min(lo, pred[i]); hi = Math.max(hi, pred[i]); }
  const m = new Float32Array(S * S); for (let i = 0; i < m.length; i++) m[i] = (pred[i] - lo) / Math.max(1e-6, hi - lo);
  const a = resize(m, S, S, 1, W, H), out = new Uint8Array(N0 * 4);
  for (let i = 0; i < N0; i++) {
    out[i * 4] = img.rgba[i * 4]; out[i * 4 + 1] = img.rgba[i * 4 + 1]; out[i * 4 + 2] = img.rgba[i * 4 + 2];
    out[i * 4 + 3] = Math.round(Math.min(1, Math.max(0, a[i])) * (img.rgba[i * 4 + 3] / 255) * 255);
  }
  fs.writeFileSync(job.out, M.png(out, W, H, 4));
  prog(100);
  return { w: W, h: H };
}

// ───────── object tracking: normalised cross-correlation of a template, frame by frame (works on CPU)
async function track() {
  const W0 = job.w, H0 = job.h, k = Math.min(1, 640 / Math.max(W0, H0)), W = Math.round(W0 * k / 2) * 2, H = Math.round(H0 * k / 2) * 2;
  const total = Math.max(1, Math.round(job.dur * job.fps));
  const rd = frameReader(['-hide_banner', '-loglevel', 'error', '-ss', String(job.a), '-t', String(job.dur), '-i', job.src,
    '-vf', 'scale=' + W + ':' + H, '-r', String(job.fps), '-f', 'rawvideo', '-pix_fmt', 'gray', '-'], W * H);
  // box in source pixels → working pixels
  let bw = Math.max(8, Math.round(job.box[2] * k)), bh = Math.max(8, Math.round(job.box[3] * k));
  let cx = job.box[0] * k + bw / 2, cy = job.box[1] * k + bh / 2, vx = 0, vy = 0;
  const st = Math.max(1, Math.round(Math.max(bw, bh) / 48));   // template sampling step (keeps it ~48×48)
  const tw = Math.floor(bw / st), th = Math.floor(bh / st);
  const grab = (f, x0, y0) => { const t = new Float32Array(tw * th); for (let j = 0; j < th; j++) for (let i = 0; i < tw; i++) { const x = Math.min(W - 1, Math.max(0, Math.round(x0 + i * st))), y = Math.min(H - 1, Math.max(0, Math.round(y0 + j * st))); t[j * tw + i] = f[y * W + x]; } return t; };
  const tz = new Float32Array(tw * th);   // template minus its mean, divided by its norm
  const setTpl = (t) => { let m = 0; for (const v of t) m += v; m /= t.length; let q = 0; for (let i = 0; i < t.length; i++) { tz[i] = t[i] - m; q += tz[i] * tz[i]; } q = Math.sqrt(q) || 1; for (let i = 0; i < t.length; i++) tz[i] /= q; };
  const n2 = tw * th;
  // normalised cross-correlation at one position, reading the frame directly (no allocation)
  const score = (f, cxp, cyp) => {
    const x0 = Math.round(cxp - bw / 2), y0 = Math.round(cyp - bh / 2);
    let s1 = 0, s2 = 0, sc = 0, k2 = 0;
    for (let j = 0; j < th; j++) {
      const y = Math.min(H - 1, Math.max(0, y0 + j * st)), row = y * W;
      for (let i = 0; i < tw; i++, k2++) {
        const x = Math.min(W - 1, Math.max(0, x0 + i * st)), v = f[row + x];
        s1 += v; s2 += v * v; sc += v * tz[k2];
      }
    }
    const varc = s2 - s1 * s1 / n2;   // the mean term drops out because tz sums to 0
    return varc > 1e-6 ? sc / Math.sqrt(varc) : 0;
  };
  let tpl = null;
  const out = [];
  let f, n = 0, lost = 0;
  while ((f = await rd.next())) {
    if (!tpl) { tpl = grab(f, cx - bw / 2, cy - bh / 2); setTpl(tpl); out.push([0, cx / k, cy / k, 1]); n++; continue; }
    const R = Math.max(10, Math.round(Math.max(bw, bh) * 0.4 + Math.hypot(vx, vy))), px = cx + vx, py = cy + vy;
    // coarse grid, then a fine search around the best point
    const g = Math.max(2, st);
    let best = -2, bx = px, by = py;
    for (let y = py - R; y <= py + R; y += g) for (let x = px - R; x <= px + R; x += g) { const s2 = score(f, x, y); if (s2 > best) { best = s2; bx = x; by = y; } }
    const cx0 = bx, cy0 = by;
    for (let y = cy0 - g; y <= cy0 + g; y++) for (let x = cx0 - g; x <= cx0 + g; x++) { const s2 = score(f, x, y); if (s2 > best) { best = s2; bx = x; by = y; } }
    if (best > 0.45) {
      vx = (bx - cx) * 0.7 + vx * 0.3; vy = (by - cy) * 0.7 + vy * 0.3; cx = bx; cy = by; lost = 0;
      if (best > 0.7) { const c = grab(f, cx - bw / 2, cy - bh / 2); for (let i = 0; i < tpl.length; i++) tpl[i] = tpl[i] * 0.9 + c[i] * 0.1; setTpl(tpl); }
    } else { lost++; vx *= 0.5; vy *= 0.5; }
    out.push([n / job.fps, cx / k, cy / k, Math.round(Math.max(0, best) * 100) / 100]);
    n++; prog(n / total * 100);
  }
  // light smoothing, keeps the motion
  const keys = out.map((p, i) => {
    let sx = 0, sy = 0, c = 0;
    for (let j = Math.max(0, i - 1); j <= Math.min(out.length - 1, i + 1); j++) { sx += out[j][1]; sy += out[j][2]; c++; }
    return [i / job.fps, Math.round(sx / c * 100) / 100, Math.round(sy / c * 100) / 100, p[3]];
  });
  return { frames: n, keys, weak: keys.filter((x) => x[3] < 0.45).length };
}

const TASKS = { mask, voice, face, to3d, cutimg, track };
TASKS[job.task]().then((r) => { say('DONE ' + JSON.stringify(r)); process.exit(0); }, (e) => { say('ERR ' + String(e && e.stack || e).replace(/\n/g, ' | ').slice(0, 1500)); process.exit(1); });
