/* MIGZZ — mesh tools for image → 3D (no dependencies):
   surface extraction (surface nets), clean-up, smoothing, a texture atlas (two triangles per square),
   colour baking from a 3D colour field, and a .glb writer with an embedded PNG. */
'use strict';
const zlib = require('zlib');

// grid: Float32Array N³ (x fastest), value > 0 inside. Returns { pos: Float32Array, tri: Uint32Array } in grid units.
function surfaceNets(grid, N) {
  const idx = (x, y, z) => x + N * (y + N * z);
  const vid = new Int32Array((N - 1) * (N - 1) * (N - 1)).fill(-1);
  const cid = (x, y, z) => x + (N - 1) * (y + (N - 1) * z);
  const pos = [];
  const C = [[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0], [0, 0, 1], [1, 0, 1], [0, 1, 1], [1, 1, 1]];
  const E = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]];
  const v = new Float32Array(8);
  for (let z = 0; z < N - 1; z++) for (let y = 0; y < N - 1; y++) for (let x = 0; x < N - 1; x++) {
    let inside = 0;
    for (let c = 0; c < 8; c++) { v[c] = grid[idx(x + C[c][0], y + C[c][1], z + C[c][2])]; if (v[c] > 0) inside++; }
    if (inside === 0 || inside === 8) continue;
    let sx = 0, sy = 0, sz = 0, n = 0;
    for (const [a, b] of E) {
      if ((v[a] > 0) === (v[b] > 0)) continue;
      const t = v[a] / (v[a] - v[b]);
      sx += C[a][0] + (C[b][0] - C[a][0]) * t; sy += C[a][1] + (C[b][1] - C[a][1]) * t; sz += C[a][2] + (C[b][2] - C[a][2]) * t; n++;
    }
    vid[cid(x, y, z)] = pos.length / 3;
    pos.push(x + sx / n, y + sy / n, z + sz / n);
  }
  const tri = [];
  const quad = (a, b, c, d, flip) => {
    if (a < 0 || b < 0 || c < 0 || d < 0) return;
    if (flip) tri.push(a, c, b, a, d, c); else tri.push(a, b, c, a, c, d);
  };
  for (let z = 1; z < N - 1; z++) for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
    const s = grid[idx(x, y, z)] > 0;
    // edge along +x from (x,y,z): the four cells around it share it
    if (x < N - 1 && s !== (grid[idx(x + 1, y, z)] > 0)) quad(vid[cid(x, y - 1, z - 1)], vid[cid(x, y, z - 1)], vid[cid(x, y, z)], vid[cid(x, y - 1, z)], !s);
    if (y < N - 1 && s !== (grid[idx(x, y + 1, z)] > 0)) quad(vid[cid(x - 1, y, z - 1)], vid[cid(x - 1, y, z)], vid[cid(x, y, z)], vid[cid(x, y, z - 1)], !s);
    if (z < N - 1 && s !== (grid[idx(x, y, z + 1)] > 0)) quad(vid[cid(x - 1, y - 1, z)], vid[cid(x, y - 1, z)], vid[cid(x, y, z)], vid[cid(x - 1, y, z)], !s);
  }
  return { pos: new Float32Array(pos), tri: new Uint32Array(tri) };
}

// keeps the biggest connected piece (drops floating crumbs), re-indexes the vertices
function keepLargest(m) {
  const nv = m.pos.length / 3, par = new Int32Array(nv);
  for (let i = 0; i < nv; i++) par[i] = i;
  const find = (a) => { while (par[a] !== a) { par[a] = par[par[a]]; a = par[a]; } return a; };
  for (let t = 0; t < m.tri.length; t += 3) { const a = find(m.tri[t]); par[find(m.tri[t + 1])] = a; par[find(m.tri[t + 2])] = a; }
  const count = new Map();
  for (let t = 0; t < m.tri.length; t += 3) { const r = find(m.tri[t]); count.set(r, (count.get(r) || 0) + 1); }
  let best = -1, bc = 0;
  count.forEach((c, r) => { if (c > bc) { bc = c; best = r; } });
  const map = new Int32Array(nv).fill(-1), pos = [], tri = [];
  for (let t = 0; t < m.tri.length; t += 3) {
    if (find(m.tri[t]) !== best) continue;
    for (let k = 0; k < 3; k++) {
      const o = m.tri[t + k];
      if (map[o] < 0) { map[o] = pos.length / 3; pos.push(m.pos[o * 3], m.pos[o * 3 + 1], m.pos[o * 3 + 2]); }
      tri.push(map[o]);
    }
  }
  return { pos: new Float32Array(pos), tri: new Uint32Array(tri) };
}

// Taubin smoothing: removes the voxel stair-steps without shrinking the object
function smooth(m, iters) {
  const nv = m.pos.length / 3, nb = Array.from({ length: nv }, () => new Set());
  for (let t = 0; t < m.tri.length; t += 3) for (let k = 0; k < 3; k++) { const a = m.tri[t + k], b = m.tri[t + (k + 1) % 3]; nb[a].add(b); nb[b].add(a); }
  const lists = nb.map((s) => Array.from(s));
  const tmp = new Float32Array(m.pos.length);
  const step = (lam) => {
    for (let i = 0; i < nv; i++) {
      const L = lists[i];
      if (!L.length) { tmp[i * 3] = m.pos[i * 3]; tmp[i * 3 + 1] = m.pos[i * 3 + 1]; tmp[i * 3 + 2] = m.pos[i * 3 + 2]; continue; }
      let x = 0, y = 0, z = 0;
      for (const j of L) { x += m.pos[j * 3]; y += m.pos[j * 3 + 1]; z += m.pos[j * 3 + 2]; }
      x /= L.length; y /= L.length; z /= L.length;
      tmp[i * 3] = m.pos[i * 3] + lam * (x - m.pos[i * 3]); tmp[i * 3 + 1] = m.pos[i * 3 + 1] + lam * (y - m.pos[i * 3 + 1]); tmp[i * 3 + 2] = m.pos[i * 3 + 2] + lam * (z - m.pos[i * 3 + 2]);
    }
    m.pos.set(tmp);
  };
  for (let i = 0; i < iters; i++) { step(0.5); step(-0.53); }
  return m;
}

function normals(pos, tri) {
  const n = new Float32Array(pos.length);
  for (let t = 0; t < tri.length; t += 3) {
    const a = tri[t] * 3, b = tri[t + 1] * 3, c = tri[t + 2] * 3;
    const ux = pos[b] - pos[a], uy = pos[b + 1] - pos[a + 1], uz = pos[b + 2] - pos[a + 2];
    const vx = pos[c] - pos[a], vy = pos[c + 1] - pos[a + 1], vz = pos[c + 2] - pos[a + 2];
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    for (const o of [a, b, c]) { n[o] += nx; n[o + 1] += ny; n[o + 2] += nz; }
  }
  for (let i = 0; i < n.length; i += 3) { const l = Math.hypot(n[i], n[i + 1], n[i + 2]) || 1; n[i] /= l; n[i + 1] /= l; n[i + 2] /= l; }
  return n;
}
function signedVolume(pos, tri) {
  let v = 0;
  for (let t = 0; t < tri.length; t += 3) {
    const a = tri[t] * 3, b = tri[t + 1] * 3, c = tri[t + 2] * 3;
    v += pos[a] * (pos[b + 1] * pos[c + 2] - pos[b + 2] * pos[c + 1]) - pos[a + 1] * (pos[b] * pos[c + 2] - pos[b + 2] * pos[c]) + pos[a + 2] * (pos[b] * pos[c + 1] - pos[b + 1] * pos[c]);
  }
  return v / 6;
}

/* texture atlas: triangle pairs share one square cell; every triangle gets its own 3 corners (unwelded).
   Returns per-corner arrays + the list of texels to colour: for each texel its 3D point. */
function atlas(m, size) {
  const nt = m.tri.length / 3, cells = Math.ceil(nt / 2), per = Math.ceil(Math.sqrt(cells)), S = Math.floor(size / per);
  if (S < 4) throw new Error('mesh too dense for the texture');
  const g = 1.2;   // gap between the two triangles of a cell, in texels
  const pos = new Float32Array(nt * 9), uv = new Float32Array(nt * 6), tri = new Uint32Array(nt * 3);
  const tex = []; // [px, py, x, y, z]
  for (let t = 0; t < nt; t++) {
    const c = t >> 1, cx = (c % per) * S, cy = Math.floor(c / per) * S, s = S - 1;
    // corners in texel space (inset by half a texel from the cell border)
    const P = (t & 1) === 0 ? [[cx + 0.5, cy + 0.5], [cx + s - g, cy + 0.5], [cx + 0.5, cy + s - g]] : [[cx + s, cy + s], [cx + g + 1, cy + s], [cx + s, cy + g + 1]];
    for (let k = 0; k < 3; k++) {
      const o = m.tri[t * 3 + k];
      pos.set([m.pos[o * 3], m.pos[o * 3 + 1], m.pos[o * 3 + 2]], (t * 3 + k) * 3);
      uv[(t * 3 + k) * 2] = P[k][0] / size; uv[(t * 3 + k) * 2 + 1] = P[k][1] / size;
      tri[t * 3 + k] = t * 3 + k;
    }
    // texels whose centres fall in (or within half a texel of) the triangle
    const [A, B, Cc] = P, x0 = Math.floor(Math.min(A[0], B[0], Cc[0])) - 1, x1 = Math.ceil(Math.max(A[0], B[0], Cc[0])) + 1;
    const y0 = Math.floor(Math.min(A[1], B[1], Cc[1])) - 1, y1 = Math.ceil(Math.max(A[1], B[1], Cc[1])) + 1;
    const den = (B[1] - Cc[1]) * (A[0] - Cc[0]) + (Cc[0] - B[0]) * (A[1] - Cc[1]);
    for (let py = Math.max(0, y0); py <= Math.min(size - 1, y1); py++) for (let px = Math.max(0, x0); px <= Math.min(size - 1, x1); px++) {
      const X = px + 0.5, Y = py + 0.5;
      let l0 = ((B[1] - Cc[1]) * (X - Cc[0]) + (Cc[0] - B[0]) * (Y - Cc[1])) / den;
      let l1 = ((Cc[1] - A[1]) * (X - Cc[0]) + (A[0] - Cc[0]) * (Y - Cc[1])) / den;
      let l2 = 1 - l0 - l1;
      const e = -0.6 / s;
      if (l0 < e || l1 < e || l2 < e) continue;
      l0 = Math.max(0, l0); l1 = Math.max(0, l1); l2 = Math.max(0, l2);
      const sm = l0 + l1 + l2; l0 /= sm; l1 /= sm; l2 /= sm;
      const a = m.tri[t * 3] * 3, b = m.tri[t * 3 + 1] * 3, cc = m.tri[t * 3 + 2] * 3;
      tex.push(px, py, l0 * m.pos[a] + l1 * m.pos[b] + l2 * m.pos[cc], l0 * m.pos[a + 1] + l1 * m.pos[b + 1] + l2 * m.pos[cc + 1], l0 * m.pos[a + 2] + l1 * m.pos[b + 2] + l2 * m.pos[cc + 2]);
    }
  }
  return { pos, uv, tri, tex: new Float32Array(tex), S };
}

// fills empty texels from their coloured neighbours (stops colour bleeding at the edges of each triangle)
function dilate(rgb, filled, size, passes) {
  for (let p = 0; p < passes; p++) {
    const add = [];
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const i = y * size + x;
      if (filled[i]) continue;
      let r = 0, g = 0, b = 0, n = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const X = x + dx, Y = y + dy;
        if (X < 0 || Y < 0 || X >= size || Y >= size) continue;
        const j = Y * size + X;
        if (filled[j]) { r += rgb[j * 3]; g += rgb[j * 3 + 1]; b += rgb[j * 3 + 2]; n++; }
      }
      if (n) add.push(i, r / n, g / n, b / n);
    }
    for (let k = 0; k < add.length; k += 4) { const i = add[k]; rgb[i * 3] = add[k + 1]; rgb[i * 3 + 1] = add[k + 2]; rgb[i * 3 + 2] = add[k + 3]; filled[i] = 1; }
  }
}

// PNG (RGB or RGBA 8-bit)
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function png(data, w, h, ch) {
  const raw = Buffer.alloc((w * ch + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * ch + 1)] = 0; Buffer.from(data.buffer, data.byteOffset + y * w * ch, w * ch).copy(raw, y * (w * ch + 1) + 1); }
  const chunk = (type, body) => { const b = Buffer.alloc(12 + body.length); b.writeUInt32BE(body.length, 0); b.write(type, 4, 'latin1'); body.copy(b, 8); b.writeUInt32BE(crc32(b.subarray(4, 8 + body.length)), 8 + body.length); return b; };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = ch === 4 ? 6 : 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 6 })), chunk('IEND', Buffer.alloc(0))]);
}

// glTF 2.0 binary: one mesh, one textured material
function glb(pos, nrm, uv, tri, pngBuf, name) {
  const parts = [], views = [];
  let off = 0;
  const add = (buf, target) => {
    const pad = (4 - (buf.length % 4)) % 4;
    views.push({ buffer: 0, byteOffset: off, byteLength: buf.length, ...(target ? { target } : {}) });
    parts.push(buf, Buffer.alloc(pad)); off += buf.length + pad;
    return views.length - 1;
  };
  const b = (ta) => Buffer.from(ta.buffer, ta.byteOffset, ta.byteLength);
  const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < pos.length; i += 3) for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], pos[i + k]); mx[k] = Math.max(mx[k], pos[i + k]); }
  const vP = add(b(pos), 34962), vN = add(b(nrm), 34962), vT = add(b(uv), 34962), vI = add(b(tri), 34963), vImg = add(pngBuf);
  const n = pos.length / 3;
  const json = {
    asset: { version: '2.0', generator: 'MIGZZ' },
    scene: 0, scenes: [{ nodes: [0] }], nodes: [{ mesh: 0, name }],
    meshes: [{ name, primitives: [{ attributes: { POSITION: 0, NORMAL: 1, TEXCOORD_0: 2 }, indices: 3, material: 0 }] }],
    materials: [{ name: name + ' material', pbrMetallicRoughness: { baseColorTexture: { index: 0 }, metallicFactor: 0, roughnessFactor: 0.75 } }],
    textures: [{ source: 0, sampler: 0 }], samplers: [{ magFilter: 9729, minFilter: 9729, wrapS: 33071, wrapT: 33071 }],
    images: [{ bufferView: vImg, mimeType: 'image/png' }],
    accessors: [
      { bufferView: vP, componentType: 5126, count: n, type: 'VEC3', min: mn, max: mx },
      { bufferView: vN, componentType: 5126, count: n, type: 'VEC3' },
      { bufferView: vT, componentType: 5126, count: n, type: 'VEC2' },
      { bufferView: vI, componentType: 5125, count: tri.length, type: 'SCALAR' }
    ],
    bufferViews: views, buffers: [{ byteLength: off }]
  };
  let js = Buffer.from(JSON.stringify(json));
  js = Buffer.concat([js, Buffer.alloc((4 - (js.length % 4)) % 4, 0x20)]);
  const bin = Buffer.concat(parts);
  const head = Buffer.alloc(12); head.write('glTF', 0, 'latin1'); head.writeUInt32LE(2, 4); head.writeUInt32LE(12 + 8 + js.length + 8 + bin.length, 8);
  const ch = (len, type) => { const h = Buffer.alloc(8); h.writeUInt32LE(len, 0); h.write(type, 4, 'latin1'); return h; };
  return Buffer.concat([head, ch(js.length, 'JSON'), js, ch(bin.length, 'BIN\0'), bin]);
}

module.exports = { surfaceNets, keepLargest, smooth, normals, signedVolume, atlas, dilate, png, glb };
