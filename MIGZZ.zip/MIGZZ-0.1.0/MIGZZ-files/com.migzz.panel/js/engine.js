/* MIGZZ — local engine: downloads the AI tools once, runs them on this computer, keeps a log.
   Exposes window.MZE. Needs Node (CEP --enable-nodejs --mixed-context). */
(function () {
  'use strict';
  var nreq = (typeof window.cep_node !== 'undefined' && window.cep_node.require) ? window.cep_node.require : (typeof require === 'function' ? require : null);
  var NODE = !!nreq && typeof process !== 'undefined';
  if (!NODE) { window.MZE = { NODE: false }; return; }

  var fs = nreq('fs'), path = nreq('path'), os = nreq('os'), https = nreq('https'), cp = nreq('child_process'), url = nreq('url');
  var WIN = process.platform === 'win32';
  var DATA = path.join(process.env.APPDATA || path.join(os.homedir(), '.config'), 'MIGZZ');
  var PACKS_DIR = path.join(DATA, 'packs');
  var TMP = path.join(os.tmpdir(), 'MIGZZ');

  function mkdirp(d) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); }
  mkdirp(DATA); mkdirp(PACKS_DIR); mkdirp(TMP);

  function log() {
    var line = new Date().toISOString() + ' ' + Array.prototype.map.call(arguments, function (a) {
      return typeof a === 'string' ? a : (a && a.stack) ? a.stack : JSON.stringify(a);
    }).join(' ') + '\n';
    try {
      var f = path.join(DATA, 'log.txt');
      if (fs.existsSync(f) && fs.statSync(f).size > 2e6) fs.renameSync(f, f + '.old');
      fs.appendFileSync(f, line);
    } catch (e) { /* logging must never break a tool */ }
  }

  // ───────── what can be downloaded (once), and where it ends up
  var GH_WHISPER = 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.9.2/';
  var HF_WHISPER = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/';
  var PACKS = {
    ffmpeg: { label: 'قارئ الصوت والفيديو (FFmpeg)', url: 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1.zip', zip: true, exe: 'ffmpeg.exe', mb: 80 },
    whisperCpu: { label: 'محرك الكلام (المعالج)', url: GH_WHISPER + 'whisper-blas-bin-x64.zip', zip: true, exe: 'whisper-cli.exe', mb: 21 },
    whisperGpu: { label: 'محرك الكلام (كارت الشاشة)', url: GH_WHISPER + 'whisper-cublas-12.4.0-bin-x64.zip', zip: true, exe: 'whisper-cli.exe', mb: 670 },
    speechFast: { label: 'موديل الكلام السريع', url: HF_WHISPER + 'ggml-small-q5_1.bin', file: 'ggml-small-q5_1.bin', mb: 190 },
    speechBest: { label: 'موديل الكلام الأدق', url: HF_WHISPER + 'ggml-large-v3-turbo-q5_0.bin', file: 'ggml-large-v3-turbo-q5_0.bin', mb: 574 }
  };

  function packDir(key) { return path.join(PACKS_DIR, key); }
  function findFile(dir, name) {
    if (!fs.existsSync(dir)) return null;
    var items = fs.readdirSync(dir), i, p, st, r;
    for (i = 0; i < items.length; i++) {
      p = path.join(dir, items[i]);
      st = fs.statSync(p);
      if (st.isFile() && items[i].toLowerCase() === name.toLowerCase()) return p;
    }
    for (i = 0; i < items.length; i++) {
      p = path.join(dir, items[i]);
      if (fs.statSync(p).isDirectory()) { r = findFile(p, name); if (r) return r; }
    }
    return null;
  }
  // the main file of an installed pack, or null when it isn't installed (or got damaged)
  function installed(key) {
    var P = PACKS[key], d = packDir(key);
    if (!fs.existsSync(path.join(d, '.ok'))) return null;
    return findFile(d, P.exe || P.file);
  }

  // ───────── download with redirects, progress, a size check, and resume (Range) after a dropped connection
  function downloadOnce(src, dest, onProgress, job) {
    return new Promise(function (resolve, reject) {
      var part = dest + '.part', hops = 0;
      function get(u) {
        if (job && job.cancelled) return reject(new Error('CANCELLED'));
        var have = fs.existsSync(part) ? fs.statSync(part).size : 0;
        var opts = url.parse(u);
        opts.headers = { 'User-Agent': 'MIGZZ-panel' };
        if (have > 0) opts.headers.Range = 'bytes=' + have + '-';
        var req = https.get(opts, function (res) {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            res.resume();
            if (++hops > 10) return reject(new Error('too many redirects'));
            return get(url.resolve(u, res.headers.location));
          }
          if (res.statusCode === 416 && have > 0) { res.resume(); try { fs.unlinkSync(part); } catch (e) {} return get(u); }
          if (res.statusCode !== 200 && res.statusCode !== 206) { res.resume(); return reject(new Error('HTTP ' + res.statusCode + ' ' + u)); }
          var resumed = res.statusCode === 206, base = resumed ? have : 0;
          var total = (Number(res.headers['content-length']) || 0) + (total0(res) ? base : 0), got = base;
          var out = fs.createWriteStream(part, { flags: resumed ? 'a' : 'w' });
          res.on('data', function (chunk) {
            got += chunk.length;
            if (onProgress) onProgress(got, total);
            if (job && job.cancelled) { req.destroy(); out.destroy(); }
          });
          res.pipe(out);
          out.on('finish', function () {
            out.close(function () {
              if (job && job.cancelled) return reject(new Error('CANCELLED'));
              if (total && fs.statSync(part).size !== total) return reject(new Error('download incomplete'));
              try { if (fs.existsSync(dest)) fs.unlinkSync(dest); fs.renameSync(part, dest); } catch (e) { return reject(e); }
              resolve(dest);
            });
          });
          out.on('error', reject);
          res.on('error', reject);
          res.on('aborted', function () { reject(new Error('download incomplete')); });
        });
        req.on('error', reject);
        req.setTimeout(60000, function () { req.destroy(new Error('the connection timed out')); });
      }
      function total0(res) { return !!res.headers['content-length']; }
      get(src);
    });
  }
  // up to 4 tries, each one continues where the last stopped
  function download(src, dest, onProgress, job) {
    var tries = 0;
    function attempt() {
      return downloadOnce(src, dest, onProgress, job).catch(function (e) {
        if (job && job.cancelled) throw e;
        if (++tries >= 4 || !/incomplete|timed out|ECONNRESET|socket hang up|EPIPE|ETIMEDOUT|EAI_AGAIN/i.test(String(e && e.message))) throw e;
        log('download retry', tries, e.message);
        return new Promise(function (r) { setTimeout(r, 2000 * tries); }).then(attempt);
      });
    }
    return attempt();
  }

  function runQuiet(cmd, args) {
    return new Promise(function (resolve, reject) {
      cp.execFile(cmd, args, { windowsHide: true, maxBuffer: 1 << 24 }, function (err, so, se) {
        if (err) return reject(new Error((String(se || '') + ' ' + err.message).trim()));
        resolve(String(so || ''));
      });
    });
  }
  function unzip(zip, outDir) {
    mkdirp(outDir);
    var tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
    return runQuiet(tar, ['-xf', zip, '-C', outDir]).catch(function (e) {
      log('tar failed, trying PowerShell', e.message);
      return runQuiet('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
        "Expand-Archive -LiteralPath '" + zip.replace(/'/g, "''") + "' -DestinationPath '" + outDir.replace(/'/g, "''") + "' -Force"]);
    });
  }
  // small JSON over https (GitHub API needs a User-Agent)
  function getJSON(u, timeout) {
    return new Promise(function (resolve, reject) {
      var opts = url.parse(u); opts.headers = { 'User-Agent': 'MIGZZ-panel', 'Accept': 'application/vnd.github+json' };
      var req = https.get(opts, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return getJSON(url.resolve(u, res.headers.location), timeout).then(resolve, reject); }
        var b = ''; res.setEncoding('utf8');
        res.on('data', function (c) { b += c; });
        res.on('end', function () { if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode)); try { resolve(JSON.parse(b)); } catch (e) { reject(e); } });
      });
      req.on('error', reject);
      req.setTimeout(timeout || 15000, function () { req.destroy(new Error('timed out')); });
    });
  }
  function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) { /* in use: next time */ } }

  // installs a pack now (only ever one download per pack: see ensure)
  function installNow(key, emit, job) {
    var P = PACKS[key], d = packDir(key);
    var dest = path.join(d, P.zip ? 'download.zip' : P.file);
    // clean a half-installed pack, but keep a partial download (and the lock) so it can resume
    if (fs.existsSync(d)) fs.readdirSync(d).forEach(function (n) { if (n !== path.basename(dest) + '.part' && n !== '.dl-lock') rmrf(path.join(d, n)); });
    mkdirp(d);
    log('download', key, P.url);
    return download(P.url, dest, function (got, total) {
      var pct = total ? Math.round(got / total * 100) : null;
      emit('بينزّل ' + P.label + ' · ' + (pct !== null ? pct + '%' : Math.round(got / 1e6) + ' MB'), pct);
    }, job).then(function () {
      if (!P.zip) return;
      emit('بيفك ' + P.label + '…', 100);
      return unzip(dest, d).then(function () { try { fs.unlinkSync(dest); } catch (e) {} });
    }).then(function () {
      if (P.after) return P.after(d);
    }).then(function () {
      var f = findFile(d, P.exe || P.file);
      if (!f) throw new Error('missing ' + (P.exe || P.file) + ' after install');
      fs.writeFileSync(path.join(d, '.ok'), new Date().toISOString());
      log('installed', key, f);
      return f;
    }).catch(function (e) { log('install failed', key, e); throw e; });
  }

  // ───────── one download per pack, shared by the tools and the background downloader,
  // and between After Effects and Premiere when both panels are open (a lock file with a heartbeat)
  var inflight = {};
  var ME = process.pid + '@' + (window.__adobe_cep__ ? 'cep' : 'web');
  function lockPath(key) { return path.join(packDir(key), '.dl-lock'); }
  function otherLock(key) {
    try { var o = JSON.parse(fs.readFileSync(lockPath(key), 'utf8')); return (o.me !== ME && Date.now() - o.t < 20000) ? o : null; } catch (e) { return null; }
  }
  function writeLock(key, pct) { try { mkdirp(packDir(key)); fs.writeFileSync(lockPath(key), JSON.stringify({ me: ME, t: Date.now(), pct: pct })); } catch (e) {} }
  function packState(key) {
    if (installed(key)) return { state: 'ok', pct: 100 };
    var f = inflight[key]; if (f) return { state: 'dl', pct: f.pct, text: f.text };
    var o = otherLock(key); if (o) return { state: 'dl', pct: o.pct, other: true };
    if (BG.errors[key]) return { state: 'err', error: BG.errors[key] };
    return { state: 'wait' };
  }
  // ensure(key, onProgress(text, percent), job) → path of the pack's main file
  function ensure(key, onProgress, job) {
    var have = installed(key);
    if (have) return Promise.resolve(have);
    var P = PACKS[key];
    var tell = function (t, p) { if (onProgress) onProgress(t, p); };
    var cancelWatch = function (promise) {   // a tool can stop waiting; the download itself goes on in the background
      if (!job) return promise;
      return new Promise(function (resolve, reject) {
        var iv = setInterval(function () { if (job.cancelled) { clearInterval(iv); reject(new Error('CANCELLED')); } }, 400);
        promise.then(function (v) { clearInterval(iv); resolve(v); }, function (e) { clearInterval(iv); reject(e); });
      });
    };
    var f = inflight[key];
    if (!f && otherLock(key)) {
      // the other Adobe app is downloading it right now: wait for it
      return cancelWatch(new Promise(function (resolve, reject) {
        (function poll() {
          var ok = installed(key); if (ok) return resolve(ok);
          var o = otherLock(key);
          if (!o) return ensure(key, onProgress, null).then(resolve, reject);
          tell('بيتحمّل في البرنامج التاني · ' + P.label + (o.pct !== null && o.pct !== undefined ? ' ' + o.pct + '%' : '') + '. الأداة هتكمل لوحدها أول ما يخلص', o.pct);
          setTimeout(poll, 1000);
        })();
      }));
    }
    if (!f) {
      f = inflight[key] = { listeners: [], pct: 0, text: '', bg: !onProgress };
      var lastLock = 0, emit = function (t, p) {
        f.text = t; if (p !== null && p !== undefined) f.pct = p;
        if (Date.now() - lastLock > 2000) { lastLock = Date.now(); writeLock(key, f.pct); }
        f.listeners.slice().forEach(function (l) { try { l(t, p); } catch (e) {} });
      };
      writeLock(key, 0);
      var hb = setInterval(function () { writeLock(key, f.pct); }, 5000);
      f.promise = installNow(key, emit, null).then(function (r) {
        clearInterval(hb); delete inflight[key]; try { fs.unlinkSync(lockPath(key)); } catch (e) {}
        delete BG.errors[key]; return r;
      }, function (e) {
        clearInterval(hb); delete inflight[key]; try { fs.unlinkSync(lockPath(key)); } catch (e2) {}
        throw e;
      });
    } else if (onProgress) {
      tell('الموديل لسه بيتحمّل في الخلفية · ' + P.label + ' ' + f.pct + '%. الأداة هتكمل لوحدها أول ما يخلص', f.pct);
    }
    if (onProgress) {
      var joined = f.listeners.length > 0 || f.bg;
      var l = function (t, p) { tell(joined && /^بينزّل/.test(t) ? 'الموديل لسه بيتحمّل في الخلفية · ' + P.label + ' ' + (p === null ? '' : p + '%') + '. الأداة هتكمل لوحدها أول ما يخلص' : t, p); };
      f.listeners.push(l);
      f.promise.then(function () {}, function () {}).then(function () { var i = f.listeners.indexOf(l); if (i >= 0) f.listeners.splice(i, 1); });
    }
    return cancelWatch(f.promise);
  }

  // ───────── background downloader: gets every model ready once, while the panel is open.
  // Resumes where it stopped (closing the app or a dropped connection loses nothing).
  var BG = { started: false, paused: false, errors: {}, keys: [], done: false, other: false };
  var BG_ORDER = ['ffmpeg', 'ytdlp', 'node', 'ortNode', 'ortCommon', 'mFace', 'mMask', 'mVoice', 'whisperCpu', 'whisperGpu', 'speechBest', 'mSeg', 'rife', 'speechFast', 'm3dDec', 'm3dEnc'];
  var BG_LOCK = path.join(PACKS_DIR, '.bg-lock');
  function bgOwner() { try { var o = JSON.parse(fs.readFileSync(BG_LOCK, 'utf8')); return (o.me !== ME && Date.now() - o.t < 20000) ? o : null; } catch (e) { return null; } }
  function bgKeys() { return BG.keys; }
  function bgState() {
    var items = BG.keys.map(function (k) { var s = packState(k); s.key = k; s.label = PACKS[k].label; s.mb = PACKS[k].mb; return s; });
    var left = items.filter(function (i) { return i.state !== 'ok'; });
    return { items: items, left: left.length, total: items.length, mbLeft: left.reduce(function (a, i) { return a + i.mb; }, 0), paused: BG.paused, cur: items.filter(function (i) { return i.state === 'dl'; })[0] || null, started: BG.started };
  }
  function bgStart() {
    if (BG.started) return;
    BG.started = true;
    hasNvidia().then(function (gpu) {
      BG.keys = BG_ORDER.filter(function (k) { return PACKS[k] && (k !== 'whisperGpu' || gpu); });
      log('bg downloads', BG.keys.filter(function (k) { return !installed(k); }).join(',') || 'all ready');
      var i = 0;
      function next() {
        if (BG.paused) return setTimeout(next, 1500);
        if (bgOwner()) { BG.other = true; return setTimeout(next, 5000); }   // the other Adobe app is on it
        BG.other = false;
        try { fs.writeFileSync(BG_LOCK, JSON.stringify({ me: ME, t: Date.now() })); } catch (e) {}
        while (i < BG.keys.length && (installed(BG.keys[i]) || BG.errors[BG.keys[i]])) i++;
        if (i >= BG.keys.length) {
          try { fs.unlinkSync(BG_LOCK); } catch (e) {}
          var failed = Object.keys(BG.errors);
          if (!failed.length) { BG.done = true; log('bg downloads done'); return; }
          // something failed (usually the connection): try those again in a bit
          return setTimeout(function () { BG.errors = {}; i = 0; next(); }, 120000);
        }
        var k = BG.keys[i];
        var o = otherLock(k);
        if (o) return setTimeout(next, 3000);
        var hb = setInterval(function () { try { fs.writeFileSync(BG_LOCK, JSON.stringify({ me: ME, t: Date.now() })); } catch (e) {} }, 5000);
        ensure(k).then(function () { clearInterval(hb); i++; next(); }, function (e) {
          clearInterval(hb); BG.errors[k] = String(e && e.message || e); i++; setTimeout(next, 3000);
        });
      }
      next();
    });
  }

  // ───────── run a tool; onLine gets every stderr/stdout line (for progress)
  function run(exe, args, onLine, job, opts) {
    return new Promise(function (resolve) {
      log('run', exe, JSON.stringify(args));
      var p, out = '', err = '', o = { windowsHide: true, cwd: path.dirname(exe) };
      if (opts && opts.env) o.env = Object.assign({}, process.env, opts.env);
      try { p = cp.spawn(exe, args, o); } catch (e) { return resolve({ code: -1, err: e.message }); }
      if (job) job.proc = p;
      function feed(buf, isErr) {
        var s = buf.toString('utf8');
        if (isErr) err += s; else out += s;
        if (err.length > 400000) err = err.slice(-200000);
        if (onLine) s.split(/\r?\n|\r/).forEach(function (l) { if (l.trim()) onLine(l); });
      }
      p.stdout.on('data', function (b) { feed(b, false); });
      p.stderr.on('data', function (b) { feed(b, true); });
      p.on('error', function (e) { resolve({ code: -1, err: e.message, out: out }); });
      p.on('close', function (code) {
        if (code !== 0) log('exit', code, err.slice(-3000));
        resolve({ code: code, out: out, err: err });
      });
    });
  }

  var nvidia = null;
  function hasNvidia() {
    if (nvidia !== null) return Promise.resolve(nvidia);
    return runQuiet('nvidia-smi', ['--query-gpu=name,memory.total', '--format=csv,noheader']).then(function (o) {
      nvidia = o.trim() ? o.trim().split(/\r?\n/)[0] : '';
      log('gpu', nvidia || 'none');
      return nvidia;
    }).catch(function () { nvidia = ''; return ''; });
  }

  function tmpFile(ext) { return path.join(TMP, 'mz_' + Date.now() + '_' + Math.floor(Math.random() * 1e6) + ext); }
  function cleanTmp() {
    try {
      fs.readdirSync(TMP).forEach(function (n) {
        var p = path.join(TMP, n);
        if (Date.now() - fs.statSync(p).mtimeMs > 6 * 3600e3) rmrf(p);
      });
    } catch (e) {}
  }
  cleanTmp();

  window.MZE = {
    NODE: true, WIN: WIN, DATA: DATA, PACKS: PACKS, fs: fs, path: path, os: os, cp: cp,
    log: log, installed: installed, ensure: ensure, packState: packState, bgStart: bgStart, bgState: bgState, bgPause: function (v) { BG.paused = !!v; }, run: run, hasNvidia: hasNvidia, tmpFile: tmpFile, rmrf: rmrf, packDir: packDir,
    download: download, unzip: unzip, mkdirp: mkdirp, getJSON: getJSON
  };
  log('panel start', 'node ' + process.version);
})();

/* ───────── beat detection: pure JavaScript, no model needed.
   The bass (kick + bass line) is isolated with a low-pass filter, its energy envelope is
   followed in 10 ms steps, and the sharp rises of that envelope are the beats. */
(function () {
  'use strict';
  var E = window.MZE;
  if (!E || !E.NODE) return;
  var SR = 11025, HOP = Math.round(SR * 0.01);

  // decodes the audio of [a, a+dur] seconds to mono float samples at SR
  function decode(ff, file, a, dur, job) {
    return new Promise(function (resolve, reject) {
      var cp = E.cp, chunks = [], size = 0;
      var p = cp.spawn(ff, ['-hide_banner', '-loglevel', 'error', '-ss', a.toFixed(3), '-t', dur.toFixed(3), '-i', file, '-vn', '-ac', '1', '-ar', String(SR), '-f', 'f32le', '-'], { windowsHide: true });
      if (job) job.proc = p;
      p.stdout.on('data', function (b) { chunks.push(b); size += b.length; });
      p.on('error', reject);
      p.on('close', function (code) {
        if (job && job.cancelled) return reject(new Error('CANCELLED'));
        if (code !== 0 || !size) return reject(new Error('decode failed (' + code + ')'));
        var buf = Buffer.concat(chunks, size);
        var n = Math.floor(buf.length / 4), out = new Float32Array(n);
        for (var i = 0; i < n; i++) out[i] = buf.readFloatLE(i * 4);
        resolve(out);
      });
    });
  }

  // 2nd-order low-pass (RBJ biquad), run twice for a steeper slope
  function lowpass(x, fc) {
    var w = 2 * Math.PI * fc / SR, al = Math.sin(w) / (2 * 0.7071), cs = Math.cos(w);
    var b0 = (1 - cs) / 2, b1 = 1 - cs, b2 = (1 - cs) / 2, a0 = 1 + al, a1 = -2 * cs, a2 = 1 - al;
    b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
    var y = new Float32Array(x.length), x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (var i = 0; i < x.length; i++) {
      var v = b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
      x2 = x1; x1 = x[i]; y2 = y1; y1 = v; y[i] = v;
    }
    return y;
  }

  // sensitivity 0..100 → beat times in seconds (relative to the decoded start)
  function findBeats(x, sensitivity) {
    var bass = lowpass(lowpass(x, 150), 150);
    var nF = Math.floor(bass.length / HOP), env = new Float32Array(nF), i, j, s;
    for (i = 0; i < nF; i++) {
      s = 0;
      for (j = i * HOP; j < (i + 1) * HOP; j++) s += bass[j] * bass[j];
      env[i] = Math.log(1e-9 + s / HOP);
    }
    // onset strength: how much the bass energy jumps compared to the frames just before
    var on = new Float32Array(nF);
    for (i = 3; i < nF; i++) on[i] = Math.max(0, env[i] - Math.max(env[i - 1], env[i - 2], env[i - 3]));
    // adaptive threshold over ±1 s; higher sensitivity → lower threshold
    var k = 2.6 - (Math.max(0, Math.min(100, sensitivity)) / 100) * 2.2, W = 100, beats = [], last = -1e9, minGap = 0.18;
    var sum = 0, sum2 = 0, cnt = 0, lo = 0, hi = 0;
    for (i = 0; i < nF; i++) {
      while (hi < nF && hi <= i + W) { sum += on[hi]; sum2 += on[hi] * on[hi]; cnt++; hi++; }
      while (lo < i - W) { sum -= on[lo]; sum2 -= on[lo] * on[lo]; cnt--; lo++; }
      var mean = sum / cnt, sd = Math.sqrt(Math.max(0, sum2 / cnt - mean * mean));
      var isPeak = on[i] > 0 && on[i] >= on[i - 1 < 0 ? 0 : i - 1] && on[i] >= (i + 1 < nF ? on[i + 1] : 0);
      if (isPeak && on[i] > mean + k * sd && on[i] > 0.35) {
        var t = i * HOP / SR;
        if (t - last >= minGap) { beats.push(t); last = t; }
      }
    }
    return beats;
  }

  E.beats = function (ff, file, a, dur, sensitivity, job) {
    return decode(ff, file, a, dur, job).then(function (x) { return findBeats(x, sensitivity); });
  };
  E._findBeats = findBeats; E._SR = SR;
})();

/* ───────── fluid motion: RIFE makes new frames between the frames of a clip.
   ffmpeg decodes the clip as a stream of PNGs, cut into short chunks on disk (disk use stays small),
   RIFE interpolates each chunk on the graphics card, and the new frames stream into a ProRes encoder. */
(function () {
  'use strict';
  var E = window.MZE;
  if (!E || !E.NODE) return;
  var fs = E.fs, path = E.path;
  E.PACKS.rife = { label: 'محرك الحركة الناعمة', url: 'https://github.com/nihui/rife-ncnn-vulkan/releases/download/20221029/rife-ncnn-vulkan-20221029-windows.zip', zip: true, exe: 'rife-ncnn-vulkan.exe', mb: 430 };

  // splits a stream of concatenated JPEG files (ffmpeg's mjpeg: no embedded thumbnails, so FFD9 only ends an image)
  function JpegSplitter(onJpg) {
    var buf = Buffer.alloc(0), scan = 2;
    this.push = function (chunk) {
      buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
      for (;;) {
        var e = -1;
        for (var i = Math.max(2, scan); i < buf.length - 1; i++) if (buf[i] === 0xFF && buf[i + 1] === 0xD9) { e = i + 2; break; }
        if (e < 0) { scan = Math.max(2, buf.length - 1); return; }
        onJpg(buf.subarray(0, e));
        buf = buf.subarray(e); scan = 2;
      }
    };
  }

  function listFrames(dir) { return fs.readdirSync(dir).filter(function (n) { return /\.jpg$/i.test(n); }).sort(); }
  function writeAll(stream, data) {
    return new Promise(function (res, rej) {
      if (stream.destroyed) return rej(new Error('encoder closed'));
      if (stream.write(data)) return res();
      function ok() { stream.removeListener('error', bad); res(); }
      function bad(e) { stream.removeListener('drain', ok); rej(e); }
      stream.once('drain', ok);
      stream.once('error', bad);
    });
  }

  // o: {ff, rife, src, a, dur, fps, mode: 'blur'|'frames'|'slow', k, blur, out}
  // Frames travel as top-quality JPEG (4:4:4, q2): several times faster than PNG at 1080p.
  // While RIFE works on one chunk, the frames of the previous chunk are being encoded.
  E.fluid = function (o, onProgress, job) {
    var cp = E.cp, CH = 40;
    var K = o.mode === 'blur' ? 8 : o.k;
    var total = Math.max(1, Math.round(o.dur * o.fps));
    var work = E.tmpFile('_fluid'); fs.mkdirSync(work);
    var vf = [];
    var encRate = o.mode === 'slow' ? o.fps : o.fps * K;
    if (o.mode === 'blur') vf.push('tmix=frames=' + Math.max(2, Math.min(8, o.blur)), 'fps=' + o.fps);
    var encArgs = ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'image2pipe', '-c:v', 'mjpeg', '-framerate', String(encRate), '-i', '-']
      .concat(vf.length ? ['-vf', vf.join(',')] : [])
      .concat(o.mode === 'blur' ? ['-r', String(o.fps)] : [])
      .concat(['-c:v', 'prores_ks', '-profile:v', '3', '-pix_fmt', 'yuv422p10le', '-vendor', 'apl0', o.out]);
    E.log('fluid', JSON.stringify(o));
    var enc = cp.spawn(o.ff, encArgs, { windowsHide: true });
    var encErr = ''; enc.stderr.on('data', function (b) { encErr += b; });
    var encDone = new Promise(function (res) { enc.on('close', function (c) { res(c); }); });
    var dec = cp.spawn(o.ff, ['-hide_banner', '-loglevel', 'error', '-ss', o.a.toFixed(4), '-i', o.src, '-t', o.dur.toFixed(4), '-an', '-sn',
      '-vf', 'fps=' + o.fps + ',format=yuvj444p', '-c:v', 'mjpeg', '-q:v', '2', '-f', 'image2pipe', '-'], { windowsHide: true });
    var decErr = ''; dec.stderr.on('data', function (b) { decErr += b; });
    if (job) job.procs = [enc, dec];

    var frames = [], decEnded = false, chunkNo = 0, doneFrames = 0, busy = false, failed = null, finishing = false;
    var outQ = [], writing = false, resolveAll, rejectAll;
    var finished = new Promise(function (res, rej) { resolveAll = res; rejectAll = rej; });
    function fail(e) { if (failed) return; failed = e; try { dec.kill(); } catch (x) {} try { enc.kill(); } catch (x) {} rejectAll(e); }

    var splitter = new JpegSplitter(function (jpg) {
      frames.push(jpg);
      if (frames.length >= CH + 1) dec.stdout.pause();
      pump();
    });
    dec.stdout.on('data', function (b) { splitter.push(b); });
    dec.on('close', function (code) {
      decEnded = true;
      if (code !== 0 && !(job && job.cancelled)) E.log('fluid decode exit', code, decErr.slice(-2000));
      pump();
    });

    // the encoder side: chunks of finished frames, strictly in order
    function drain() {
      if (writing || failed) return;
      if (!outQ.length) { if (finishing && !busy) finish(); return; }
      writing = true;
      var item = outQ.shift(), seq = Promise.resolve();
      item.bufs.forEach(function (b) { seq = seq.then(function () { return writeAll(enc.stdin, b); }); });
      item.files.forEach(function (f) { seq = seq.then(function () { return writeAll(enc.stdin, fs.readFileSync(f)); }); });
      seq.then(function () {
        item.dirs.forEach(E.rmrf);
        doneFrames += item.src;
        if (onProgress) onProgress(Math.min(99, Math.round(doneFrames / total * 100)));
        writing = false;
        drain(); pump();
      }).catch(fail);
    }

    function runChunk(list, isLast) {
      if (list.length === 1) {                      // a lone last frame: nothing to interpolate with
        var reps = []; for (var r1 = 0; r1 < K; r1++) reps.push(list[0]);
        return Promise.resolve({ bufs: reps, files: [], dirs: [], src: 1 });
      }
      var n = chunkNo++, dirIn = path.join(work, 'in' + n), dirOut = path.join(work, 'out' + n);
      fs.mkdirSync(dirIn); fs.mkdirSync(dirOut);
      list.forEach(function (jpg, i) { fs.writeFileSync(path.join(dirIn, ('0000000' + (i + 1)).slice(-8) + '.jpg'), jpg); });
      var target = list.length * K, keep = isLast ? target : (list.length - 1) * K;
      var args = ['-i', dirIn, '-o', dirOut, '-n', String(target), '-m', path.join(path.dirname(o.rife), 'rife-v4.6'), '-f', '%08d.jpg', '-j', '2:2:4'];
      return E.run(o.rife, args, null, job).then(function (r) {
        if (job && job.cancelled) throw new Error('CANCELLED');
        var outs = listFrames(dirOut);
        if (r.code !== 0 || outs.length < keep) throw new Error('RIFE failed (' + r.code + ') ' + String(r.err || '').slice(-300));
        E.rmrf(dirIn);
        return { bufs: [], files: outs.slice(0, keep).map(function (f) { return path.join(dirOut, f); }), dirs: [dirOut], src: isLast ? list.length : list.length - 1 };
      });
    }

    function pump() {
      if (busy || failed || outQ.length > 1) return;   // at most two finished chunks wait on disk
      if (job && job.cancelled) return fail(new Error('CANCELLED'));
      var ready = frames.length >= CH + 1, last = decEnded && frames.length > 0;
      if (!ready && !last) { if (decEnded && !frames.length) { finishing = true; drain(); } return; }
      var isLast = !ready;
      var list = isLast ? frames.splice(0, frames.length) : frames.slice(0, CH + 1);
      if (!isLast) frames.splice(0, CH);           // the overlap frame starts the next chunk
      busy = true;
      if (!decEnded) dec.stdout.resume();
      runChunk(list, isLast).then(function (item) {
        busy = false;
        outQ.push(item);
        if (isLast) finishing = true;
        drain();
        if (!isLast) pump();
      }).catch(fail);
    }
    var finishedOnce = false;
    function finish() {
      if (failed || finishedOnce) return;
      finishedOnce = true;
      enc.stdin.end();
      encDone.then(function (code) {
        E.rmrf(work);
        if (code !== 0) return fail(new Error('encode failed: ' + encErr.slice(-400)));
        resolveAll({ out: o.out, frames: doneFrames });
      });
    }
    return finished.catch(function (e) { E.rmrf(work); try { fs.unlinkSync(o.out); } catch (x) {} throw e; });
  };
  E._JpegSplitter = JpegSplitter;
})();
