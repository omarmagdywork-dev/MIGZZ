/* MIGZZ — loads the panel scripts in order, always fresh (the panel's browser keeps old copies otherwise). */
(function () {
  var v = Date.now();
  var css = document.querySelector('link[href^="css/panel.css"]'); if (css) css.href = 'css/panel.css?v=' + v;
  ['engine', 'app', 'motion', 'more', 'ai', 'pr', 'mogrt', 'extra', 'track', 'update'].forEach(function (n) {
    document.write('<script src="js/' + n + '.js?v=' + v + '"><\/script>');
  });
})();
