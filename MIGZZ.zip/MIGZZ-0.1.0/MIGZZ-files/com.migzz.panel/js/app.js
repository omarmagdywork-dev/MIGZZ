/* MIGZZ — panel (CEP). Runs inside After Effects or Premiere Pro; in a plain browser it opens in preview mode. */
(function () {
  'use strict';

  var VERSION = '0.1.0';
  var CEP = !!window.__adobe_cep__;
  var HOST = 'ae';
  if (CEP) {
    try { HOST = JSON.parse(window.__adobe_cep__.getHostEnvironment()).appName === 'PPRO' ? 'pr' : 'ae'; } catch (e) { HOST = 'ae'; }
  } else if (/[?&]host=pr/.test(location.search)) HOST = 'pr';

  // ───────── host bridge
  function extPath() {
    var p = decodeURI(window.__adobe_cep__.getSystemPath('extension'));
    return p.replace(/^file:\/\/\/?/, '').replace(/\\/g, '/');
  }
  function evalRaw(code) {
    return new Promise(function (resolve) { window.__adobe_cep__.evalScript(code, function (r) { resolve(r); }); });
  }
  function call(fn) {
    var args = Array.prototype.slice.call(arguments, 1);
    if (!CEP) return Promise.resolve({ ok: false, code: 'PREVIEW' });
    var code = fn + '(' + args.map(function (a) {
      // ExtendScript gets plain ASCII: every other character travels as \uXXXX
      return JSON.stringify(a).replace(/[\u007f-\uffff]/g, function (ch) { return '\\u' + ('000' + ch.charCodeAt(0).toString(16)).slice(-4); });
    }).join(',') + ')';
    return evalRaw(code).then(function (r) {
      try { return JSON.parse(r); } catch (e) { return { ok: false, code: 'EXC', error: r || 'Script error' }; }
    });
  }
  // the host side is split in several files; all of them are loaded in order
  // each file ends by setting MZ_FILE_<name> = 1, so a file that failed half-way is caught too
  var JSX = HOST === 'pr' ? ['pr'] : ['ae', 'ae_motion', 'ae_more', 'ae_extra'];
  var hostReady = CEP
    // top level on purpose: $.evalFile inside a function defines the functions in that function only
    ? evalRaw('var MZ_BAD=[];' + JSX.map(function (f) {
        return 'try{MZ_FILE_' + f + '=0;$.evalFile(new File(' + JSON.stringify(extPath() + '/jsx/' + f + '.jsx') + '));if(MZ_FILE_' + f + '!==1)MZ_BAD.push("' + f + '");}catch(e){MZ_BAD.push("' + f + ': "+e+" (line "+e.line+")");}';
      }).join('') + 'MZ_BAD.length?MZ_BAD.join(" · "):"loaded";')
    : Promise.resolve('preview');

  // ───────── icons (one stroke path each)
  var I = {
    motion: 'M4 19C10 19 9 5 20 5M3 19h2M19 5h2', ai: 'M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2zM19 15l1 2 2 1-2 1-1 2-1-2-2-1 2-1z',
    d3: 'M12 2l9 5v10l-9 5-9-5V7zM3 7l9 5 9-5M12 12v10', layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5M3 17l9 5 9-5',
    edit: 'M6 6a3 3 0 1 0 0.01 0M6 18a3 3 0 1 0 0.01 0M8.5 7.5L20 18M8.5 16.5L20 6', lib: 'M6 3h12v18l-6-4-6 4z',
    tools: 'M14 7a4 4 0 0 0 5 5l-9 9-3-3 9-9a4 4 0 0 1-2-2zM5 5l3 3',
    curves: 'M4 19C10 19 9 5 20 5M3 19h2M19 5h2', bounce: 'M15 3a3 3 0 1 0 0.01 0M3 20h18M5 17c2-6 4-6 6 0',
    textAnim: 'M5 19l5-14 5 14M7 14h6M17 9h4M18 13h3', speed: 'M12 14l4-4M3 14a9 9 0 0 1 18 0M3 18h18',
    style: 'M7 3h10v6H7zM12 9v4M9 13h6l-1 8h-4z', captions: 'M3 5h18v14H3zM7 12h6M7 15h10',
    mask: 'M12 4a3.5 3.5 0 1 0 0.01 0M5 20c1-4 4-6 7-6s6 2 7 6', voice: 'M9 3h6v11H9zM5 11a7 7 0 0 0 14 0M12 18v3',
    beat: 'M4 10v4M8 6v12M12 9v6M16 4v16M20 10v4', fluid: 'M3 8c3-3 6 3 9 0s6 3 9 0M3 14c3-3 6 3 9 0s6 3 9 0',
    face: 'M12 3.5a8.5 8.5 0 1 0 0.01 0M9 10h.01M15 10h.01M8.5 14.5c2 2 5 2 7 0', track: 'M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M12 9a3 3 0 1 0 0.01 0',
    relight: 'M12 8a4 4 0 1 0 0.01 0M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2',
    to3d: 'M12 2l9 5v10l-9 5-9-5V7zM3 7l9 5 9-5M12 12v10', models: 'M7 3l4 2v4l-4 2-4-2V5zM17 3l4 2v4l-4 2-4-2V5zM12 13l4 2v4l-4 2-4-2v-4z',
    silence: 'M3 12h4l2-5 3 10 2-5h1M17 9l4 6M21 9l-4 6', podcast: 'M3 6h8v6H3zM13 6h8v6h-8zM8 16h8M12 12v4',
    precomp: 'M3 5h18v14H3zM7 9h10v6H7z', precompEach: 'M3 4h7v7H3zM14 4h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
    decomp: 'M3 3h12v12H3zM13 13l8 8M21 15v6h-6', fx: 'M8 8h12v12H8zM16 8V4H4v12h4',
    anchor: 'M12 4a8 8 0 1 0 0.01 0M12 2v6M12 16v6M2 12h6M16 12h6', newLayer: 'M12 5v14M5 12h14',
    dup: 'M3 3h12v12H3zM9 9h12v12H9z', presets: 'M6 3h12v18l-6-4-6 4z', render: 'M3 5h18v14H3zM10 9l5 3-5 3z',
    paste: 'M3 4h18v16H3zM21 16l-5-5-9 9M9 8a2 2 0 1 0 0.01 0',
    link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
    safe: 'M7 2h10v20H7zM9.5 6h5v10h-5z', organize: 'M3 6h6l2 2h10v11H3zM7 13h10', back: 'M9 6l6 6-6 6'
  };
  function svg(d, color, size) {
    return '<svg width="' + (size || 20) + '" height="' + (size || 20) + '" viewBox="0 0 24 24" fill="none" stroke="' + (color || '#F5A524') + '" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + d + '"/></svg>';
  }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  // ───────── content
  var LOCAL = 'بيشتغل على جهازك من غير نت';
  var IN = HOST === 'pr' ? 'جوه بريمير' : 'جوه الافتر';
  var SECTIONS = {
    motion: { label: 'تحريك', title: 'التحريك', sub: 'كل اللي يخلي الحركة ناعمة واحترافية', d: 'أدوات بتتحكم في شكل الحركة نفسها: نعومتها، سرعتها، وظهور النصوص واللوجوهات.', h: 'حدد الكليب أو الكيفريمز، واختار الأداة.\nكل أداة بتوريك معاينة قبل ما تطبق.', where: IN },
    ai: { label: 'AI', title: 'الذكاء الاصطناعي', sub: 'شغال على جهازك، من غير نت ومن غير حدود', d: 'أدوات بتشتغل بموديلات AI على جهازك نفسه. ملفاتك مش بتترفع على أي مكان، ومفيش حسابات أو مفاتيح تعملها.', h: 'أول مرة تستخدم أي أداة، بتنزّل الموديل بتاعها مرة واحدة.\nبعد كده تشتغل حتى لو النت فاصل.', where: LOCAL },
    d3: { label: '3D', title: '3D', sub: 'حوّل أي صورة لموديل 3D حقيقي', d: 'بتحوّل صورة لأي حاجة لموديل 3D كامل بالتكستشر والخامات، مش لايرز مرصوصة ورا بعض.', h: 'البلوجن بيكشف كارت الشاشة ويختار الموديل المناسب.\nحتى لو الكارت ضعيف بيشتغل، بس بياخد وقت أطول.', where: LOCAL },
    layers: { label: 'لايرز', title: 'اللايرز', sub: 'اختصارات بتوفر وقت كل يوم', d: 'أوامر سريعة للشغل اليومي في التايملاين: بريكومب، إيفكتات، لايرز جديدة، ونقطة الارتكاز.', h: 'حدد اللايرز ودوس على الأمر.\nأي خطوة ترجعها بـ Ctrl+Z مرة واحدة.', where: IN },
    edit: { label: 'مونتاج', title: 'المونتاج', sub: 'أدوات بتختصر ساعات من التقطيع', d: 'أدوات بتعمل التقطيع اللي بياخد وقت: بتشيل السكتات من الكلام، وبتعمل مونتاج البودكاست بين الكاميرات لوحدها.', h: 'حدد السيكوانس أو الكليبات، واختار الأداة.\nبتشوف النتيجة قبل ما تتطبق.', where: LOCAL },
    lib: { label: 'مكتبتي', title: 'مكتبتي', sub: 'حركاتك وإيفكتاتك محفوظة في فولدرات', d: 'مكانك الخاص تحفظ فيه إيفكتات أو حركات أو ستايلات وتستخدمها في أي مشروع.', h: 'حدد اللي عايز تحفظه، ودوس احفظ.\nتقدر تصدّرها وتنقلها لأي جهاز تاني.', where: IN },
    tools: { label: 'أدوات', title: 'أدوات', sub: HOST === 'pr' ? 'استيراد وتنظيم ومقاسات السوشيال' : 'ريندر واستيراد وتنظيم', d: 'حاجات بتوفر وقت برا التعديل نفسه: جلب صور وفيديوهات، تنظيم المشروع، ومساعدة في مقاسات السوشيال.', h: 'دوس على علامة التعجب جنب أي أداة تعرف تفاصيلها.', where: IN }
  };
  // run: {fn} = runs directly · {page} = opens a tool page · none = not built yet
  var TOOLS = {
    motion: [
      { k: 'curves', on: 'ae', name: 'منحنيات الحركة', sub: 'تتحكم في نعومة وسرعة الحركة بين الكيفريمز', d: 'بترسم شكل الحركة بإيدك على جراف القيمة وجراف السرعة، أو تختار من أكتر من 30 منحنى جاهز. وتقدر تقرا منحنى أي كيفريمز معمولة قبل كده وتحفظه.', h: 'حدد كيفريمين أو أكتر.\nاختار منحنى جاهز أو اسحب المقابض.\nدوس طبّق.', where: IN },
      { k: 'bounce', on: 'ae', name: 'حركات ظهور بارتداد', sub: 'النص أو اللوجو يظهر بنطة أو زنبرك', d: 'النص أو اللوجو بيظهر بحركة فيها ارتداد: نطة، سقوط، زحلقة، لف، أو جيلي. بتشوف المعاينة لايف، وبعد التطبيق تظبطها بسلايدرز.', h: 'حدد النص أو اللوجو.\nاختار الحركة وظبط المدة والقوة.\nدوس طبّق.', where: IN },
      { k: 'textAnim', on: 'ae', name: 'أنيميشن النصوص', sub: 'دخول وخروج للنص حرف حرف أو كلمة كلمة', d: 'أكتر من 20 حركة جاهزة لدخول وخروج النص، أو حركة مستمرة. تشتغل حرف حرف، أو كلمة كلمة، أو سطر سطر، وبتدعم العربي من اليمين للشمال.', h: 'حدد النص.\nاختار الحركة وشوف المعاينة.\nدوس ضيف.', where: IN },
      { k: 'speed', on: 'ae', name: 'تسريع وتبطيء الفيديو', sub: 'الكليب يسرع ويبطأ بمنحنى ناعم', d: 'بتخلي الكليب يسرع ويبطأ في نفس الحركة (Speed Ramp)، بمنحنى ناعم من غير تقطيع، وفيه بريسيتس جاهزة زي لقطات العربيات.', h: 'حدد الكليب.\nاختار بريسيت أو ظبط البداية والنص والنهاية.\nدوس طبّق.', where: IN },
      { k: 'style', on: 'ae', run: { page: 'style' }, runOn: 'ae', name: 'نسخ الشكل والحركة', sub: 'تنقل شكل وحركة لير للايرز تانية', d: 'بتنسخ كل حاجة في لير: الإيفكتات والكيفريمز والترانسفورم، وتحطها على لايرز تانية مرة واحدة.', h: 'حدد اللير اللي عاجبك ودوس انسخ.\nحدد اللايرز التانية ودوس الصق.', where: IN }
    ],
    ai: [
      { k: 'captions', on: 'both', run: { page: 'captions' }, name: 'كابشن تلقائي', sub: 'الكلام يتحول لكابشن بالعربي المصري والإنجليزي', d: 'بيسمع الصوت ويكتبه كابشن متقسم على الكلام بالظبط. بيفهم العربي المصري والإنجليزي، وبتظبط ستايل واحد (فونت، حجم، جلو) وكل الكابشنز تاخده. وتقدر تصدّرهم ملف SRT.', h: 'حدد الكليب اللي فيه كلام.\nاعمل الستايل اللي يعجبك.\nدوس كابشن تلقائي.', where: LOCAL },
      { k: 'mask', on: 'both', name: 'قص الشخص من الفيديو', sub: 'يفصل الشخص عن الخلفية فريم بفريم', d: 'بيفصل الشخص عن الخلفية في كل فريم من غير روتو. لو فاته جزء، بتصلحه بالفرشاة على فريم واحد وهو بيكمل على باقي الفريمات.', h: 'حدد الفيديو.\nاختار الجودة، وكل الناس ولا شخص واحد.\nدوس قص.', where: LOCAL },
      { k: 'voice', on: 'both', name: 'فصل الصوت عن المزيكا', sub: 'الكلام في تراك والمزيكا والدوشة في تراك', d: 'بيفصل صوت الكلام عن المزيكا والدوشة في تراكين منفصلين، وكل واحد له الفوليوم بتاعه.', h: 'حدد الكليب.\nدوس افصل الصوت.', where: LOCAL },
      { k: 'beat', on: 'both', run: { page: 'beat' }, name: 'قص على إيقاع المزيكا', sub: 'علامات على كل ضربة في المزيكا', d: 'بيسمع المزيكا ويحط علامة على كل ضربة (الكيك والباص). بعدها تقدر تقطع الكليبات أو ترصها على الضربات أوتوماتيك.', h: 'حدد المزيكا.\nظبط الحساسية (علامات أكتر أو أقل).\nدوس حط العلامات، وبعدين قص أو رص.', where: LOCAL },
      { k: 'fluid', on: 'both', run: { page: 'fluid' }, name: 'حركة ناعمة وسلو موشن', sub: 'موشن بلر سينمائي أو سلو موشن ناعم', d: 'الـ AI بيعمل فريمات جديدة بين الفريمات الموجودة. تطلع منها موشن بلر زي الكاميرا السينما، أو فيديو 60 و120 فريم، أو سلو موشن 2x و4x و8x من غير تقطيع.', h: 'حدد الفيديو.\nاختار النوع.\nالنتيجة بتنزل كليب جديد فوق الأصلي.', where: LOCAL },
      { k: 'face', on: 'ae', name: 'تتبع الوش', sub: 'نص أو صورة تمشي مع وش الشخص', d: 'بيخلي نص أو صورة تمشي مع وش الشخص، حتى لو لف راسه يمين وشمال أو فوق وتحت.', h: 'حدد الفيديو.\nاختار تضيف نص أو صورة ومكانها.\nدوس تتبع.', where: LOCAL },
      { k: 'track', on: 'pr', name: 'تتبع الحركة', sub: 'أي حاجة تمشي مع حاجة بتتحرك في الفيديو', d: 'بتحدد أي حاجة في الفيديو (عربية، منتج، إيد)، والـ AI بيتتبعها فريم بفريم ويخلي نص أو جرافيك يمشي معاها.', h: 'حدد الفيديو.\nارسم مربع حوالين الحاجة اللي عايز تتتبعها.\nاختار النص أو الجرافيك ودوس تتبع.', where: LOCAL },
      { k: 'relight', on: 'ae', name: 'إضاءة بعد التصوير', sub: 'تضيف نور على الشخص أو المنتج', d: 'بتحط نقط إضاءة على الشخص أو المنتج، تحركها وتغير لونها وقوتها، وتعمل عليها كيفريمز لفلاش مثلًا.', h: 'حدد اللير.\nدوس ضيف إضاءة واسحبها في المعاينة.', where: IN }
    ],
    d3: [
      { k: 'to3d', on: 'ae', name: 'صورة لموديل 3D', sub: 'موديل حقيقي بالتكستشر يدخل الافتر', d: 'بتديله صورة لأي حاجة (منتج، لوجو، شخصية، عربية) فيطلعلك موديل 3D حقيقي بالتكستشر والخامات، ويدخل الافتر جاهز تلف الكاميرا حواليه.', h: 'اختار صورة الحاجة على خلفية بسيطة.\nالبلوجن بيختار الموديل المناسب لكارت الشاشة بتاعك.\nدوس حوّل لـ 3D.', where: LOCAL },
      { k: 'models', on: 'ae', name: 'موديلاتي', sub: 'كل الموديلات اللي عملتها قبل كده', d: 'كل الموديلات اللي عملتها محفوظة هنا، تحطها في أي كومب تاني من غير ما تعملها من الأول.', h: 'دوس على أي موديل يدخل الكومب.', where: IN }
    ],
    layers: [
      { k: 'precomp', on: 'ae', run: { fn: 'mz_precompose' }, name: 'تجميع في بريكومب', sub: 'اللايرز المحددة في بريكومب واحد', d: 'بيجمع اللايرز المحددة في بريكومب واحد، وبيحافظ على مكانها وتوقيتها.', h: 'حدد اللايرز ودوس.', where: IN },
      { k: 'precompEach', on: 'ae', run: { fn: 'mz_precomposeEach' }, name: 'بريكومب لكل لير', sub: 'كل لير في بريكومب لوحدها', d: 'كل لير محددة بتدخل بريكومب لوحدها. مفيد لما يبقى عندك صور أو كليبات كتير.', h: 'حدد اللايرز ودوس.', where: IN },
      { k: 'decomp', on: 'ae', run: { fn: 'mz_decompose' }, name: 'فك البريكومب', sub: 'يرجّع اللايرز للكومب الأصلي', d: 'بيطلّع اللايرز من جوه البريكومب ويرجعها للكومب الأصلي بنفس مكانها وتوقيتها. لو البريكومب نفسه متحرك أو متعدل، الأداة بتقولك بدل ما تبوّظ الشكل.', h: 'حدد البريكومب ودوس.', where: IN },
      { k: 'fx', on: 'ae', run: { page: 'fx' }, name: 'نسخ ولصق الإيفكتات', sub: 'تنقل الإيفكتات من لير للايرز كتير', d: 'بينسخ كل الإيفكتات من لير بإعداداتها وحركتها، ويلصقها على لير واحدة أو لايرز كتير مرة واحدة. ولو حددت إيفكتات معينة في Effect Controls، بينسخ دول بس.', h: 'حدد اللير ودوس انسخ.\nحدد اللايرز التانية ودوس الصق.', where: IN },
      { k: 'anchor', on: 'ae', run: { page: 'anchor' }, name: 'تحريك نقطة الارتكاز', sub: 'للركن أو للنص من غير ما اللير تتحرك', d: 'بينقل نقطة الارتكاز (Anchor Point) لأي ركن أو للنص، واللير نفسها مش بتتحرك من مكانها.', h: 'حدد اللير، واختار المكان من الشبكة.', where: IN },
      { k: 'newLayer', on: 'ae', run: { page: 'newLayer' }, name: 'لايرز جديدة', sub: 'نص، نل، سوليد، أدجستمنت، كاميرا، إضاءة', d: 'بيعمل أي لير جديدة بضغطة: نص في نص الكومب، أو نل، أو سوليد بلونك، أو أدجستمنت، أو كاميرا، أو إضاءة، فوق اللير المحددة.', h: 'دوس، واختار نوع اللير.', where: IN },
      { k: 'dup', on: 'ae', run: { fn: 'mz_duplicateIndependent' }, name: 'نسخة مستقلة', sub: 'تكرار بريكومب من غير ما الأصل يتأثر', d: 'بيكرر اللير أو البريكومب كنسخة مستقلة بالكامل، تعدل فيها والأصل ميتأثرش.', h: 'حدد ودوس.', where: IN }
    ],
    edit: [
      { k: 'silence', on: 'pr', name: 'قص السكتات', sub: 'يشيل السكتات من الكلام في كل التراكات', d: 'بيسمع الكلام ويشيل السكتات والوقفات الطويلة من كل التراكات مع بعض، والصورة والصوت يفضلوا متزامنين.', h: 'حدد الكليبات أو السيكوانس.\nظبط طول السكتة اللي تتشال.\nشوف المعاينة، ودوس اقطع.', where: LOCAL },
      { k: 'podcast', on: 'pr', name: 'مونتاج البودكاست', sub: 'يقلب بين الكاميرات حسب مين بيتكلم', d: 'لو كل متكلم ليه مايك، البلوجن بيعرف مين بيتكلم في كل لحظة، ويقلب بين الكاميرات لوحده، بأشكال جاهزة للريلز ويوتيوب.', h: 'حدد الكاميرات والمايكات.\nاربط كل متكلم بالكاميرا بتاعته.\nاختار الشكل، ودوس وزّع.', where: LOCAL }
    ],
    lib: [
      { k: 'presets', on: 'ae', name: 'البريسيتس بتاعتي', sub: 'احفظ واستخدم حركاتك وإيفكتاتك', d: 'بتحفظ إيفكتات أو حركات أو ستايلات نص في فولدرات، وتطبقها في أي مشروع بضغطة. ومحفوظة على جهازك.', h: 'حدد اللي عايز تحفظه.\nدوس احفظ وسمّيه.\nدوسة واحدة تطبقه بعد كده.', where: IN }
    ],
    tools: [
      { k: 'render', on: 'ae', run: { page: 'render' }, runOn: 'ae', name: 'ريندر في الخلفية', sub: 'MP4 وإنت كمل شغل عادي', d: 'بيرندر الكومب MP4 في الخلفية، وإنت كمل شغل في الافتر عادي.', h: 'اختار الجزء والجودة ومكان الحفظ.\nدوس ريندر.', where: IN },
      { k: 'paste', on: 'both', run: { act: 'paste' }, name: 'لصق صورة من النت', sub: 'انسخ من جوجل أو بنترست والصق', d: 'انسخ أي صورة من المتصفح، ودوس هنا تلاقيها في التايملاين على طول.', h: 'كليك يمين على الصورة ← نسخ الصورة.\nارجع للبرنامج ودوس الصق.', where: IN },
      { k: 'link', on: 'both', name: 'استيراد من لينك', sub: 'فيديو أو صورة أو صوت من أي لينك', d: 'حط لينك من تيك توك أو يوتيوب أو إنستجرام أو بنترست أو X، واختار تنزله فيديو أو صورة أو صوت بس، ويدخل التايملاين على طول.', h: 'الصق اللينك.\nاختار فيديو أو صورة أو صوت.\nدوس استورد.', where: 'محتاج نت' },
      { k: 'safe', on: 'both', run: { page: 'safe' }, name: 'أدلة السوشيال', sub: 'المناطق الآمنة لريلز وتيك توك وشورتس', d: 'بيحط فوق الفيديو دليل بيوريك الأماكن اللي أزرار التطبيق والكابشن هتغطيها في كل منصة، علشان الكلام والوشوش ميتغطوش. الدليل مش بيظهر في الريندر.', h: 'اختار المنصة.\nالدليل بيظهر فوق الفيديو.\nدوس تاني يختفي.', where: IN },
      { k: 'organize', on: 'both', run: { page: 'organize' }, name: 'تنظيم المشروع', sub: 'يرتب ملفات المشروع في فولدرات', d: 'بيرتب ملفات المشروع في فولدرات: فيديو، صور، صوت، سيكوانسز أو كومبوزيشنز، جرافيك. بتشوف الترتيب قبل ما يتنفذ.', h: 'دوس عاين الترتيب.\nلو عاجبك دوس نظّم.', where: IN }
    ]
  };
  var ORDER = HOST === 'pr' ? ['motion', 'ai', 'edit', 'tools'] : ['motion', 'ai', 'd3', 'layers', 'lib', 'tools'];
  function fits(t) { return t.on === 'both' || t.on === HOST; }

  var ERR = {
    NO_COMP: 'افتح كومب الأول', NO_SEQ: 'افتح سيكوانس الأول', NO_TRACK: 'مفيش تراك فاضي فوق الكليب: ضيف تراك وجرب تاني', PR_OLD: 'نسخة البريمير دي قديمة على الأداة دي (محتاج 2022 أو أحدث)', NO_SEL: 'حدد لير واحدة على الأقل', ONE_LAYER: 'حدد لير واحدة بس',
    NO_FX: 'اللير دي مفيهاش إيفكتات', NOTHING_COPIED: 'انسخ الإيفكتات الأول', SOURCE_GONE: 'اللير اللي نسخت منها اتمسحت، انسخ تاني',
    NO_TARGET: 'حدد لير تانية غير اللي نسخت منها',
    DECOMP_NOT_PRECOMP: 'دي مش بريكومب', DECOMP_SIZE: 'مقاس البريكومب مختلف عن الكومب، فكّه هيغيّر الشكل',
    DECOMP_STRETCH: 'البريكومب متسرّع أو متبطّأ، فكّه هيغيّر التوقيت', DECOMP_TIMEREMAP: 'البريكومب عليه Time Remap',
    DECOMP_THREE_D: 'البريكومب 3D، فكّه هيغيّر الشكل', DECOMP_EFFECTS: 'البريكومب عليه إيفكتات هتضيع لو اتفك',
    DECOMP_MASKS: 'البريكومب عليه ماسكات هتضيع لو اتفك', DECOMP_BLEND: 'البريكومب عليه Blending Mode هيضيع لو اتفك',
    DECOMP_ANIMATED: 'البريكومب نفسه متحرك، فكّه هيبوّظ الحركة', DECOMP_MOVED: 'البريكومب متحرك من مكانه أو متعدل، فكّه هيغيّر الشكل',
    DECOMP_PARENTED: 'البريكومب مربوط بلير تانية',
    ANCHOR_KIND: 'الكاميرا والإضاءة مالهمش نقطة ارتكاز', ANCHOR_ANIMATED: 'اللير عليها نقطة ارتكاز أو سكيل أو روتيشن متحركة، النقل هيحرّكها',
    ANCHOR_3D: 'اللير 3D ومتلففة، النقل هيحرّكها',
    CAP_ONE: 'حدد كليب واحد بس (فيديو أو صوت)', CAP_FOOTAGE: 'حدد فيديو أو ملف صوت (مش بريكومب أو نص)', CAP_NO_AUDIO: 'الكليب ده مفيهوش صوت',
    CAP_STRETCH: 'الكليب متسرّع أو عليه Time Remap، شيلهم الأول', CAP_MISSING: 'ملف الكليب مش موجود على الجهاز', CAP_EMPTY: 'الجزء المختار قصير أوي',
    VID_ONE: 'حدد فيديو واحد بس', VID_FOOTAGE: 'حدد فيديو (مش صورة أو بريكومب أو نص)', FILE_MISSING: 'الملف اللي اتعمل مش موجود',
    STYLE_KIND: 'حدد لير عادية (مش كاميرا أو إضاءة)', RENDER_UNSAVED: 'سيّف المشروع مرة الأول (Ctrl+S) علشان الريندر يشتغل', RENDER_NO_AER: 'مالقيتش aerender جوه فولدر الافتر', NO_PROJECT: 'مفيش مشروع مفتوح',
    CAP_NOTHING: 'مالقيتش كلام', BEAT_NONE: 'حط علامات الضربات الأول', BEAT_SEL: 'حدد الصور أو الكليبات اللي عايزها تمشي على الضربات',
    BEAT_ONE: 'حدد كليب واحد بس علشان يتقطع', BEAT_NONE_IN: 'مفيش ضربات جوه الكليب ده', CAP_GONE: 'الكليب اتمسح من الكومب', PREVIEW: 'ده وضع المعاينة برا البرنامج'
  };
  function errText(r) {
    var m = ERR[r.code] || ('حصل خطأ: ' + (r.error || r.code));
    if (/^DECOMP_/.test(r.code) && r.error) m += ' («' + r.error + '»)';
    return m;
  }

  // ───────── UI state
  var view = document.getElementById('view');
  var tabsEl = document.getElementById('tabs');
  var sheet = document.getElementById('sheet');
  var q = document.getElementById('q');
  var st = { tab: 'layers', page: null, query: '' };
  if (ORDER.indexOf(st.tab) < 0) st.tab = 'ai';

  document.getElementById('hostLabel').textContent = HOST === 'pr' ? 'نسخة Premiere Pro' : 'نسخة After Effects';

  function status(msg, kind) {
    var el = document.getElementById('status');
    el.className = 'status' + (kind ? ' ' + kind : '');
    document.getElementById('stMsg').textContent = msg;
  }

  function renderTabs() {
    tabsEl.style.gridTemplateColumns = 'repeat(' + ORDER.length + ', minmax(0, 1fr))';
    tabsEl.innerHTML = ORDER.map(function (k) {
      return '<button class="tab' + (k === st.tab && !st.query ? ' on' : '') + '" data-tab="' + k + '">' + svg(I[k], null, 19) + '<span>' + SECTIONS[k].label + '</span></button>';
    }).join('');
  }

  function isBuilt(t) { return !!t.run && (!t.runOn || t.runOn === HOST); }

  // ───────── which downloaded parts each tool needs (for the «still downloading» tag)
  var AI_BASE = ['ffmpeg', 'node', 'ortNode', 'ortCommon'];
  var TOOL_PACKS = {
    captions: function () { return ['ffmpeg', prefs.capGpu && gpuName ? 'whisperGpu' : 'whisperCpu', prefs.capModel === 'fast' ? 'speechFast' : 'speechBest']; },
    mask: AI_BASE.concat('mMask'), voice: AI_BASE.concat('mVoice'), face: AI_BASE.concat('mFace'), track: AI_BASE.concat('mFace'),
    cutimg: AI_BASE.concat('mSeg'), to3d: AI_BASE.concat(['mSeg', 'm3dEnc', 'm3dDec']),
    beat: ['ffmpeg'], fluid: ['ffmpeg', 'rife'], link: ['ffmpeg', 'ytdlp'], silence: ['ffmpeg'], podcast: ['ffmpeg'], trans: ['ffmpeg']
  };
  function toolPacks(t) {
    var p = TOOL_PACKS[t.k]; p = typeof p === 'function' ? p() : p;
    return (p || []).filter(function (k) { return window.MZE && MZE.PACKS && MZE.PACKS[k]; });
  }
  // null when the tool is ready; otherwise what to tell the user
  function toolDl(t) {
    if (!window.MZE || !MZE.NODE || !MZE.packState) return null;
    var keys = toolPacks(t), dl = null, wait = 0, err = 0, i, s;
    for (i = 0; i < keys.length; i++) {
      s = MZE.packState(keys[i]);
      if (s.state === 'dl' && !dl) dl = s; else if (s.state === 'wait') wait++; else if (s.state === 'err') err++;
    }
    if (dl) return { cls: 'dl', text: 'بيتحمّل' + (dl.pct ? ' ' + dl.pct + '%' : '') };
    if (err) return { cls: 'dl', text: 'التحميل وقف' };
    if (wait) return { cls: 'dl', text: 'في الطابور' };
    return null;
  }
  function dlTag(t) { var d = toolDl(t); return d ? '<span class="tag ' + d.cls + '">' + d.text + '</span>' : ''; }

  // ───────── the background download bar + its sheet
  var dlLeft = -1;
  function fmtMB(mb) { return mb >= 1000 ? (mb / 1000).toFixed(1) + ' جيجا' : Math.max(1, Math.round(mb)) + ' ميجا'; }
  function dlTick() {
    var bar = document.getElementById('dlbar');
    if (!bar || !window.MZE || !MZE.bgState) return;
    var s = MZE.bgState();
    if (!s.started || !s.total) return;
    if (dlLeft !== s.left) { var first = dlLeft < 0; dlLeft = s.left; if (!first && !st.page) render(); }   // a tool just got ready: refresh its tag
    if (!s.left) { bar.hidden = true; return; }
    bar.hidden = false;
    var errs = s.items.filter(function (i) { return i.state === 'err'; }).length;
    bar.className = 'dlbar' + (s.paused ? ' paused' : errs && !s.cur ? ' err' : '');
    var txt = s.paused ? 'التحميل واقف · دوس هنا تكمّله'
      : s.cur ? 'بيجهّز أدوات الـ AI · ' + s.cur.label + (s.cur.pct ? ' ' + s.cur.pct + '%' : '') + ' · فاضل ' + s.left + ' من ' + s.total
      : errs ? 'النت فصل؟ هيحاول تاني لوحده · فاضل ' + s.left
      : 'بيجهّز أدوات الـ AI · فاضل ' + s.left + ' من ' + s.total;
    document.getElementById('dlText').textContent = txt;
    var done = s.total - s.left + (s.cur && s.cur.pct ? s.cur.pct / 100 : 0);
    document.getElementById('dlFill').style.width = Math.round(done / s.total * 100) + '%';
    if (!sheet.hidden && document.getElementById('dlList')) document.getElementById('dlList').innerHTML = dlRows(s);
  }
  function dlRows(s) {
    return s.items.map(function (i) {
      var t = i.state === 'ok' ? '<span class="st ok">جاهز</span>' : i.state === 'dl' ? '<span class="st">' + (i.other ? 'في البرنامج التاني ' : '') + (i.pct || 0) + '%</span>' : i.state === 'err' ? '<span class="st">هيحاول تاني</span>' : '<span class="st">في الطابور</span>';
      return '<div class="dlrow"><b>' + esc(i.label) + '</b>' + t + '<small>' + fmtMB(i.mb) + '</small></div>';
    }).join('');
  }
  function openDownloads() {
    var s = MZE.bgState();
    sheet.innerHTML = '<div class="sheet" role="dialog" aria-label="تحميل أدوات الـ AI">' +
      '<div class="sheet-top"><b>تحميل أدوات الـ AI</b><button class="iconbtn" data-close aria-label="اقفل">×</button></div>' +
      '<p>أدوات الـ AI بتشتغل على جهازك من غير نت، فمحتاجة موديلات تتحمّل مرة واحدة بس (حوالي ' + fmtMB(s.items.reduce(function (a, i) { return a + i.mb; }, 0)) + '). البلوجن بيحمّلها لوحده في الخلفية وإنت شغال.</p>' +
      '<p class="how">• الأداة اللي عليها «بيتحمّل» أو «في الطابور» هتشتغل أول ما الموديل بتاعها يخلص. لو دوست عليها قبلها، هتستنى وتكمل لوحدها.\n• سيب البانل مفتوح (حتى لو ورا بانل تاني). لو قفلت البرنامج أو النت فصل، التحميل بيكمل من مكانه.\n• لو الافتر وبريمير مفتوحين مع بعض، التحميل بيحصل مرة واحدة بس.</p>' +
      '<div class="dllist" id="dlList">' + dlRows(s) + '</div>' +
      '<div class="row" style="margin-top:10px"><button class="btn" data-x="dlPause">' + (s.paused ? 'كمّل التحميل' : 'وقّف التحميل مؤقتًا') + '</button></div>' +
    '</div>';
    sheet.hidden = false;
  }
  function toolRow(t, secKey) {
    var built = isBuilt(t);
    return '<div class="tool' + (built ? '' : ' soon') + '">' +
      '<button class="main" data-tool="' + secKey + ':' + t.k + '">' +
        '<span class="ticon">' + svg(I[t.k]) + '</span>' +
        '<span class="ttext"><span class="tname">' + esc(t.name) + (built ? dlTag(t) : '<span class="tag dim">قيد البناء</span>') + '</span><span class="tsub">' + esc(t.sub) + '</span></span>' +
      '</button>' +
      '<button class="i" data-info="' + secKey + ':' + t.k + '" aria-label="شرح ' + esc(t.name) + '">!</button>' +
    '</div>';
  }

  function render() {
    renderTabs();
    if (st.page) return renderPage();
    var html = '';
    if (st.query) {
      var ql = st.query.trim();
      var hits = [];
      ORDER.forEach(function (s) { TOOLS[s].filter(fits).forEach(function (t) { if ((t.name + ' ' + t.sub).indexOf(ql) >= 0) hits.push([s, t]); }); });
      html = '<div class="sechead"><div><h2>نتايج البحث</h2><p>' + hits.length + ' أداة</p></div></div><div class="list">' +
        (hits.length ? hits.map(function (h) { return toolRow(h[1], h[0]); }).join('') : '<div class="empty">مفيش أداة بالاسم ده</div>') + '</div>';
    } else {
      var S = SECTIONS[st.tab];
      html = '<div class="sechead"><div><h2>' + S.title + '</h2><p>' + S.sub + '</p></div><button class="info-btn" data-secinfo="' + st.tab + '" aria-label="شرح القسم ده">!</button></div>' +
        '<div class="list">' + TOOLS[st.tab].filter(fits).map(function (t) { return toolRow(t, st.tab); }).join('') + '</div>';
    }
    view.innerHTML = html;
  }

  function findTool(ref) {
    var p = ref.split(':');
    var list = TOOLS[p[0]] || [];
    for (var i = 0; i < list.length; i++) if (list[i].k === p[1]) return list[i];
    return null;
  }

  function openInfo(o) {
    sheet.innerHTML = '<div class="sheet" role="dialog" aria-label="' + esc(o.t) + '">' +
      '<div class="sheet-top"><b>' + esc(o.t) + '</b><button class="iconbtn" data-close aria-label="اقفل">×</button></div>' +
      (o.where ? '<span class="chip">' + esc(o.where) + '</span>' : '') +
      '<span class="k">بتعمل إيه؟</span><p>' + esc(o.d) + '</p>' +
      '<span class="k">إزاي تستخدمها؟</span><p class="how">' + esc(o.h) + '</p>' +
      (o.soon ? '<span class="chip" style="color:#F5A524">الأداة دي لسه بتتبني</span>' : '') +
    '</div>';
    sheet.hidden = false;
  }
  function closeInfo() { sheet.hidden = true; sheet.innerHTML = ''; }

  // ───────── running actions
  var busy = false;
  function run(fn, args, okMsg) {
    if (busy) return Promise.resolve();
    busy = true;
    status('شغال…', 'busy');
    return hostReady.then(function () { return call.apply(null, [fn].concat(args || [])); }).then(function (r) {
      busy = false;
      if (r && r.ok) status(typeof okMsg === 'function' ? okMsg(r) : okMsg);
      else status(errText(r || {}), 'err');
      return r;
    }).catch(function (e) { busy = false; status('حصل خطأ: ' + e.message, 'err'); });
  }

  // ───────── tool pages
  function pageHead(t) {
    return '<div class="page-head"><button class="iconbtn" data-back aria-label="رجوع">' + svg(I.back, '#F2F2F3', 16) + '</button><h2>' + esc(t.name) + '</h2>' +
      '<button class="info-btn" data-info="' + st.page.ref + '" aria-label="شرح ' + esc(t.name) + '">!</button></div>';
  }
  var PAGES = {
    fx: function (t) {
      return pageHead(t) +
        '<div class="card"><span class="label">١. انسخ</span><span class="hint">حدد لير واحدة. لو حددت إيفكتات معينة في Effect Controls، هينسخ دول بس.</span><button class="btn" data-act="copyFx">انسخ الإيفكتات</button></div>' +
        '<div class="card"><span class="label">٢. الصق</span><span class="hint">حدد لير أو أكتر، والإيفكتات هتتحط عليهم بإعداداتها وحركتها.</span><button class="btn primary" data-act="pasteFx">الصق على المحدد</button></div>';
    },
    anchor: function (t) {
      var cells = [['tl', 'فوق شمال'], ['t', 'فوق'], ['tr', 'فوق يمين'], ['l', 'شمال'], ['c', 'النص'], ['r', 'يمين'], ['bl', 'تحت شمال'], ['b', 'تحت'], ['br', 'تحت يمين']];
      return pageHead(t) +
        '<div class="card"><span class="label">دوس على المكان</span><div class="grid3">' +
        cells.map(function (c) { return '<button data-anchor="' + c[0] + '" aria-label="' + c[1] + '" title="' + c[1] + '"><span></span></button>'; }).join('') +
        '</div><span class="hint">بيتطبق على كل اللايرز المحددة، واللير مش بتتحرك من مكانها.</span></div>';
    },
    newLayer: function (t) {
      var k = [['text', 'نص'], ['null', 'نل'], ['solid', 'سوليد'], ['adjust', 'أدجستمنت'], ['camera', 'كاميرا'], ['light', 'إضاءة']];
      return pageHead(t) +
        '<div class="card"><span class="label">نوع اللير</span><div class="kinds">' +
        k.map(function (x) { return '<button class="btn" data-new="' + x[0] + '">' + x[1] + '</button>'; }).join('') +
        '</div><div class="color"><span class="hint">لون السوليد</span><input type="color" id="solidColor" value="#ffffff" aria-label="لون السوليد"></div>' +
        '<span class="hint">اللير الجديدة بتتحط فوق اللير المحددة.</span></div>';
    }
  };
  // ───────── auto captions
  var PREF_KEY = 'migzz.prefs';
  var prefs = { styMotion: true, styFx: true, styBlend: true, orgDeep: false, renWork: false, renQuality: 'best', fluMode: 'blur', fluBlur: 4, fluK: 2, fluSlow: 4, fluWork: true, beatSens: 55, beatComp: false, beatWork: false, beatReplace: true, beatNum: false, capLang: 'ar', capModel: 'best', capWords: 3, capPos: 'bottom', capWork: false, capGpu: true, capPunct: false };
  try { Object.assign(prefs, JSON.parse(localStorage.getItem(PREF_KEY) || '{}')); } catch (e) { /* first run */ }
  function savePrefs() { try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch (e) {} }
  var capJob = null, lastCaps = null, gpuName = null;
  if (window.MZE && MZE.NODE) MZE.hasNvidia().then(function (g) { gpuName = g; if (st.page && st.page.ref === 'ai:captions') render(); });

  function seg(name, value, opts) {
    return '<div class="seg" role="group">' + opts.map(function (o) {
      return '<button class="' + (String(value) === String(o[0]) ? 'on' : '') + '" data-pref="' + name + '" data-val="' + o[0] + '">' + o[1] + '</button>';
    }).join('') + '</div>';
  }
  function sizeNote(key) {
    if (!window.MZE || !MZE.NODE) return '';
    return MZE.installed(key) ? ' · متنزّل' : ' · ' + MZE.PACKS[key].mb + 'MB أول مرة';
  }
  PAGES.captions = function (t) {
    var running = !!capJob;
    return pageHead(t) +
      '<div class="card"><span class="label">اللغة</span>' + seg('capLang', prefs.capLang, [['ar', 'عربي'], ['en', 'English'], ['auto', 'تلقائي']]) +
      '<span class="label">الدقة</span>' + seg('capModel', prefs.capModel, [['fast', 'سريع' + sizeNote('speechFast')], ['best', 'أدق' + sizeNote('speechBest')]]) +
      (gpuName ? '<label class="check"><input type="checkbox" data-pref="capGpu"' + (prefs.capGpu ? ' checked' : '') + '> استخدم كارت الشاشة (أسرع بكتير' + sizeNote('whisperGpu') + ')</label>' : '') +
      '</div>' +
      '<div class="card"><span class="label">عدد الكلمات في كل كابشن: <b id="capWordsVal">' + prefs.capWords + '</b></span>' +
      '<input type="range" min="1" max="8" step="1" value="' + prefs.capWords + '" data-pref="capWords" aria-label="عدد الكلمات">' +
      (HOST === 'pr' ? '' : '<span class="label">مكان الكابشن</span>' + seg('capPos', prefs.capPos, [['bottom', 'تحت'], ['center', 'في النص']])) +
      '<label class="check"><input type="checkbox" data-pref="capWork"' + (prefs.capWork ? ' checked' : '') + '> الجزء بين B و N بس (أسرع في التجربة)</label>' +
      '<label class="check"><input type="checkbox" data-pref="capPunct"' + (prefs.capPunct ? ' checked' : '') + '> سيب علامات الترقيم</label>' +
      '</div>' +
      (HOST === 'pr' ? '<div class="card"><span class="hint">الكابشن بيتحط تراك Captions في السيكوانس. الشكل بتغيّره من Essential Graphics لكل الكابشنز مرة واحدة.</span></div>' :
      '<div class="card"><span class="label">الستايل</span><span class="hint">دوس «اعمل ستايل»، هتلاقي لير اسمها Caption style. غيّر الفونت والحجم والإيفكتات زي ما تحب، وكل الكابشنز هتاخد شكلها. من غيرها هتطلع أبيض بحواف سودا.</span>' +
      '<button class="btn" data-cap="style">اعمل ستايل</button></div>') +
      '<div class="card"><span class="hint">حدد الكليب اللي فيه كلام في التايملاين.</span>' +
      (running ? '<div class="bar"><span id="capBar" style="width:0%"></span></div><button class="btn" data-cap="cancel">إلغاء</button>'
               : '<button class="btn primary" data-cap="go">كابشن تلقائي</button>') +
      (lastCaps && !running ? '<button class="btn" data-cap="srt">صدّر آخر كابشن ملف SRT</button>' : '') +
      '</div>';
  };

  function capProgress(text, pct) {
    status(text, 'busy');
    var b = document.getElementById('capBar');
    if (b && pct !== null && pct !== undefined) b.style.width = Math.max(0, Math.min(100, pct)) + '%';
  }
  function cleanWord(w, keepPunct) {
    w = String(w || '').replace(/�/g, '').trim();
    if (!keepPunct) w = w.replace(/^[.,!?؟،؛:"'«»()\-]+|[.,!?؟،؛:"'«»()\-]+$/g, '');
    return w;
  }
  // words → captions of up to n words; a pause or the end of a sentence starts a new one
  function groupWords(words, n, keepPunct) {
    var out = [], cur = [];
    function flush() {
      if (!cur.length) return;
      var text = cur.map(function (w) { return cleanWord(w.w, keepPunct); }).filter(Boolean).join(' ');
      if (text) out.push({ t: text, s: cur[0].s, e: cur[cur.length - 1].e });
      cur = [];
    }
    words.forEach(function (w) {
      if (cur.length && (cur.length >= n || w.s - cur[cur.length - 1].e > 0.6)) flush();
      cur.push(w);
      if (/[.!?؟]$/.test(w.w.trim())) flush();
    });
    flush();
    for (var i = 0; i < out.length; i++) {
      var nx = out[i + 1];
      if (nx && nx.s - out[i].e < 0.3) out[i].e = nx.s;          // no flicker between close captions
      if (nx && out[i].e > nx.s) out[i].e = nx.s;
      if (out[i].e - out[i].s < 0.15) out[i].e = out[i].s + 0.15;
    }
    return out;
  }
  function srtTime(t) {
    var ms = Math.max(0, Math.round(t * 1000)), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, sec = Math.floor(ms / 1000) % 60;
    function p(x, l) { x = String(x); while (x.length < l) x = '0' + x; return x; }
    return p(h, 2) + ':' + p(m, 2) + ':' + p(sec, 2) + ',' + p(ms % 1000, 3);
  }

  function runCaptions() {
    var E = window.MZE;
    if (!E || !E.NODE) return status('الأداة دي محتاجة تشتغل جوه البرنامج', 'err');
    if (capJob) return;
    var job = capJob = { cancelled: false }, info, ff, wh, model, wav, base, useGpu = false;
    render();
    function stop(msg, kind) { capJob = null; render(); status(msg, kind); }
    hostReady.then(function () { return call('mz_captionInfo', prefs.capWork); }).then(function (r) {
      if (!r.ok) throw { mz: errText(r) };
      info = r;
      useGpu = !!(prefs.capGpu && gpuName);
      return E.ensure('ffmpeg', capProgress, job);
    }).then(function (f) {
      ff = f;
      return E.ensure(useGpu ? 'whisperGpu' : 'whisperCpu', capProgress, job);
    }).then(function (w) {
      wh = w;
      return E.ensure(prefs.capModel === 'fast' ? 'speechFast' : 'speechBest', capProgress, job);
    }).then(function (m) {
      model = m;
      if (job.cancelled) throw new Error('CANCELLED');
      capProgress('بيقرا الصوت من الكليب…', 2);
      wav = E.tmpFile('.wav');
      base = wav.replace(/\.wav$/, '');
      return E.run(ff, ['-hide_banner', '-loglevel', 'error', '-y', '-ss', info.a.toFixed(3), '-t', (info.b - info.a).toFixed(3), '-i', info.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav], null, job);
    }).then(function (r) {
      if (job.cancelled) throw new Error('CANCELLED');
      if (r.code !== 0 || !E.fs.existsSync(wav)) throw { mz: 'مقدرتش أقرا الصوت من الكليب' };
      var threads = String(Math.max(2, Math.min(8, E.os.cpus().length - 1)));
      function whisper(exe) {
        capProgress('بيسمع الكلام… 0%', 0);
        return E.run(exe, ['-m', model, '-f', wav, '-l', prefs.capLang, '-ml', '1', '-sow', '-oj', '-of', base, '-t', threads, '-pp'], function (line) {
          var m = /progress\s*=\s*(\d+)%/.exec(line);
          if (m) capProgress('بيسمع الكلام… ' + m[1] + '%', Number(m[1]));
        }, job);
      }
      return whisper(wh).then(function (res) {
        if (res.code === 0 || job.cancelled || !useGpu) return res;
        E.log('gpu whisper failed, falling back to the processor');
        capProgress('كارت الشاشة ما اشتغلش، بيكمل على المعالج…', 0);
        return E.ensure('whisperCpu', capProgress, job).then(whisper);
      });
    }).then(function (r) {
      if (job.cancelled) throw new Error('CANCELLED');
      if (r.code !== 0 || !E.fs.existsSync(base + '.json')) throw { mz: 'محرك الكلام وقف قبل ما يخلص. ابعتلنا ملف log.txt من فولدر MIGZZ' };
      var j = JSON.parse(E.fs.readFileSync(base + '.json', 'utf8'));
      var words = (j.transcription || []).map(function (sg) {
        return { w: String(sg.text || ''), s: sg.offsets.from / 1000 + info.a, e: sg.offsets.to / 1000 + info.a };
      }).filter(function (w) { var x = w.w.trim(); return x && !/^[\[(].*[\])]$/.test(x); });
      var caps = groupWords(words, Number(prefs.capWords) || 3, prefs.capPunct);
      E.log('captions', words.length + ' words', caps.length + ' captions');
      if (!caps.length) throw { mz: 'مالقيتش كلام في الجزء ده' };
      lastCaps = { caps: caps, start: info.start, name: info.name };
      capProgress('بيحط الكابشن في الكومب…', 100);
      return call('mz_captionsApply', caps, { id: info.id, start: info.start, pos: prefs.capPos });
    }).then(function (r) {
      try { E.rmrf(wav); E.rmrf(base + '.json'); } catch (e) {}
      if (!r.ok) throw { mz: errText(r) };
      stop('اتعمل ' + r.count + ' كابشن');
    }).catch(function (e) {
      try { if (wav) { E.rmrf(wav); E.rmrf(base + '.json'); } } catch (x) {}
      if (e && e.message === 'CANCELLED') return stop('اتلغى');
      if (e && e.mz) return stop(e.mz, 'err');
      E.log('captions failed', e);
      var net = /HTTP|ENOTFOUND|ECONN|timed out|incomplete|EAI_AGAIN/.test(String(e && e.message));
      stop(net ? 'التحميل وقف. اتأكد من النت وجرب تاني' : 'حصل خطأ: ' + (e && e.message ? e.message : e), 'err');
    });
  }
  function cancelCaptions() { cancelJob(capJob); }
  function exportSrt() {
    var E = window.MZE;
    if (!lastCaps || !E || !E.NODE) return;
    var txt = lastCaps.caps.map(function (c, i) {
      return (i + 1) + '\n' + srtTime(c.s + lastCaps.start) + ' --> ' + srtTime(c.e + lastCaps.start) + '\n' + c.t + '\n';
    }).join('\n');
    var dir = E.path.join(E.os.homedir(), 'Downloads', 'MIGZZ');
    try {
      if (!E.fs.existsSync(dir)) E.fs.mkdirSync(dir, { recursive: true });
      var f = E.path.join(dir, (lastCaps.name || 'captions').replace(/[\\/:*?"<>|]/g, '_') + '.srt');
      E.fs.writeFileSync(f, '﻿' + txt, 'utf8');
      status('اتحفظ في Downloads › MIGZZ');
    } catch (e) { status('مقدرتش أحفظ الملف: ' + e.message, 'err'); }
  }

  // ───────── small tools: style copy, safe guides, organize, paste image, render
  PAGES.style = function (t) {
    return pageHead(t) +
      '<div class="card"><span class="label">١. انسخ</span><span class="hint">حدد اللير اللي عاجبك شكلها وحركتها.</span><button class="btn" data-sty="copy">انسخ الشكل والحركة</button></div>' +
      '<div class="card"><span class="label">٢. اختار تنقل إيه</span>' +
      '<label class="check"><input type="checkbox" data-pref="styMotion"' + (prefs.styMotion ? ' checked' : '') + '> الحركة (السكيل والروتيشن والأوباسيتي، والحركة من مكان اللير نفسها)</label>' +
      '<label class="check"><input type="checkbox" data-pref="styFx"' + (prefs.styFx ? ' checked' : '') + '> الإيفكتات</label>' +
      '<label class="check"><input type="checkbox" data-pref="styBlend"' + (prefs.styBlend ? ' checked' : '') + '> الـ Blending Mode والموشن بلر</label>' +
      '<button class="btn primary" data-sty="paste">الصق على المحدد</button></div>';
  };
  PAGES.safe = function (t) {
    return pageHead(t) +
      '<div class="card"><span class="label">المنصة</span><div class="kinds">' +
      '<button class="btn" data-safe="reels">ريلز إنستجرام</button><button class="btn" data-safe="tiktok">تيك توك</button>' +
      '<button class="btn" data-safe="shorts">يوتيوب شورتس</button><button class="btn" data-safe="off">شيل الدليل</button></div>' +
      '<span class="hint">الأحمر = أماكن هتتغطى بأزرار التطبيق والكابشن. الدليل لير Guide: بيظهر وإنت شغال بس، ومش بيطلع في الريندر. دوس على نفس المنصة تاني يختفي. المقاسات تقريبية.</span></div>';
  };
  var orgPlan = null;
  PAGES.organize = function (t) {
    var names = { Comps: 'كومبوزيشنز', Sequences: 'سيكوانسز', Video: 'فيديو', Images: 'صور', Audio: 'صوت', Graphics: 'جرافيك', Other: 'تاني' };
    var rows = orgPlan ? Object.keys(orgPlan.plan).filter(function (k) { return orgPlan.plan[k]; }).map(function (k) {
      return '<div style="display:flex;justify-content:space-between"><span>' + k + ' (' + names[k] + ')</span><b>' + orgPlan.plan[k] + '</b></div>';
    }).join('') : '';
    return pageHead(t) +
      '<div class="card"><label class="check"><input type="checkbox" data-pref="orgDeep"' + (prefs.orgDeep ? ' checked' : '') + '> رتّب كمان الملفات اللي جوه فولدرات</label>' +
      '<button class="btn" data-org="plan">عاين الترتيب</button>' +
      (orgPlan ? (orgPlan.n ? '<span class="label">هيتنقل ' + orgPlan.n + ' ملف:</span>' + rows + '<button class="btn primary" data-org="go">نظّم</button>' : '<span class="hint">المشروع متنظم خلاص.</span>') : '') +
      '</div>';
  };
  var renJob = null;
  PAGES.render = function (t) {
    var running = !!renJob;
    return pageHead(t) +
      '<div class="card"><span class="label">الجزء</span>' + seg('renWork', prefs.renWork ? '1' : '', [['', 'الكومب كله'], ['1', 'بين B و N']]) +
      '<span class="label">الجودة</span>' + seg('renQuality', prefs.renQuality, [['best', 'أعلى جودة'], ['small', 'ملف أصغر']]) +
      '<span class="hint">المشروع بيتسيّف الأول، وبعدين نسخة منه بتترندر في الخلفية وإنت كمل شغل. الملف بيتحفظ في Downloads › MIGZZ › Renders. خلي بالك: البريفيو التقيل وقت الريندر ممكن يبطّأ الجهاز.</span>' +
      (running ? '<div class="bar"><span id="renBar" style="width:0%"></span></div><button class="btn" data-ren="cancel">إلغاء</button>'
               : '<button class="btn primary" data-ren="go">ريندر MP4</button>') + '</div>';
  };

  function pasteImage() {
    var E = window.MZE;
    if (!E || !E.NODE) return status('الأداة دي محتاجة تشتغل جوه البرنامج', 'err');
    var dir = E.path.join(E.os.homedir(), 'Downloads', 'MIGZZ', 'Images');
    if (!E.fs.existsSync(dir)) E.fs.mkdirSync(dir, { recursive: true });
    var file = E.path.join(dir, 'image ' + new Date().toISOString().replace(/[:.]/g, '-') + '.png');
    var q = "'" + file.replace(/'/g, "''") + "'";
    var ps = "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; " +
      "$d = [System.Windows.Forms.Clipboard]::GetData('PNG'); " +
      "if ($d -is [System.IO.MemoryStream]) { [System.IO.File]::WriteAllBytes(" + q + ", $d.ToArray()); 'image' } " +
      "else { $i = [System.Windows.Forms.Clipboard]::GetImage(); " +
      "if ($i -ne $null) { $i.Save(" + q + ", [System.Drawing.Imaging.ImageFormat]::Png); 'image' } " +
      "elseif ([System.Windows.Forms.Clipboard]::ContainsFileDropList()) { [System.Windows.Forms.Clipboard]::GetFileDropList()[0] } else { 'none' } }";
    status('بيجيب الصورة…', 'busy');
    E.cp.execFile('powershell.exe', ['-NoProfile', '-STA', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true }, function (err, so) {
      var out = String(so || '').trim();
      if (err) { E.log('paste image', err); return status('مقدرتش أقرا الكليببورد', 'err'); }
      var src = out === 'image' ? file : (out && out !== 'none' && /\.(png|jpe?g|webp|gif|bmp|tiff?)$/i.test(out) ? out : '');
      if (!src) return status('مفيش صورة في الكليببورد: كليك يمين على الصورة ← Copy image', 'err');
      run('mz_addImage', [src], 'الصورة اتحطت في الكومب');
    });
  }

  function runRender() {
    var E = window.MZE;
    if (!E || !E.NODE) return status('الأداة دي محتاجة تشتغل جوه البرنامج', 'err');
    if (renJob) return;
    var job = renJob = { cancelled: false }, info, copy, out;
    render();
    function bar(p) { var b = document.getElementById('renBar'); if (b) b.style.width = p + '%'; }
    function stop(msg, kind) { renJob = null; render(); status(msg, kind); }
    status('بيسيّف المشروع…', 'busy');
    hostReady.then(function () { return call('mz_renderInfo', !!prefs.renWork); }).then(function (r) {
      if (!r.ok) throw { mz: errText(r) };
      if (!r.unique) throw { mz: 'فيه أكتر من كومب بنفس الاسم «' + r.comp + '». غيّر اسم الكومب وجرب تاني' };
      info = r;
      var dir = E.path.join(E.os.homedir(), 'Downloads', 'MIGZZ', 'Renders');
      if (!E.fs.existsSync(dir)) E.fs.mkdirSync(dir, { recursive: true });
      out = E.path.join(dir, info.comp.replace(/[\\/:*?"<>|]/g, '_') + ' ' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.mp4');
      copy = E.tmpFile('.aep');
      E.fs.copyFileSync(info.project, copy);
      function aer(withTemplate) {
        var args = ['-project', copy, '-comp', info.comp, '-s', String(info.start), '-e', String(info.end), '-output', out];
        if (withTemplate) args.push('-OMtemplate', prefs.renQuality === 'small' ? 'H.264 - Match Render Settings - 15 Mbps' : 'H.264 - Match Render Settings - 40 Mbps');
        status('بيرندر… 0%', 'busy');
        return E.run(info.aerender, args, function (line) {
          var m = /PROGRESS:.*\((\d+)\)/.exec(line);
          if (m) { var p = Math.min(99, Math.round(Number(m[1]) / info.frames * 100)); status('بيرندر… ' + p + '%', 'busy'); bar(p); }
        }, job);
      }
      return aer(true).then(function (res) {
        if (res.code === 0 || job.cancelled) return res;
        E.log('aerender with template failed, retrying with the default output module');
        return aer(false);
      });
    }).then(function (res) {
      E.rmrf(copy);
      if (job.cancelled) throw new Error('CANCELLED');
      if (res.code !== 0 || !E.fs.existsSync(out)) throw { mz: 'الريندر وقف. ابعتلنا ملف log.txt من فولدر MIGZZ' };
      stop('الريندر خلص: Downloads › MIGZZ › Renders');
      try { E.cp.spawn('explorer.exe', ['/select,', out], { detached: true, stdio: 'ignore' }).unref(); } catch (e) {}
    }).catch(function (e) {
      if (copy) E.rmrf(copy);
      if (e && e.message === 'CANCELLED') return stop('اتلغى');
      if (e && e.mz) return stop(e.mz, 'err');
      E.log('render failed', e);
      stop('حصل خطأ: ' + (e && e.message ? e.message : e), 'err');
    });
  }

  // ───────── fluid motion
  var fluJob = null;
  PAGES.fluid = function (t) {
    var m = prefs.fluMode, running = !!fluJob;
    var sub = m === 'blur' ? '<span class="label">قوة البلر</span>' + seg('fluBlur', prefs.fluBlur, [[2, 'خفيف'], [4, 'فيلم'], [6, 'قوي'], [8, 'أقصى']]) +
        '<span class="hint">بلر حقيقي زي كاميرا السينما: فريمات جديدة بين كل فريمين، وبعدين بتتدمج.</span>'
      : m === 'frames' ? '<span class="label">الفريمات</span>' + seg('fluK', prefs.fluK, [[2, '×2'], [4, '×4']]) +
        '<span class="hint">الكليب يبقى أنعم بنفس مدته (مثلًا 30 فريم يبقى 60 أو 120).</span>'
      : '<span class="label">البطء</span>' + seg('fluSlow', prefs.fluSlow, [[2, '2x'], [4, '4x'], [8, '8x']]) +
        '<span class="hint">الكليب يطوّل وبيتحرك أبطأ من غير تقطيع.</span>';
    return pageHead(t) +
      '<div class="card"><span class="label">النوع</span>' + seg('fluMode', m, [['blur', 'موشن بلر'], ['frames', 'فريمات أكتر'], ['slow', 'سلو موشن']]) + sub + '</div>' +
      '<div class="card"><label class="check"><input type="checkbox" data-pref="fluWork"' + (prefs.fluWork ? ' checked' : '') + '> الجزء بين B و N بس (أسرع بكتير)</label>' +
      '<span class="hint">حدد الفيديو في التايملاين. النتيجة كليب جديد فوقه (ProRes بنفس الألوان)، والملف بيتحفظ في Downloads › MIGZZ.</span>' +
      (running ? '<div class="bar"><span id="fluBar" style="width:0%"></span></div><button class="btn" data-flu="cancel">إلغاء</button>'
               : '<button class="btn primary" data-flu="go">ابدأ</button>') + '</div>';
  };
  function runFluid() {
    var E = window.MZE;
    if (!E || !E.NODE) return status('الأداة دي محتاجة تشتغل جوه البرنامج', 'err');
    if (fluJob) return;
    var job = fluJob = { cancelled: false }, info, ff, out, mode = prefs.fluMode;
    var k = mode === 'frames' ? Number(prefs.fluK) : mode === 'slow' ? Number(prefs.fluSlow) : 8;
    render();
    function bar(p) { var b = document.getElementById('fluBar'); if (b) b.style.width = p + '%'; }
    function stop(msg, kind) { fluJob = null; render(); status(msg, kind); }
    hostReady.then(function () { return call('mz_videoInfo', !!prefs.fluWork); }).then(function (r) {
      if (!r.ok) throw { mz: errText(r) };
      info = r;
      return E.ensure('ffmpeg', function (t2, p) { status(t2, 'busy'); }, job);
    }).then(function (f) {
      ff = f;
      return E.ensure('rife', function (t2, p) { status(t2, 'busy'); }, job);
    }).then(function (rife) {
      var dir = E.path.join(E.os.homedir(), 'Downloads', 'MIGZZ', 'Fluid');
      if (!E.fs.existsSync(dir)) E.fs.mkdirSync(dir, { recursive: true });
      var tag = mode === 'blur' ? 'motion blur' : mode === 'frames' ? (Math.round(info.fps * k)) + 'fps' : 'slow ' + k + 'x';
      out = E.path.join(dir, info.name.replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]/g, '_') + ' - ' + tag + ' ' + Date.now() % 100000 + '.mov');
      status('بيعمل الفريمات الجديدة… 0%', 'busy');
      return E.fluid({ ff: ff, rife: rife, src: info.path, a: info.a, dur: info.b - info.a, fps: info.fps, mode: mode, k: k, blur: Number(prefs.fluBlur), out: out },
        function (p) { status('بيعمل الفريمات الجديدة… ' + p + '%', 'busy'); bar(p); }, job);
    }).then(function () {
      var tag = mode === 'blur' ? 'موشن بلر' : mode === 'frames' ? '×' + k : 'سلو ' + k + 'x';
      return call('mz_importAbove', out, info.id, info.start + info.a, info.name + ' · ' + tag);
    }).then(function (r) {
      if (!r.ok) throw { mz: errText(r) };
      stop('الكليب الجديد اتحط فوق الأصلي');
    }).catch(function (e) {
      if (e && e.message === 'CANCELLED') return stop('اتلغى');
      if (e && e.mz) return stop(e.mz, 'err');
      E.log('fluid failed', e);
      stop('حصل خطأ: ' + (e && e.message ? e.message : e), 'err');
    });
  }
  function cancelJob(j) {
    if (!j) return;
    j.cancelled = true;
    try { if (j.proc) j.proc.kill(); } catch (e) {}
    (j.procs || []).forEach(function (p) { try { p.kill(); } catch (e) {} });
  }

  // ───────── beats
  var lastBeats = null, beatJob = null;
  PAGES.beat = function (t) {
    var has = !!(lastBeats && lastBeats.times.length);
    return pageHead(t) +
      '<div class="card"><span class="label">الحساسية: <b id="beatSensVal">' + prefs.beatSens + '</b></span>' +
      '<input type="range" min="0" max="100" step="1" value="' + prefs.beatSens + '" data-pref="beatSens" aria-label="الحساسية">' +
      '<span class="hint">أعلى = علامات أكتر (حتى الضربات الخفيفة). أقل = الضربات القوية بس.</span>' +
      (HOST === 'pr' ? '' : '<span class="label">العلامات تتحط على</span>' + seg('beatComp', prefs.beatComp ? '1' : '', [['', 'لير المزيكا'], ['1', 'الكومب']])) +
      '<label class="check"><input type="checkbox" data-pref="beatWork"' + (prefs.beatWork ? ' checked' : '') + '> الجزء بين B و N بس</label>' +
      '<label class="check"><input type="checkbox" data-pref="beatReplace"' + (prefs.beatReplace ? ' checked' : '') + '> امسح علامات الضربات القديمة</label>' +
      '<label class="check"><input type="checkbox" data-pref="beatNum"' + (prefs.beatNum ? ' checked' : '') + '> رقّم العلامات</label>' +
      '<span class="hint">حدد لير المزيكا في التايملاين.</span>' +
      '<div class="row" style="grid-template-columns:2fr 1fr"><button class="btn primary" data-beat="go"' + (beatJob ? ' disabled' : '') + '>حط العلامات</button><button class="btn" data-beat="clear">امسحها</button></div></div>' +
      '<div class="card"><span class="label">بعد ما تحط العلامات' + (has ? ' (' + lastBeats.times.length + ' ضربة)' : '') + '</span>' +
      '<span class="hint">' + (HOST === 'pr' ? 'حدد الكليب اللي عايز تقطعه على الضربات:' : 'حدد الصور أو الكليبات اللي عايزها تمشي على المزيكا، واختار:') + '</span>' +
      (HOST === 'pr' ? '' : '<button class="btn" data-beat="snap"' + (has ? '' : ' disabled') + '>كل لير تبدأ على أقرب ضربة</button>' +
      '<button class="btn" data-beat="seq"' + (has ? '' : ' disabled') + '>رُصّهم ورا بعض، كل واحدة ضربة</button>') +
      '<button class="btn" data-beat="cut"' + (has ? '' : ' disabled') + '>قطّع الكليب المحدد على الضربات</button></div>';
  };
  function runBeats() {
    var E = window.MZE;
    if (!E || !E.NODE) return status('الأداة دي محتاجة تشتغل جوه البرنامج', 'err');
    if (beatJob) return;
    var job = beatJob = { cancelled: false }, info;
    render();
    function stop(msg, kind) { beatJob = null; render(); status(msg, kind); }
    hostReady.then(function () { return call('mz_captionInfo', prefs.beatWork); }).then(function (r) {
      if (!r.ok) throw { mz: errText(r) };
      info = r;
      return E.ensure('ffmpeg', function (txt) { status(txt, 'busy'); }, job);
    }).then(function (ff) {
      status('بيسمع المزيكا…', 'busy');
      return E.beats(ff, info.path, info.a, info.b - info.a, Number(prefs.beatSens), job);
    }).then(function (rel) {
      var times = rel.map(function (t) { return info.start + info.a + t; });
      if (!times.length) throw { mz: 'مالقيتش ضربات واضحة. علّي الحساسية وجرب تاني' };
      lastBeats = { times: times, id: info.id };
      E.log('beats', times.length);
      return call('mz_beatMarkers', times, { id: info.id, onComp: !!prefs.beatComp, replace: !!prefs.beatReplace, number: !!prefs.beatNum });
    }).then(function (r) {
      if (!r.ok) throw { mz: errText(r) };
      stop('اتحطت ' + r.count + ' علامة على الضربات');
    }).catch(function (e) {
      if (e && e.message === 'CANCELLED') return stop('اتلغى');
      if (e && e.mz) return stop(e.mz, 'err');
      E.log('beats failed', e);
      stop('حصل خطأ: ' + (e && e.message ? e.message : e), 'err');
    });
  }

  function renderPage() {
    var t = findTool(st.page.ref);
    view.innerHTML = PAGES[t.run.page](t);
  }

  // ───────── events
  tabsEl.addEventListener('click', function (e) {
    var b = e.target.closest('[data-tab]'); if (!b) return;
    st.tab = b.dataset.tab; st.page = null; st.query = ''; q.value = '';
    render();
  });
  view.addEventListener('click', function (e) {
    var b;
    if ((b = e.target.closest('[data-secinfo]'))) { var S = SECTIONS[b.dataset.secinfo]; return openInfo({ t: 'قسم ' + S.title, d: S.d, h: S.h, where: S.where }); }
    if ((b = e.target.closest('[data-info]'))) { var ti = findTool(b.dataset.info); return openInfo({ t: ti.name, d: ti.d, h: ti.h, where: ti.where, soon: !isBuilt(ti) }); }
    if ((b = e.target.closest('[data-back]'))) { st.page = null; return render(); }
    if ((b = e.target.closest('[data-tool]'))) {
      var t = findTool(b.dataset.tool);
      if (!isBuilt(t)) return openInfo({ t: t.name, d: t.d, h: t.h, where: t.where, soon: true });
      if (t.run.page) { st.page = { ref: b.dataset.tool }; return render(); }
      if (t.run.act === 'paste') return pasteImage();
      return run(t.run.fn, [], function (r) {
        if (t.k === 'precomp') return 'اتعمل بريكومب «' + r.name + '»';
        if (t.k === 'precompEach') return 'اتعمل ' + r.count + ' بريكومب';
        if (t.k === 'decomp') return 'اتفك البريكومب (' + r.count + ' لير)';
        if (t.k === 'dup') return 'اتعمل ' + r.count + ' نسخة مستقلة';
        return 'تم';
      });
    }
    if ((b = e.target.closest('[data-act]'))) {
      if (b.dataset.act === 'copyFx') return run('mz_copyFx', [], function (r) { return 'اتنسخ ' + r.count + ' إيفكت من «' + r.name + '»'; });
      if (b.dataset.act === 'pasteFx') return run('mz_pasteFx', [], function (r) { return 'اتلصق ' + r.count + ' إيفكت' + (r.skipped ? ' (' + r.skipped + ' إعداد متقدم متنقلش)' : ''); });
    }
    if ((b = e.target.closest('[data-anchor]'))) return run('mz_anchor', [b.dataset.anchor], function (r) { return 'اتنقلت نقطة الارتكاز في ' + r.count + ' لير' + (r.skipped ? ' · ' + r.skipped + ' لير اتسابت: ' + (ERR[r.why] || '') : ''); });
    if ((b = e.target.closest('[data-cap]'))) {
      if (b.dataset.cap === 'go') return runCaptions();
      if (b.dataset.cap === 'cancel') return cancelCaptions();
      if (b.dataset.cap === 'srt') return exportSrt();
      if (b.dataset.cap === 'style') return run('mz_captionStyleNew', [], 'اتعملت لير Caption style: ظبط شكلها وبعدين دوس كابشن تلقائي');
    }
    if ((b = e.target.closest('[data-sty]'))) {
      if (b.dataset.sty === 'copy') return run('mz_copyStyle', [], function (r) { return 'اتنسخ شكل «' + r.name + '»'; });
      return run('mz_pasteStyle', [{ motion: !!prefs.styMotion, fx: !!prefs.styFx, blend: !!prefs.styBlend }], function (r) { return 'اتلصق الشكل على ' + r.count + ' لير' + (r.skipped ? ' (' + r.skipped + ' إعداد متقدم متنقلش)' : ''); });
    }
    if ((b = e.target.closest('[data-safe]'))) return HOST === 'pr' ? MZ.safePr(b.dataset.safe) : run('mz_safeGuide', [b.dataset.safe], function (r) { return r.removed ? 'الدليل اتشال' : 'اتحط دليل ' + r.name.split(' \u00B7 ')[1]; });
    if ((b = e.target.closest('[data-org]'))) {
      if (b.dataset.org === 'plan') return run('mz_organizeInfo', [!!prefs.orgDeep], function (r) { orgPlan = r; setTimeout(render, 0); return r.n ? 'شوف الترتيب ودوس نظّم' : 'المشروع متنظم خلاص'; });
      return run('mz_organize', [!!prefs.orgDeep], function (r) { orgPlan = null; setTimeout(render, 0); return 'اتنقل ' + r.count + ' ملف لفولدراته'; });
    }
    if ((b = e.target.closest('[data-ren]'))) return b.dataset.ren === 'go' ? runRender() : cancelJob(renJob);
    if ((b = e.target.closest('[data-flu]'))) { return b.dataset.flu === 'go' ? runFluid() : cancelJob(fluJob); }
    if ((b = e.target.closest('[data-beat]'))) {
      var bk = b.dataset.beat;
      if (bk === 'go') return runBeats();
      if (bk === 'clear') return run('mz_beatClear', [{ id: lastBeats ? lastBeats.id : 0 }], function (r) { return 'اتمسح ' + r.count + ' علامة'; });
      if (!lastBeats) return;
      if (bk === 'snap') return run('mz_beatSnap', [lastBeats.times, lastBeats.id], function (r) { return r.count + ' لير بقت على الضربات'; });
      if (bk === 'seq') return run('mz_beatSequence', [lastBeats.times, lastBeats.id], function (r) { return 'اترصّت ' + r.count + ' لير على الضربات'; });
      if (bk === 'cut') return run('mz_beatCut', [lastBeats.times, 0], function (r) { return 'الكليب اتقطع ' + r.count + ' حتة'; });
    }
    if ((b = e.target.closest('[data-x]'))) { var hx = MZ.handlers[b.dataset.x]; if (hx) return hx(b, e); }
    if ((b = e.target.closest('button[data-pref]'))) { prefs[b.dataset.pref] = b.dataset.val; savePrefs(); return render(); }
    if ((b = e.target.closest('[data-new]'))) {
      var col = (document.getElementById('solidColor') || {}).value || '#ffffff';
      return run('mz_newLayer', [b.dataset.new, col], function (r) { return 'اتعملت لير «' + r.name + '»'; });
    }
  });
  view.addEventListener('change', function (e) {
    var el = e.target;
    if (!el.dataset || !el.dataset.pref) return;
    prefs[el.dataset.pref] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? Number(el.value) : el.value;
    if (el.type === 'checkbox' && MZ.onRange[el.dataset.pref]) MZ.onRange[el.dataset.pref](el.checked);
    savePrefs();
  });
  view.addEventListener('input', function (e) {
    var el = e.target;
    if (el.type === 'range' && el.dataset && el.dataset.pref) {
      prefs[el.dataset.pref] = Number(el.value); savePrefs();
      var v = document.getElementById(el.dataset.pref + 'Val');
      if (v) v.textContent = el.dataset.fmt && MZ.fmt[el.dataset.fmt] ? MZ.fmt[el.dataset.fmt](Number(el.value)) : el.value;
      if (MZ.onRange[el.dataset.pref]) MZ.onRange[el.dataset.pref](Number(el.value));
    }
  });
  sheet.addEventListener('click', function (e) { if (e.target === sheet || e.target.closest('[data-close]')) closeInfo(); });
  document.getElementById('btnAbout').addEventListener('click', function () {
    openInfo({ t: 'MIGZZ ' + VERSION, d: 'بلوجن مجانية للافتر وبريمير، وكل أدوات الـ AI فيها بتشتغل على جهازك من غير نت.', h: 'دوس على علامة التعجب جنب أي أداة علشان تعرف بتعمل إيه.\nCtrl+K علشان تدور على أي أداة.' });
  });
  q.addEventListener('input', function () { st.query = q.value; st.page = null; render(); });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); q.focus(); q.select(); }
    if (e.key === 'Escape') { if (!sheet.hidden) closeInfo(); else if (st.page) { st.page = null; render(); } else if (st.query) { q.value = ''; st.query = ''; render(); } }
  });

  // ───────── context in the status bar (comp / sequence name)
  function poll() {
    if (!CEP || busy || document.hidden) return;
    hostReady.then(function () { return call('mz_status'); }).then(function (r) {
      var ctx = document.getElementById('stCtx');
      if (r && r.ok) ctx.textContent = r.comp ? r.comp + (r.sel ? ' · ' + r.sel + ' محدد' : '') : (HOST === 'pr' ? 'مفيش سيكوانس مفتوحة' : 'مفيش كومب مفتوح');
    });
  }
  setInterval(poll, 1500);

  hostReady.then(function (r) {
    if (CEP && r !== 'loaded') status('الجزء الخاص بالبرنامج ما اتحمّلش: ' + r, 'err');
    poll();
  });
  // models download by themselves in the background (all panel files are loaded by then)
  if (window.MZE && MZE.NODE && MZE.bgStart) setTimeout(function () { if (prefs.bgDl !== false) { MZE.bgPause(!!prefs.bgPaused); MZE.bgStart(); } }, 2500);
  setInterval(dlTick, 1000);
  document.getElementById('dlbar').addEventListener('click', openDownloads);
  sheet.addEventListener('click', function (e) {
    if (e.target.closest('[data-x="dlPause"]')) { prefs.bgPaused = !prefs.bgPaused; savePrefs(); MZE.bgPause(prefs.bgPaused); openDownloads(); dlTick(); }
  });
  // ───────── shared with the other panel files (js/motion.js, js/more.js, js/dev.js)
  var MZ = window.MZ = {
    VERSION: VERSION, CEP: CEP, HOST: HOST, TOOLS: TOOLS, SECTIONS: SECTIONS, PAGES: PAGES, ERR: ERR, I: I, prefs: prefs, st: st,
    call: call, run: run, status: status, savePrefs: savePrefs, seg: seg, pageHead: pageHead, render: render, svg: svg, esc: esc,
    hostReady: hostReady, errText: errText, cancelJob: cancelJob, openInfo: openInfo, findTool: findTool, sizeNote: sizeNote,
    handlers: {}, onRange: {}, fmt: {},
    tool: function (sec, k) { var l = TOOLS[sec]; for (var i = 0; i < l.length; i++) if (l[i].k === k) return l[i]; return null; },
    // range slider bound to a pref, with a live value label
    range: function (pref, label, min, max, step, fmt) {
      var v = prefs[pref], f = fmt && MZ.fmt[fmt] ? MZ.fmt[fmt](v) : v;
      return '<span class="label">' + label + ': <b id="' + pref + 'Val">' + f + '</b></span><input type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + v + '" data-pref="' + pref + '"' + (fmt ? ' data-fmt="' + fmt + '"' : '') + ' aria-label="' + esc(label) + '">';
    },
    check: function (pref, label) { return '<label class="check"><input type="checkbox" data-pref="' + pref + '"' + (prefs[pref] ? ' checked' : '') + '> ' + label + '</label>'; },
    defaults: function (o) { for (var k in o) if (!(k in prefs)) prefs[k] = o[k]; },
    setBusy: function (b) { busy = b; }
  };
  MZ.fmt.sec = function (v) { return Number(v).toFixed(2).replace(/0$/, '') + ' ث'; };
  MZ.fmt.pct = function (v) { return v + '%'; };
  render();
})();
