/* MIGZZ — panel: motion tools (curves, bounce, text animations, speed ramp). Needs js/app.js (window.MZ). */
(function () {
  'use strict';
  var MZ = window.MZ;
  if (!MZ || MZ.HOST !== 'ae') return;
  var prefs = MZ.prefs, esc = MZ.esc;
  Object.assign(MZ.ERR, {
    NO_KEYS: 'حدد كيفريمين جنب بعض أو أكتر (على نفس الخاصية)', KEYS_KIND: 'الكيفريمز دي نوعها مايتظبطش بمنحنى (زي الماسك أو النص)',
    KEYS_HOLD: 'الكيفريم ده Hold، مفيهوش منحنى', KEYS_FLAT: 'الكيفريمين بنفس القيمة، مفيش حركة أقراها',
    TEXT_ONLY: 'حدد لير نص', SPEED_KIND: 'حدد فيديو (مش صورة أو نص أو بريكومب فاضي)', SPEED_NONE: 'الكليب ده سرعته عادية أصلًا'
  });
  MZ.defaults({
    curB: [0.33, 0, 0.67, 1], curSaved: [], curGraph: 'value',
    bnKind: 'pop', bnDur: 0.35, bnAmp: 100, bnFreq: 3, bnDecay: 6, bnAt: 'cti',
    taGroup: 'in', taPreset: 'rise', taUnit: 3, taDur: 0.8, taSpread: 40, taAt: 'layer',
    spPreset: 'car', spStrength: 100, spWork: false, spBlend: true
  });
  function built(sec, k, page) { var t = MZ.tool(sec, k); t.run = { page: page }; t.runOn = 'ae'; }
  built('motion', 'curves', 'curves'); built('motion', 'bounce', 'bounce'); built('motion', 'textAnim', 'textAnim'); built('motion', 'speed', 'speed');

  // ───────── curves
  var CURVES = [
    ['ثابت (Linear)', [0, 0, 1, 1]], ['Easy Ease', [0.33, 0, 0.67, 1]], ['ناعم', [0.4, 0, 0.2, 1]], ['خاطف', [0.8, 0, 0.1, 1]],
    ['دخلة قوية', [0.05, 0.7, 0.1, 1]], ['يهدى في النص', [0.1, 0.6, 0.9, 0.4]],
    ['Sine In', [0.12, 0, 0.39, 0]], ['Sine Out', [0.61, 1, 0.88, 1]], ['Sine In-Out', [0.37, 0, 0.63, 1]],
    ['Quad In', [0.11, 0, 0.5, 0]], ['Quad Out', [0.5, 1, 0.89, 1]], ['Quad In-Out', [0.45, 0, 0.55, 1]],
    ['Cubic In', [0.32, 0, 0.67, 0]], ['Cubic Out', [0.33, 1, 0.68, 1]], ['Cubic In-Out', [0.65, 0, 0.35, 1]],
    ['Quart In', [0.5, 0, 0.75, 0]], ['Quart Out', [0.25, 1, 0.5, 1]], ['Quart In-Out', [0.76, 0, 0.24, 1]],
    ['Quint In', [0.64, 0, 0.78, 0]], ['Quint Out', [0.22, 1, 0.36, 1]], ['Quint In-Out', [0.83, 0, 0.17, 1]],
    ['Expo In', [0.7, 0, 0.84, 0]], ['Expo Out', [0.16, 1, 0.3, 1]], ['Expo In-Out', [0.87, 0, 0.13, 1]],
    ['Circ In', [0.55, 0, 1, 0.45]], ['Circ Out', [0.01, 0.55, 0.45, 1]], ['Circ In-Out', [0.85, 0, 0.15, 1]],
    ['يبدأ هادي', [0.6, 0, 1, 1]], ['يقف هادي', [0, 0, 0.4, 1]], ['ضربة', [0.7, 0, 0.01, 1]]
  ];
  function bz(b, s) { // point on the curve at parameter s
    var u = 1 - s;
    return [3 * u * u * s * b[0] + 3 * u * s * s * b[2] + s * s * s, 3 * u * u * s * b[1] + 3 * u * s * s * b[3] + s * s * s];
  }
  function curvePath(b, W, H, pad) {
    var d = '', i, p;
    for (i = 0; i <= 40; i++) { p = bz(b, i / 40); d += (i ? 'L' : 'M') + (pad + p[0] * W).toFixed(1) + ' ' + (pad + (1 - p[1]) * H).toFixed(1); }
    return d;
  }
  function speedPath(b, W, H, pad) { // normalised speed over time
    var pts = [], i, s, u, dx, dy, mx = 0, d = '';
    for (i = 0; i <= 60; i++) {
      s = i / 60; u = 1 - s;
      dx = 3 * u * u * b[0] + 6 * u * s * (b[2] - b[0]) + 3 * s * s * (1 - b[2]);
      dy = 3 * u * u * b[1] + 6 * u * s * (b[3] - b[1]) + 3 * s * s * (1 - b[3]);
      var v = dx > 1e-4 ? dy / dx : (dy > 0 ? 50 : 0);
      v = Math.max(0, Math.min(v, 50));
      pts.push([bz(b, s)[0], v]); mx = Math.max(mx, v);
    }
    mx = mx || 1;
    pts.forEach(function (p, j) { d += (j ? 'L' : 'M') + (pad + p[0] * W).toFixed(1) + ' ' + (pad + (1 - p[1] / mx) * H).toFixed(1); });
    return d;
  }
  function miniCurve(b) {
    return '<svg width="38" height="30" viewBox="0 0 38 30" aria-hidden="true"><path d="' + curvePath(b, 30, 22, 4) + '" fill="none" stroke="#F5A524" stroke-width="1.6" stroke-linecap="round"/></svg>';
  }
  var EW = 220, EH = 170, EP = 18;
  function editorSvg() {
    var b = prefs.curB, speed = prefs.curGraph === 'speed';
    var x1 = EP + b[0] * EW, y1 = EP + (1 - b[1]) * EH, x2 = EP + b[2] * EW, y2 = EP + (1 - b[3]) * EH;
    var grid = '';
    for (var g = 1; g < 4; g++) grid += '<path d="M' + (EP + g * EW / 4) + ' ' + EP + 'V' + (EP + EH) + 'M' + EP + ' ' + (EP + g * EH / 4) + 'H' + (EP + EW) + '" stroke="#26272C"/>';
    return '<svg id="curSvg" viewBox="0 0 ' + (EW + 2 * EP) + ' ' + (EH + 2 * EP) + '" style="width:100%;height:auto;direction:ltr;touch-action:none" aria-label="محرر المنحنى">' +
      '<rect x="' + EP + '" y="' + EP + '" width="' + EW + '" height="' + EH + '" fill="#131417" stroke="#2A2B30"/>' + grid +
      (speed ? '<path d="' + speedPath(b, EW, EH, EP) + '" fill="none" stroke="#F5A524" stroke-width="2.2"/>' :
        '<path d="M' + EP + ' ' + (EP + EH) + 'L' + x1 + ' ' + y1 + 'M' + (EP + EW) + ' ' + EP + 'L' + x2 + ' ' + y2 + '" stroke="#6B6C74" stroke-width="1.2"/>' +
        '<path d="' + curvePath(b, EW, EH, EP) + '" fill="none" stroke="#F5A524" stroke-width="2.4"/>' +
        '<circle data-h="1" cx="' + x1 + '" cy="' + y1 + '" r="8" fill="#F2F2F3" style="cursor:grab"/>' +
        '<circle data-h="2" cx="' + x2 + '" cy="' + y2 + '" r="8" fill="#F2F2F3" style="cursor:grab"/>') +
      '</svg>';
  }
  function fmtB(b) { return b.map(function (v) { return (Math.round(v * 100) / 100).toFixed(2); }).join(', '); }
  MZ.PAGES.curves = function (t) {
    var saved = prefs.curSaved || [];
    return MZ.pageHead(t) +
      '<div class="card">' + MZ.seg('curGraph', prefs.curGraph, [['value', 'جراف القيمة'], ['speed', 'جراف السرعة']]) +
      '<div id="curEd">' + editorSvg() + '</div>' +
      '<span class="hint" style="direction:ltr;text-align:center" id="curNums">' + fmtB(prefs.curB) + '</span>' +
      '<span class="hint">' + (prefs.curGraph === 'speed' ? 'ده شكل السرعة: عالي = سريع. ارجع لجراف القيمة علشان تسحب المقابض.' : 'اسحب الدايرتين البيض علشان تغيّر شكل الحركة.') + '</span>' +
      '<div class="row" style="grid-template-columns:2fr 1fr"><button class="btn primary" data-x="curApply">طبّق على الكيفريمز المحددة</button><button class="btn" data-x="curRead">اقرا المحدد</button></div>' +
      '<button class="btn" data-x="curSave">احفظ المنحنى ده</button></div>' +
      (saved.length ? '<div class="card"><span class="label">منحنياتي</span><div class="kinds">' + saved.map(function (s, i) {
        return '<button class="btn" data-x="curPick" data-b="' + s.b.join(',') + '" style="justify-content:space-between">' + miniCurve(s.b) + '<span>' + esc(s.name) + '</span><span data-x="curDel" data-i="' + i + '" aria-label="امسح" style="color:#A1A2A9;padding:0 4px">×</span></button>';
      }).join('') + '</div></div>' : '') +
      '<div class="card"><span class="label">منحنيات جاهزة</span><div class="kinds">' + CURVES.map(function (c) {
        return '<button class="btn" data-x="curPick" data-b="' + c[1].join(',') + '" style="justify-content:space-between;font-size:12px">' + miniCurve(c[1]) + '<span>' + c[0] + '</span></button>';
      }).join('') + '</div></div>';
  };
  function redrawCurve() {
    var ed = document.getElementById('curEd'); if (ed) ed.innerHTML = editorSvg();
    var n = document.getElementById('curNums'); if (n) n.textContent = fmtB(prefs.curB);
  }
  var drag = null;
  document.addEventListener('pointerdown', function (e) {
    var h = e.target.closest && e.target.closest('#curSvg [data-h]'); if (!h) return;
    drag = Number(h.getAttribute('data-h')); e.preventDefault();
  });
  document.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var svgEl = document.getElementById('curSvg'); if (!svgEl) return;
    var r = svgEl.getBoundingClientRect(), sx = (EW + 2 * EP) / r.width;
    var x = ((e.clientX - r.left) * sx - EP) / EW, y = 1 - ((e.clientY - r.top) * sx - EP) / EH;
    x = Math.max(0, Math.min(1, x)); y = Math.max(0, Math.min(1, y));
    var b = prefs.curB.slice();
    if (drag === 1) { b[0] = x; b[1] = y; } else { b[2] = x; b[3] = y; }
    prefs.curB = b; redrawCurve();
  });
  document.addEventListener('pointerup', function () { if (drag) { drag = null; MZ.savePrefs(); } });
  MZ.handlers.curPick = function (b, e) {
    if (e.target.closest('[data-x="curDel"]')) return MZ.handlers.curDel(e.target.closest('[data-x="curDel"]'));
    prefs.curB = b.dataset.b.split(',').map(Number); MZ.savePrefs(); redrawCurve();
    MZ.status('اختار «' + b.textContent.replace('×', '').trim() + '» · دوس طبّق');
  };
  MZ.handlers.curDel = function (b) { prefs.curSaved.splice(Number(b.dataset.i), 1); MZ.savePrefs(); MZ.render(); };
  MZ.handlers.curApply = function () {
    return MZ.run('mz_easeApply', [prefs.curB], function (r) { return 'اتطبق المنحنى على ' + r.count + ' جزء' + (r.skipped ? ' · ' + r.skipped + ' خاصية نوعها مايتظبطش' : ''); });
  };
  MZ.handlers.curRead = function () {
    return MZ.run('mz_easeRead', [], function (r) {
      prefs.curB = r.b.map(function (v) { return Math.max(0, Math.min(1, v)); }); MZ.savePrefs(); setTimeout(redrawCurve, 0);
      return 'اتقرا منحنى «' + r.name + '»';
    });
  };
  MZ.handlers.curSave = function () {
    var n = (prefs.curSaved || []).length + 1;
    prefs.curSaved = (prefs.curSaved || []).concat([{ name: 'منحنى ' + n, b: prefs.curB.slice() }]);
    MZ.savePrefs(); MZ.render(); MZ.status('اتحفظ في «منحنياتي»');
  };

  // ───────── bounce
  var BOUNCE = [['pop', 'نطة للحجم'], ['drop', 'سقوط ونطة'], ['rise', 'طلوع من تحت'], ['slideR', 'زحلقة من اليمين'], ['slideL', 'زحلقة من الشمال'], ['spin', 'لف ونطة'], ['jelly', 'جيلي']];
  function bounceAt(kind, t) { // the same math as the AE expression → preview (x, y, scale, rot, opacity)
    var d = prefs.bnDur, a = prefs.bnAmp / 100, f = prefs.bnFreq, dc = prefs.bnDecay, w = f * 2 * Math.PI;
    function spring(from, to) {
      if (t < d) return from + (to - from) * (t / d);
      var v = (to - from) / d, tt = t - d;
      return to + v * a * Math.sin(w * tt) / Math.exp(dc * tt) / w;
    }
    var o = { x: 0, y: 0, s: 1, sy: 1, r: 0, op: Math.min(1, t / Math.min(d * 0.5, 0.15)) };
    if (kind === 'pop') { o.s = spring(0, 1); o.op = 1; }
    if (kind === 'spin') { o.s = spring(0, 1); o.r = spring(-180, 0); o.op = 1; }
    if (kind === 'jelly') { o.s = spring(1.35, 1); o.sy = spring(0.65, 1) / Math.max(0.01, o.s); o.op = 1; }
    if (kind === 'slideR') o.x = spring(110, 0);
    if (kind === 'slideL') o.x = spring(-110, 0);
    if (kind === 'rise') o.y = spring(70, 0);
    if (kind === 'drop') {
      var h = -90;
      if (t < d) o.y = h * (1 - t / d);
      else {
        var e = Math.min(0.95, a * 0.6), g = 6000 * f / 3 / 6, vl = Math.abs(h / d) * e, tc = 0, seg = 2 * vl / g, tn = seg, nb = 1, tt = t - d;
        while (tn < tt && nb <= 9) { vl *= e; seg *= e; tc = tn; tn += seg; nb++; }
        o.y = nb <= 9 ? -((tt - tc) * (vl - g * (tt - tc) / 2)) : 0;
      }
    }
    return o;
  }
  var bnRaf = 0;
  function bnLoop(t0) {
    var box = document.getElementById('bnBox');
    if (!box) { bnRaf = 0; return; }
    var t = ((performance.now() - t0) / 1000) % 2.2, o = bounceAt(prefs.bnKind, Math.max(0, t - 0.2));
    if (t < 0.2) o = bounceAt(prefs.bnKind, 0);
    box.style.transform = 'translate(' + o.x + 'px,' + o.y + 'px) rotate(' + o.r + 'deg) scale(' + o.s + ',' + (o.s * o.sy) + ')';
    box.style.opacity = Math.max(0, Math.min(1, o.op));
    bnRaf = requestAnimationFrame(function () { bnLoop(t0); });
  }
  MZ.PAGES.bounce = function (t) {
    setTimeout(function () { if (!bnRaf) bnLoop(performance.now()); }, 0);
    return MZ.pageHead(t) +
      '<div class="card"><div style="height:150px;border-radius:10px;background:#131417;border:1px solid #2A2B30;display:flex;align-items:center;justify-content:center;overflow:hidden;direction:ltr">' +
      '<div id="bnBox" style="width:58px;height:58px;border-radius:14px;background:#F5A524;display:flex;align-items:center;justify-content:center;color:#1A1205;font-weight:700">M</div></div>' +
      '<span class="label">الحركة</span><div class="kinds">' + BOUNCE.map(function (k) { return '<button class="btn' + (prefs.bnKind === k[0] ? ' primary' : '') + '" data-pref="bnKind" data-val="' + k[0] + '">' + k[1] + '</button>'; }).join('') + '</div></div>' +
      '<div class="card">' + MZ.range('bnDur', 'مدة الدخلة', 0.1, 1.5, 0.05, 'sec') + MZ.range('bnAmp', 'قوة الارتداد', 0, 200, 5, 'pct') +
      MZ.range('bnFreq', 'عدد الاهتزازات', 1, 6, 0.5) + (prefs.bnKind === 'drop' ? '' : MZ.range('bnDecay', 'سرعة الهدوء', 1, 12, 0.5)) +
      '<span class="label">تبدأ من</span>' + MZ.seg('bnAt', prefs.bnAt, [['cti', 'مكان المؤشر'], ['in', 'أول اللير']]) +
      '<span class="hint">حدد النص أو اللوجو أو أي لير. بعد التطبيق هتلاقي سلايدرز MIGZZ في Effect Controls تظبط بيها القوة والسرعة.</span>' +
      '<div class="row" style="grid-template-columns:2fr 1fr"><button class="btn primary" data-x="bnApply">طبّق</button><button class="btn" data-x="bnRemove">شيل الارتداد</button></div></div>';
  };
  MZ.handlers.bnApply = function () {
    return MZ.run('mz_bounce', [prefs.bnKind, { dur: prefs.bnDur, amp: prefs.bnAmp, freq: prefs.bnFreq, decay: prefs.bnDecay, at: prefs.bnAt }], function (r) { return 'اتطبقت الحركة على ' + r.count + ' لير'; });
  };
  MZ.handlers.bnRemove = function () { return MZ.run('mz_bounceRemove', [], function (r) { return 'اتشال الارتداد (الكيفريمز فضلت)'; }); };

  // ───────── text animations
  var TA = {
    'in': [['fade', 'ظهور تدريجي'], ['rise', 'طلوع من تحت'], ['drop', 'نزول من فوق'], ['slideR', 'من اليمين'], ['slideL', 'من الشمال'], ['pop', 'نطة'], ['zoom', 'زووم'], ['blur', 'من البلر'], ['track', 'الحروف بتتلم'], ['rotate', 'لف'], ['skew', 'ميلان'], ['type', 'آلة كاتبة'], ['random', 'عشوائي']],
    out: [['fade', 'اختفاء تدريجي'], ['rise', 'يطلع لفوق'], ['drop', 'ينزل لتحت'], ['slideR', 'لليمين'], ['slideL', 'للشمال'], ['pop', 'يصغر'], ['zoom', 'زووم'], ['blur', 'للبلر'], ['track', 'الحروف بتتفرق'], ['rotate', 'لف'], ['type', 'مسح حرف حرف'], ['random', 'عشوائي']],
    loop: [['wave', 'موجة'], ['float', 'طفو'], ['shake', 'رعشة'], ['flicker', 'ومضة']]
  };
  function taPreview() {
    var el = document.getElementById('taPrev'); if (!el) return;
    var unit = Number(prefs.taUnit), txt = 'نص تجريبي للحركة';
    var parts = unit === 1 ? txt.split('') : unit === 3 ? txt.split(' ') : [txt];
    el.innerHTML = parts.map(function (p) { return '<span style="display:inline-block;white-space:pre">' + esc(p === ' ' ? ' ' : p) + (unit === 3 ? ' ' : '') + '</span>'; }).join('');
    var spans = el.children, n = spans.length, pre = prefs.taPreset, grp = prefs.taGroup;
    var start = performance.now();
    function frame() {
      if (!document.getElementById('taPrev') || el !== document.getElementById('taPrev')) return;
      var T = (performance.now() - start) / 1000, cyc = Math.max(1.6, prefs.taDur + 1), tt = T % cyc - 0.2;
      for (var i = 0; i < n; i++) {
        var p, s = spans[i];
        if (grp === 'loop') {
          var ph = T * 4 - i * 0.6;
          s.style.transform = pre === 'wave' ? 'translateY(' + (-6 * Math.sin(ph)) + 'px)' : pre === 'float' ? 'translateY(' + (3 * Math.sin(T * 2 + i)) + 'px)' : pre === 'shake' ? 'translate(' + (Math.random() * 3 - 1.5) + 'px,' + (Math.random() * 3 - 1.5) + 'px)' : '';
          s.style.opacity = pre === 'flicker' ? (Math.random() > 0.15 ? 1 : 0.2) : 1;
          continue;
        }
        var W = pre === 'type' ? 0 : Math.max(0.05, prefs.taSpread / 100);
        var pos = n > 1 ? i / n : 0, prog = Math.max(0, Math.min(1, tt / prefs.taDur));
        var off = pre === 'type' ? prog : -W + prog * (1 + W);
        p = pre === 'type' ? (pos < off ? 1 : 0) : Math.max(0, Math.min(1, (off - pos) / W + 1 - 1 / 1));
        if (pre !== 'type') p = Math.max(0, Math.min(1, (off + W - pos) / W));
        p = p * p * (3 - 2 * p);
        if (grp === 'out') p = 1 - p;
        var h = 1 - p, tr = '';
        if (pre === 'rise') tr = 'translateY(' + (h * 14) + 'px)';
        if (pre === 'drop') tr = 'translateY(' + (-h * 14) + 'px)';
        if (pre === 'slideR') tr = 'translateX(' + (h * 18) + 'px)';
        if (pre === 'slideL') tr = 'translateX(' + (-h * 18) + 'px)';
        if (pre === 'pop') tr = 'scale(' + p + ')';
        if (pre === 'zoom') tr = 'scale(' + (1 + h * 1.8) + ')';
        if (pre === 'rotate') tr = 'rotate(' + (-90 * h) + 'deg)';
        if (pre === 'skew') tr = 'skewX(' + (-45 * h) + 'deg) translateX(' + (h * 10) + 'px)';
        if (pre === 'track') tr = 'translateX(' + ((i - n / 2) * h * 4) + 'px)';
        s.style.transform = tr;
        s.style.filter = pre === 'blur' ? 'blur(' + (h * 6) + 'px)' : '';
        s.style.opacity = pre === 'random' ? ((i * 7919) % n / n < 1 - h ? 1 : 0) : p;
      }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }
  MZ.PAGES.textAnim = function (t) {
    var grp = prefs.taGroup, list = TA[grp];
    if (!list.some(function (x) { return x[0] === prefs.taPreset; })) prefs.taPreset = list[0][0];
    setTimeout(taPreview, 0);
    return MZ.pageHead(t) +
      '<div class="card"><div id="taPrev" style="height:70px;border-radius:10px;background:#131417;border:1px solid #2A2B30;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;overflow:hidden;direction:rtl"></div>' +
      MZ.seg('taGroup', grp, [['in', 'دخول'], ['out', 'خروج'], ['loop', 'مستمر']]) +
      '<div class="kinds">' + list.map(function (k) { return '<button class="btn' + (prefs.taPreset === k[0] ? ' primary' : '') + '" data-pref="taPreset" data-val="' + k[0] + '">' + k[1] + '</button>'; }).join('') + '</div></div>' +
      '<div class="card"><span class="label">بتتحرك</span>' + MZ.seg('taUnit', prefs.taUnit, [[1, 'حرف حرف'], [3, 'كلمة كلمة'], [4, 'سطر سطر']]) +
      (grp === 'loop' ? '' : MZ.range('taDur', 'المدة', 0.2, 3, 0.1, 'sec') + (prefs.taPreset === 'type' ? '' : MZ.range('taSpread', 'التداخل', 5, 100, 5, 'pct')) +
        '<span class="label">' + (grp === 'out' ? 'تخلص عند' : 'تبدأ من') + '</span>' + MZ.seg('taAt', prefs.taAt, [['layer', grp === 'out' ? 'آخر اللير' : 'أول اللير'], ['cti', 'مكان المؤشر']])) +
      '<span class="hint">في العربي «كلمة كلمة» بتطلع أحلى، علشان الحروف المتوصلة. التداخل الأقل = كل حرف أو كلمة تخلص قبل اللي بعدها.</span>' +
      '<div class="row" style="grid-template-columns:2fr 1fr"><button class="btn primary" data-x="taApply">ضيف</button><button class="btn" data-x="taRemove">شيل الحركات</button></div></div>';
  };
  MZ.handlers.taApply = function () {
    var label = (TA[prefs.taGroup].filter(function (x) { return x[0] === prefs.taPreset; })[0] || ['', ''])[1];
    return MZ.run('mz_textAnim', [{ preset: prefs.taPreset, group: prefs.taGroup, unit: Number(prefs.taUnit), dur: prefs.taDur, spread: prefs.taSpread, at: prefs.taAt, label: label }], function (r) { return 'اتضافت «' + label + '» على ' + r.count + ' نص'; });
  };
  MZ.handlers.taRemove = function () { return MZ.run('mz_textAnimRemove', [], function (r) { return 'اتشال ' + r.count + ' حركة'; }); };

  // ───────── speed ramp
  var RAMPS = [
    ['car', 'لقطة عربيات', [[0.3, 1], [0.3, 4], [0.25, 0.3], [0.15, 1]]],
    ['fastMid', 'يسرع في النص', [[0.3, 1], [0.4, 4], [0.3, 1]]],
    ['slowMid', 'يبطّأ في النص', [[0.35, 1], [0.3, 0.3], [0.35, 1]]],
    ['fastIn', 'دخلة سريعة', [[0.5, 4], [0.5, 1]]],
    ['fastOut', 'خروج سريع', [[0.5, 1], [0.5, 4]]],
    ['slowEnd', 'يهدى في الآخر', [[0.6, 1], [0.4, 0.3]]],
    ['punch', 'سريع وبعدين بطيء', [[0.45, 4], [0.55, 0.35]]]
  ];
  function rampOf(key) { for (var i = 0; i < RAMPS.length; i++) if (RAMPS[i][0] === key) return RAMPS[i]; return RAMPS[0]; }
  // speed (× normal) at u ∈ [0,1] of the source part; log-space blends between phases
  function speedAt(phases, u, strength) {
    var tot = phases.reduce(function (s, p) { return s + p[0]; }, 0), acc = 0, bounds = [], logs = [], w = 0.07, i;
    for (i = 0; i < phases.length; i++) { logs.push(Math.log(phases[i][1]) * strength); acc += phases[i][0] / tot; bounds.push(acc); }
    var L = logs[0];
    for (i = 0; i < phases.length - 1; i++) {
      var x = (u - (bounds[i] - w / 2)) / w; x = Math.max(0, Math.min(1, x)); x = x * x * (3 - 2 * x);
      L += (logs[i + 1] - logs[i]) * x;
    }
    return Math.exp(L);
  }
  function computeRamp(info, phases, strength) {
    var S = info.srcB - info.srcA, N = 4000, out = [0], i, T = 0;
    for (i = 1; i <= N; i++) { T += S / N / speedAt(phases, (i - 0.5) / N, strength); out.push(T); }
    var fps = info.fps, nF = Math.max(1, Math.round(T * fps)), step = Math.max(1, Math.ceil(nF / 1500)), sc = T / (nF / fps);
    var times = [], values = [], j = 0;
    // keys sit on whole frames; the curve is stretched a hair so the last frame lands exactly on the end
    for (var k = 0; k <= nF; k += step) {
      var t = Math.min(k / fps * sc, T);
      while (j < N && out[j + 1] < t) j++;
      var f = out[j + 1] > out[j] ? (t - out[j]) / (out[j + 1] - out[j]) : 0;
      times.push(info.a + k / fps); values.push(info.srcA + S * (j + Math.max(0, Math.min(1, f))) / N);
    }
    if (times[times.length - 1] < info.a + nF / fps - 1e-6) { times.push(info.a + nF / fps); values.push(info.srcB); }
    values[values.length - 1] = info.srcB;
    return { times: times, values: values, len: nF / fps };
  }
  MZ._computeRamp = computeRamp; MZ._speedAt = speedAt; MZ._RAMPS = RAMPS;
  function rampIcon(phases) {
    var d = '', i;
    for (i = 0; i <= 30; i++) { var v = Math.log(speedAt(phases, i / 30, 1)) / Math.log(4); d += (i ? 'L' : 'M') + (4 + i) + ' ' + (15 - v * 10).toFixed(1); }
    return '<svg width="38" height="30" viewBox="0 0 38 30" aria-hidden="true"><path d="M4 15H34" stroke="#34353B"/><path d="' + d + '" fill="none" stroke="#F5A524" stroke-width="1.6"/></svg>';
  }
  MZ.PAGES.speed = function (t) {
    return MZ.pageHead(t) +
      '<div class="card"><span class="label">الشكل</span><div class="kinds">' + RAMPS.map(function (r) {
        return '<button class="btn' + (prefs.spPreset === r[0] ? ' primary' : '') + '" data-pref="spPreset" data-val="' + r[0] + '" style="justify-content:space-between">' + rampIcon(r[2]) + '<span>' + r[1] + '</span></button>';
      }).join('') + '</div><span class="hint">فوق الخط = أسرع من العادي، تحت الخط = أبطأ.</span></div>' +
      '<div class="card">' + MZ.range('spStrength', 'القوة', 40, 160, 10, 'pct') +
      MZ.check('spWork', 'الجزء بين B و N بس') + MZ.check('spBlend', 'نعّم الأجزاء البطيئة (Frame Blending)') +
      '<span class="hint">حدد الكليب. طول الكليب في التايملاين هيتغير على حسب السرعة. للسلو موشن الناعم جدًا استخدم «حركة ناعمة وسلو موشن» الأول.</span>' +
      '<div class="row" style="grid-template-columns:2fr 1fr"><button class="btn primary" data-x="spApply">طبّق</button><button class="btn" data-x="spReset">رجّع العادي</button></div></div>';
  };
  MZ.handlers.spApply = function () {
    MZ.status('شغال…', 'busy');
    return MZ.hostReady.then(function () { return MZ.call('mz_speedInfo', !!prefs.spWork); }).then(function (info) {
      if (!info.ok) return MZ.status(MZ.errText(info), 'err');
      var r = computeRamp(info, rampOf(prefs.spPreset)[2], prefs.spStrength / 100);
      return MZ.run('mz_speedApply', [{ id: info.id, times: r.times, values: r.values, oldB: info.b, blend: !!prefs.spBlend }], function (x) {
        return 'اتطبق · الجزء بقى ' + x.len.toFixed(1) + ' ث (كان ' + (info.b - info.a).toFixed(1) + ' ث)';
      });
    });
  };
  MZ.handlers.spReset = function () { return MZ.run('mz_speedReset', [], 'رجعت السرعة العادية'); };

  MZ.render();
})();
