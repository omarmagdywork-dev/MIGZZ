/* MIGZZ — panel: After Effects presets → Premiere templates (.mogrt), and the template library inside Premiere. */
(function () {
  'use strict';
  var MZ = window.MZ, E = window.MZE;
  if (!MZ || !E || !E.NODE) return;
  var prefs = MZ.prefs, esc = MZ.esc, fs = E.fs, path = E.path, PR = MZ.HOST === 'pr';
  var LIB = path.join(E.os.homedir(), 'Documents', 'MIGZZ', 'MOGRT');
  MZ.I.mogrt = 'M4 5h16v11H4zM9 20h6M12 16v4M8 9l3 2-3 2M13 13h3';
  Object.assign(MZ.ERR, { MOGRT_NOTHING: 'البريسيت ده مفيهوش حركة تتنقل', MOGRT_FAIL: 'مقدرتش أعمل القالب ده' });
  MZ.defaults({ mgFormat: 'v', mgText: 'اكتب هنا', mgDirs: {}, mgFolder: '', mgSkip: true, mgInsertText: '' });
  function walk(dir, out, depth) {
    var items; try { items = fs.readdirSync(dir); } catch (e) { return out; }
    items.forEach(function (n) {
      var p = path.join(dir, n), st; try { st = fs.statSync(p); } catch (e) { return; }
      if (st.isDirectory()) { if (depth < 6) walk(p, out, depth + 1); } else if (/\.ffx$/i.test(n)) out.push(p);
    });
    return out;
  }

  if (!PR) {
    // ───────── After Effects: the converter
    MZ.TOOLS.lib.push({ k: 'mogrt', on: 'ae', run: { page: 'mogrtMake' }, runOn: 'ae', name: 'حوّل البريسيتس لبريمير', sub: 'بريسيتس الافتر تبقى قوالب MOGRT تشتغل في بريمير', d: 'بياخد بريسيتس الافتر بتاعتك (حركات النصوص والأشكال) ويحوّل كل واحد لقالب Motion Graphics Template. القوالب دي بتظهر في بريمير في قسم «أنيميشن النصوص»، والنص فيها بيتعدل.', h: 'اختار الفولدرات اللي فيها البريسيتس.\nاختار المقاس.\nدوس حوّل، وسيبه يخلص.', where: 'جوه الافتر' });
    var roots = null, scan = null, mgJob = null;
    function findRoots() {
      return MZ.hostReady.then(function () { return MZ.call('mz_aePaths'); }).then(function (r) {
        var list = [];
        if (r.ok) {
          list.push({ label: 'بريسيتس الافتر', dir: path.join(r.app, 'Presets') });
          list.push({ label: 'بريسيتس بتاعتي (User Presets)', dir: path.join(r.docs, 'Adobe', 'After Effects ' + r.year, 'User Presets') });
        }
        (prefs.mgExtra || []).forEach(function (d) { list.push({ label: path.basename(d), dir: d }); });
        roots = list.filter(function (x) { return fs.existsSync(x.dir); });
        scan = [];
        roots.forEach(function (rt) {
          var groups = {};
          walk(rt.dir, [], 0).forEach(function (f) {
            var rel = path.relative(rt.dir, path.dirname(f)) || path.basename(rt.dir);
            (groups[rel] = groups[rel] || []).push(f);
          });
          Object.keys(groups).sort().forEach(function (g) { scan.push({ root: rt, group: g, files: groups[g], key: rt.dir + '|' + g }); });
        });
        MZ.render();
      });
    }
    MZ.PAGES.mogrtMake = function (t) {
      if (!roots) { setTimeout(findRoots, 0); return MZ.pageHead(t) + '<div class="card"><span class="hint">بيدوّر على البريسيتس…</span></div>'; }
      var total = 0, chosen = 0;
      var rows = scan.map(function (g, i) {
        var on = prefs.mgDirs[g.key] !== undefined ? prefs.mgDirs[g.key] : /text|نص|title|typo/i.test(g.group);
        total += g.files.length; if (on) chosen += g.files.length;
        return '<label class="check"><input type="checkbox" data-x="mgDir" data-i="' + i + '"' + (on ? ' checked' : '') + '> ' + esc(g.group) + ' <span style="opacity:.6">(' + g.files.length + ')</span></label>';
      }).join('');
      var running = !!mgJob;
      return MZ.pageHead(t) +
        '<div class="card"><span class="label">الفولدرات (' + total + ' بريسيت)</span>' + (rows || '<span class="hint">مالقيتش بريسيتس. ضيف فولدر.</span>') +
        '<button class="btn" data-x="mgAdd">+ ضيف فولدر تاني</button></div>' +
        '<div class="card"><span class="label">المقاس</span>' + MZ.seg('mgFormat', prefs.mgFormat, [['v', 'طولي 9:16'], ['h', 'عرضي 16:9'], ['s', 'مربع']]) +
        '<span class="label">النص الافتراضي</span><input id="mgText" type="text" value="' + esc(prefs.mgText) + '" style="height:38px;border-radius:10px;border:1px solid #34353B;background:#1F2024;color:#F2F2F3;padding:0 10px;font-size:13px">' +
        MZ.check('mgSkip', 'سيب اللي اتحوّل قبل كده') +
        '<span class="hint">البريسيتس اللي بتتحكم في الفيديو نفسه (زي الترانزيشنز والإيفكتات على الكليب) مش هتتنقل، لأن بريمير مبيقبلش ده من القوالب. القوالب بتتحفظ في Documents › MIGZZ › MOGRT. احفظ مشروعك قبل ما تحوّل (الافتر مبيطلعش قوالب من مشروع مش متسيف). القوالب بتتعمل وتتشال تاني، ومشروعك بيفضل زي ما هو.</span>' +
        (running ? '<div class="bar"><span id="mgBar" style="width:0%"></span></div><button class="btn" data-x="mgCancel">وقّف</button>'
                 : '<button class="btn primary" data-x="mgGo"' + (chosen ? '' : ' disabled') + '>حوّل ' + chosen + ' بريسيت</button>') + '</div>';
    };
    MZ.handlers.mgDir = function (b) { var g = scan[Number(b.dataset.i)]; prefs.mgDirs[g.key] = b.checked !== undefined ? b.checked : !prefs.mgDirs[g.key]; MZ.savePrefs(); setTimeout(MZ.render, 0); };
    MZ.handlers.mgAdd = function () {
      var r = window.cep && window.cep.fs ? window.cep.fs.showOpenDialogEx(false, true, 'اختار فولدر البريسيتس', '', []) : null;
      if (r && r.data && r.data[0]) { prefs.mgExtra = (prefs.mgExtra || []).concat([r.data[0]]); MZ.savePrefs(); roots = null; MZ.render(); }
    };
    MZ.handlers.mgCancel = function () { if (mgJob) mgJob.cancelled = true; };
    MZ.convertPresets = function (groups) {
      if (mgJob) return Promise.resolve();
      var el = document.getElementById('mgText'); if (el) { prefs.mgText = el.value; MZ.savePrefs(); }
      var J = mgJob = { cancelled: false }, list = [];
      (groups || scan.filter(function (g) { var on = prefs.mgDirs[g.key] !== undefined ? prefs.mgDirs[g.key] : /text|نص|title|typo/i.test(g.group); return on; }))
        .forEach(function (g) { g.files.forEach(function (f) { list.push({ f: f, g: g }); }); });
      var size = prefs.mgFormat === 'h' ? [1920, 1080, 110] : prefs.mgFormat === 's' ? [1080, 1080, 100] : [1080, 1920, 100];
      var done = 0, ok = 0, skipped = 0, bad = 0, t0 = Date.now();
      MZ.render();
      var next = function (i) {
        if (J.cancelled || i >= list.length) return Promise.resolve();
        var it = list[i], name = path.basename(it.f, '.ffx'), out = path.join(LIB, it.g.group.replace(/[\\/:*?"<>|]+/g, ' › '), name + '.mogrt');
        var bar = document.getElementById('mgBar'); if (bar) bar.style.width = Math.round(i / list.length * 100) + '%';
        MZ.status('بيحوّل ' + (i + 1) + ' من ' + list.length + ': ' + name, 'busy');
        if (prefs.mgSkip && fs.existsSync(out) && fs.statSync(out).isFile()) { skipped++; return next(i + 1); }
        E.log('mogrt make', name);
        return MZ.call('mz_mogrtMake', { ffx: it.f, out: out, name: name, w: size[0], h: size[1], size: size[2], text: prefs.mgText || 'اكتب هنا', minDur: 3, kind: /shape|شكل|background|خلفي/i.test(it.g.group) ? 'shape' : 'text' })
          .then(function (r) { done++; if (r.ok) ok++; else { bad++; E.log('mogrt skip', name, r.code, r.error || ''); } return next(i + 1); });
      };
      return MZ.hostReady.then(function () { return MZ.call('mz_mogrtBegin', path.join(E.DATA, 'mogrt-tmp', 'MIGZZ convert.aep')); }).then(function (r) {
        if (!r.ok) { mgJob = null; MZ.render(); throw { mz: r.code === 'MOGRT_SAVE_FIRST' ? 'احفظ المشروع الأول (Ctrl+S)، وبعدها حوّل. القوالب بتتعمل وتتشال تاني، ومشروعك بيفضل زي ما هو.' : MZ.errText(r) }; }
        return next(0);
      }).then(function () { return MZ.call('mz_mogrtEnd'); }).then(function () {
        mgJob = null; MZ.render();
        var msg = 'اتعمل ' + ok + ' قالب' + (skipped ? ' · ' + skipped + ' كانوا معمولين' : '') + (bad ? ' · ' + bad + ' مالهمش حركة تتنقل' : '') + ' · ' + Math.round((Date.now() - t0) / 1000) + ' ث';
        MZ.status(J.cancelled ? 'وقف: ' + msg : msg);
        return { ok: ok, skipped: skipped, bad: bad };
      }).catch(function (e) { mgJob = null; MZ.status(e && e.mz ? e.mz : 'حصل خطأ: ' + (e && e.message || e), 'err'); return { error: e && e.mz || String(e) }; });
    };
    MZ.handlers.mgGo = function () { return MZ.convertPresets(); };
    MZ._mgScan = function () { return findRoots().then(function () { return scan.map(function (g) { return [g.root.label, g.group, g.files.length]; }); }); };
    MZ._mgScanData = function () { return scan; };
  } else {
    // ───────── Premiere: the template library (under «التحريك»)
    MZ.TOOLS.motion.push({ k: 'mogrt', on: 'pr', run: { page: 'mogrtLib' }, runOn: 'pr', name: 'أنيميشن النصوص', sub: 'قوالب جاهزة من بريسيتس الافتر بتاعتك', d: 'كل البريسيتس اللي حوّلتها من الافتر بتظهر هنا في فولدرات. دوسة واحدة تحط القالب عند المؤشر في أول تراك فاضي، والنص بيتعدل من Essential Graphics.', h: 'اكتب النص (اختياري).\nاختار الفولدر ودوس على القالب.', where: 'جوه بريمير' });
    var q = '';
    var list = function () {
      var out = [];
      (function rec(d, rel) {
        var items; try { items = fs.readdirSync(d); } catch (e) { return; }
        items.forEach(function (n) {
          var p = path.join(d, n), st; try { st = fs.statSync(p); } catch (e) { return; }
          if (st.isDirectory()) rec(p, rel ? rel + ' › ' + n : n); else if (/\.mogrt$/i.test(n)) out.push({ f: p, n: n.replace(/\.mogrt$/i, ''), g: rel || 'عام' });
        });
      })(LIB, '');
      return out;
    };
    MZ.PAGES.mogrtLib = function (t) {
      var all = list(), groups = {}, i;
      all.forEach(function (m) { (groups[m.g] = groups[m.g] || []).push(m); });
      var names = Object.keys(groups).sort();
      if (names.indexOf(prefs.mgFolder) < 0) prefs.mgFolder = names[0] || '';
      var shown = q ? all.filter(function (m) { return (m.n + ' ' + m.g).toLowerCase().indexOf(q.toLowerCase()) >= 0; }) : (groups[prefs.mgFolder] || []);
      return MZ.pageHead(t) +
        '<div class="card"><input id="mgInsText" type="text" placeholder="النص اللي هيتكتب في القالب (اختياري)" value="' + esc(prefs.mgInsertText) + '" style="height:38px;border-radius:10px;border:1px solid #34353B;background:#1F2024;color:#F2F2F3;padding:0 10px;font-size:13px">' +
        '<input id="mgQ" type="text" placeholder="دوّر في القوالب…" value="' + esc(q) + '" style="height:34px;border-radius:10px;border:1px solid #2A2B30;background:#17181B;color:#F2F2F3;padding:0 10px;font-size:12.5px"></div>' +
        (names.length ? (q ? '' : '<div class="card"><div class="kinds">' + names.map(function (g) {
          return '<button class="btn' + (g === prefs.mgFolder ? ' primary' : '') + '" data-pref="mgFolder" data-val="' + esc(g) + '" style="font-size:12px">' + esc(g) + ' <span style="opacity:.6">' + groups[g].length + '</span></button>';
        }).join('') + '</div></div>') +
          '<div class="card"><div class="list">' + (shown.length ? shown.map(function (m) {
            return '<div class="tool"><button class="main" data-x="mgIns" data-f="' + esc(m.f) + '" style="padding-left:12px"><span class="ttext"><span class="tname">' + esc(m.n) + '</span><span class="tsub">' + esc(m.g) + '</span></span></button></div>';
          }).join('') : '<span class="hint">مفيش نتايج.</span>') + '</div></div>'
          : '<div class="card"><span class="hint">لسه مفيش قوالب. افتح MIGZZ في الافتر ‹ مكتبتي ‹ «حوّل البريسيتس لبريمير»، وبعدها هتلاقيها هنا.</span></div>');
    };
    document.addEventListener('input', function (e) {
      if (e.target && e.target.id === 'mgQ') { q = e.target.value; var pos = e.target.selectionStart; MZ.render(); var n = document.getElementById('mgQ'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }
      if (e.target && e.target.id === 'mgInsText') { prefs.mgInsertText = e.target.value; MZ.savePrefs(); }
    });
    MZ.handlers.mgIns = function (b) {
      return MZ.run('mz_mogrtInsert', [b.dataset.f, prefs.mgInsertText || ''], function (r) { return 'اتحط «' + r.name + '» على V' + r.track; });
    };
  }
  MZ.render();
})();
