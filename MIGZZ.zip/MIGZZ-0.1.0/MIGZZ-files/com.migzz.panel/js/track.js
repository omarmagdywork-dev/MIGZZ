/* MIGZZ — panel: the current frame inside the panel — draw on it (AE) or pick a box to track (AE + Premiere). */
(function () {
  'use strict';
  var MZ = window.MZ, E = window.MZE;
  if (!MZ || !E || !E.NODE) return;
  var prefs = MZ.prefs, esc = MZ.esc, PR = MZ.HOST === 'pr';
  Object.assign(MZ.ERR, { AE_OLD_FRAME: 'الافتر ده قديم على الأداة دي (محتاج 2023 أو أحدث)', TRACK_PLAYHEAD: 'حط المؤشر على جزء من الكليب نفسه', TRACK_NO_TARGET: 'حط الجرافيك أو النص في تراك فوق الفيديو، في نفس الوقت' });
  // ───────── the current frame inside the panel: draw on it, or pick a box to track
  MZ.I.draw = 'M4 20c3-1 4-4 7-6s6-1 9-6M17 4l3 3-9 9H8v-3z';
  MZ.defaults({ dwColor: '#FF3B30', dwWidth: 10, dwDraw: true, dwArrow: false, dwDur: 1.2, tkWhat: 'text' });
  if (!PR) MZ.TOOLS.tools.push({ k: 'draw', on: 'ae', run: { page: 'draw' }, runOn: 'ae', name: 'ارسم على الفريم', sub: 'خطوط وأسهم ودواير بإيدك، وتترسم بحركة', d: 'بتشوف الفريم الحالي جوه البلوجن وترسم عليه بالماوس: دواير حوالين حاجة، أسهم، خطوط تحت كلام. اللي رسمته بيبقى Shape Layer بيترسم بحركة.', h: 'دوس هات الفريم.\nارسم بالماوس.\nدوس ضيف.', where: 'جوه الافتر' });
  var trk = MZ.tool('ai', 'track'); trk.on = 'both'; trk.run = { page: 'track' }; trk.runOn = MZ.HOST;
  trk.d = PR ? 'بتحدد أي حاجة في الفيديو بمربع (عربية، منتج، إيد)، والبلوجن بيتتبعها فريم بفريم ويخلي الجرافيك أو النص اللي في التراك اللي فوقها يمشي معاها.' : 'بتحدد أي حاجة في الفيديو بمربع (عربية، منتج، إيد)، والبلوجن بيتتبعها فريم بفريم ويعمل Null بيمشي معاها، وتقدر تربط بيه نص أو أي لير.';
  trk.h = PR ? 'حط الجرافيك أو النص في تراك فوق الفيديو.\nحدد الفيديو وحط المؤشر عند أول فريم.\nدوس هات الفريم وارسم مربع، ودوس تتبع.' : 'حدد الفيديو وحط المؤشر عند أول فريم.\nدوس هات الفريم وارسم مربع حوالين الحاجة.\nدوس تتبع.';
  var frame = null, strokes = [], cur = null, box = null;
  function frameFile() { return E.path.join(E.os.tmpdir(), 'MIGZZ', 'frame.png'); }
  var grabbing = false;
  function grabFrame() {
    if (grabbing) return;   // one comp render at a time (AE renders the PNG in the background)
    grabbing = true;
    var f = frameFile();
    MZ.status('بيجيب الفريم…', 'busy');
    return MZ.hostReady.then(function () { return MZ.call(PR ? 'mz_prFrame' : 'mz_saveFrame', f); }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      return new Promise(function (res, rej) {
        var n = 0; (function w() { if (E.fs.existsSync(f) && E.fs.statSync(f).size > 0) res(r); else if (E.fs.existsSync(f + '.png') && E.fs.statSync(f + '.png').size > 0) { E.fs.renameSync(f + '.png', f); res(r); } else if (++n > 300) rej({ mz: 'مقدرتش أجيب الفريم' }); else setTimeout(w, 200); })();
      });
    }).then(function (r) { grabbing = false; frame = { w: r.w, h: r.h, src: 'file:///' + encodeURI(f.replace(/\\/g, '/')) + '?' + Date.now() }; strokes = []; box = null; MZ.render(); MZ.status('جاهز'); })
      .catch(function (e) { grabbing = false; MZ.status(e && e.mz ? e.mz : 'حصل خطأ: ' + (e && e.message || e), 'err'); });
  }
  MZ.handlers.frGrab = grabFrame;
  // AE tracking: the clip's own frame straight from the file (ffmpeg), so the box is already in the clip's pixels.
  // (no comp render: faster, and safe even when the comp has heavy 3D in it)
  var tkSrc = null;
  function grabSourceFrame() {
    var f = frameFile();
    MZ.status('بيجيب الفريم…', 'busy');
    return MZ.hostReady.then(function () { return MZ.call('mz_trackSrc'); }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      tkSrc = r;
      return E.ensure('ffmpeg').then(function (ff) {
        try { E.fs.unlinkSync(f); } catch (e) {}
        if (!E.fs.existsSync(E.path.dirname(f))) E.fs.mkdirSync(E.path.dirname(f), { recursive: true });
        return E.run(ff, ['-hide_banner', '-loglevel', 'error', '-ss', String(r.t), '-i', r.path, '-frames:v', '1', '-y', f]);
      });
    }).then(function () {
      if (!E.fs.existsSync(f)) throw { mz: 'مقدرتش أجيب الفريم' };
      frame = { w: tkSrc.w, h: tkSrc.h, src: 'file:///' + encodeURI(f.replace(/\\/g, '/')) + '?' + Date.now() }; strokes = []; box = null; MZ.render(); MZ.status('جاهز');
    }).catch(function (e) { MZ.status(e && e.mz ? e.mz : 'حصل خطأ: ' + (e && e.message || e), 'err'); });
  }
  MZ.handlers.tkGrab = PR ? grabFrame : grabSourceFrame;
  function canvasHtml(mode) {
    var g = mode === 'box' ? 'tkGrab' : 'frGrab';
    if (!frame) return '<button class="btn" data-x="' + g + '">هات الفريم الحالي</button>';
    return '<div style="position:relative;direction:ltr"><img src="' + frame.src + '" style="width:100%;display:block;border-radius:8px">' +
      '<canvas id="frCv" data-mode="' + mode + '" width="' + frame.w + '" height="' + frame.h + '" style="position:absolute;inset:0;width:100%;height:100%;touch-action:none;cursor:crosshair"></canvas></div>' +
      '<div class="row" style="grid-template-columns:1fr 1fr"><button class="btn" data-x="' + g + '">فريم جديد</button><button class="btn" data-x="frClear">امسح</button></div>';
  }
  function redraw() {
    var cv = document.getElementById('frCv'); if (!cv) return;
    var g = cv.getContext('2d'); g.clearRect(0, 0, cv.width, cv.height);
    if (cv.dataset.mode === 'draw') {
      g.strokeStyle = prefs.dwColor; g.lineWidth = prefs.dwWidth; g.lineCap = 'round'; g.lineJoin = 'round';
      strokes.concat(cur ? [cur] : []).forEach(function (s) { g.beginPath(); s.forEach(function (p, i) { if (i) g.lineTo(p[0], p[1]); else g.moveTo(p[0], p[1]); }); g.stroke(); });
    } else if (box) {
      g.strokeStyle = '#F5A524'; g.lineWidth = Math.max(2, frame.w / 300); g.setLineDash([12, 8]); g.strokeRect(box[0], box[1], box[2], box[3]);
    }
  }
  var down = null;
  document.addEventListener('pointerdown', function (e) {
    var cv = e.target && e.target.id === 'frCv' ? e.target : null; if (!cv) return;
    var r = cv.getBoundingClientRect(), k = cv.width / r.width, p = [(e.clientX - r.left) * k, (e.clientY - r.top) * k];
    down = p;
    if (cv.dataset.mode === 'draw') cur = [p]; else box = [p[0], p[1], 0, 0];
    e.preventDefault();
  });
  document.addEventListener('pointermove', function (e) {
    if (!down) return;
    var cv = document.getElementById('frCv'); if (!cv) return;
    var r = cv.getBoundingClientRect(), k = cv.width / r.width, p = [(e.clientX - r.left) * k, (e.clientY - r.top) * k];
    if (cv.dataset.mode === 'draw') cur.push(p); else box = [Math.min(down[0], p[0]), Math.min(down[1], p[1]), Math.abs(p[0] - down[0]), Math.abs(p[1] - down[1])];
    redraw();
  });
  document.addEventListener('pointerup', function () {
    if (!down) return; down = null;
    if (cur && cur.length > 1) strokes.push(cur); cur = null; redraw();
  });
  MZ.handlers.frClear = function () { strokes = []; box = null; redraw(); };
  // Ramer–Douglas–Peucker, then Catmull-Rom tangents → smooth bezier paths
  function simplify(pts, eps) {
    if (pts.length < 3) return pts;
    var a = pts[0], b = pts[pts.length - 1], dmax = 0, idx = 0, i;
    for (i = 1; i < pts.length - 1; i++) {
      var p = pts[i], d = Math.abs((b[1] - a[1]) * p[0] - (b[0] - a[0]) * p[1] + b[0] * a[1] - b[1] * a[0]) / (Math.hypot(b[1] - a[1], b[0] - a[0]) || 1);
      if (d > dmax) { dmax = d; idx = i; }
    }
    if (dmax <= eps) return [a, b];
    return simplify(pts.slice(0, idx + 1), eps).slice(0, -1).concat(simplify(pts.slice(idx), eps));
  }
  function toBezier(pts) {
    var out = [];
    pts.forEach(function (p, i) {
      var pr = pts[Math.max(0, i - 1)], nx = pts[Math.min(pts.length - 1, i + 1)], tx = (nx[0] - pr[0]) / 6, ty = (nx[1] - pr[1]) / 6;
      if (i === 0 || i === pts.length - 1) { tx = 0; ty = 0; }
      out.push(Math.round(p[0] * 10) / 10, Math.round(p[1] * 10) / 10, -tx, -ty, tx, ty);
    });
    return out;
  }
  MZ._simplify = simplify; MZ._toBezier = toBezier;
  MZ.PAGES.draw = function (t) {
    setTimeout(redraw, 0);
    return MZ.pageHead(t) + '<div class="card">' + canvasHtml('draw') + '</div>' +
      '<div class="card"><div class="color"><span class="label" style="flex:1">اللون</span><input type="color" id="dwColor" value="' + prefs.dwColor + '"></div>' +
      MZ.range('dwWidth', 'السُمك', 2, 40, 1) + MZ.check('dwArrow', 'آخر كل خط سهم') + MZ.check('dwDraw', 'يترسم بحركة') + MZ.range('dwDur', 'مدة الرسم', 0.2, 5, 0.1, 'sec') +
      '<button class="btn primary" data-x="dwGo"' + (frame ? '' : ' disabled') + '>ضيف الرسم</button></div>';
  };
  document.addEventListener('change', function (e) { if (e.target && e.target.id === 'dwColor') { prefs.dwColor = e.target.value; MZ.savePrefs(); redraw(); } });
  MZ.onRange.dwWidth = function () { redraw(); };
  MZ.handlers.dwGo = function () {
    if (!strokes.length) return MZ.status('ارسم الأول', 'err');
    var h = prefs.dwColor.replace('#', ''), col = [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255];
    var paths = strokes.map(function (s) { return toBezier(simplify(s, Math.max(1.5, frame.w / 600))); });
    return MZ.run('mz_drawApply', [{ strokes: paths, color: col, width: Number(prefs.dwWidth), draw: !!prefs.dwDraw, dur: Number(prefs.dwDur), arrow: !!prefs.dwArrow }], function (r) { strokes = []; setTimeout(redraw, 0); return 'اتضاف الرسم (' + r.strokes + ' خط)'; });
  };
  var tkJob = null;
  MZ.PAGES.track = function (t) {
    setTimeout(redraw, 0);
    return MZ.pageHead(t) + '<div class="card"><span class="hint">حدد الفيديو، وحط المؤشر عند الفريم اللي هتبدأ منه، ودوس هات الفريم. وبعدين ارسم مربع حوالين الحاجة اللي هتتتبع.</span>' + canvasHtml('box') + '</div>' +
      '<div class="card">' + (PR ? '<span class="hint">الجرافيك أو النص اللي في التراك اللي فوق الفيديو هو اللي هيمشي مع الحاجة.</span>' : '<span class="label">ضيف</span>' + MZ.seg('tkWhat', prefs.tkWhat, [['text', 'نص بيمشي معاها'], ['null', 'Null بس']])) +
      (tkJob ? '<div class="bar"><span id="tkBar" style="width:0%"></span></div><button class="btn" data-x="tkCancel">إلغاء</button>' : '<button class="btn primary" data-x="tkGo"' + (frame ? '' : ' disabled') + '>تتبع</button>') + '</div>';
  };
  MZ.handlers.tkCancel = function () { MZ.cancelJob(tkJob); };
  MZ.handlers.tkGo = function () {
    if (!box || box[2] < 6 || box[3] < 6) return MZ.status('ارسم مربع حوالين الحاجة الأول', 'err');
    var J = tkJob = { cancelled: false }, info, t0 = Date.now();
    MZ.render();
    var stop = function (m, k) { tkJob = null; MZ.render(); MZ.status(m, k); };
    var src = null;
    if (!PR && !tkSrc) return stop('دوس هات الفريم الأول', 'err');
    return MZ.hostReady.then(function () { return PR ? MZ.call('mz_trackInfoPr', box) : { ok: true }; }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      if (!PR) { info = Object.assign({}, tkSrc); info.a = Math.max(info.a, info.t); return box; }   // the box is already in the clip's pixels
      info = r;
      // Premiere: sequence pixels → the clip's own pixels (Motion position/scale around the frame centre)
      return E.ensure('ffmpeg').then(function (ff) { return E.run(ff, ['-hide_banner', '-i', info.path]); }).then(function (pr) {
        var m = /Video:.*?(\d{2,5})x(\d{2,5})/.exec(pr.err || ''), sw = m ? Number(m[1]) : info.w, sh = m ? Number(m[2]) : info.h, k = (info.scale || 100) / 100;
        src = { w: sw, h: sh, k: k, px: info.pos[0] * info.w, py: info.pos[1] * info.h };
        info.w = sw; info.h = sh;
        return [(box[0] - src.px) / k + sw / 2, (box[1] - src.py) / k + sh / 2, box[2] / k, box[3] / k];
      });
    }).then(function (sbox) {
      return MZ.runAI('track', 'mFace', { src: info.path, a: info.a, dur: info.b - info.a, fps: Math.min(info.fps, info.compFps || info.fps), w: info.w, h: info.h, box: sbox }, function (p) {
        var el = document.getElementById('tkBar'); if (el) el.style.width = p + '%'; MZ.status('بيتتبع… ' + p + '%', 'busy');
      }, J);
    }).then(function (res) {
      if (PR) {
        var keys = res.keys.map(function (q) { return [info.start + info.a + q[0], src.px + (q[1] - src.w / 2) * src.k, src.py + (q[2] - src.h / 2) * src.k]; });
        return MZ.call('mz_trackApplyPr', info.id, keys).then(function (r) {
          if (!r.ok) throw { mz: MZ.errText(r) };
          stop('«' + r.name + '» بقى بيمشي مع الحاجة (' + r.keys + ' كيفريم)' + (res.weak ? ' · ' + res.weak + ' فريم مش واضح' : ''));
        });
      }
      return MZ.call('mz_trackApply', { id: info.id, t0: info.start + info.a, keys: res.keys, what: prefs.tkWhat }).then(function (r) {
        if (!r.ok) throw { mz: MZ.errText(r) };
        stop('اتعمل «' + r.name + '» · ' + Math.round((Date.now() - t0) / 1000) + ' ث' + (res.weak ? ' · ' + res.weak + ' فريم مش واضح' : ''));
      });
    }).catch(function (e) {
      if (e && e.message === 'CANCELLED') return stop('اتلغى');
      stop(e && e.mz ? e.mz : 'حصل خطأ: ' + (e && e.message || e), 'err');
    });
  };

  MZ.render();
})();
