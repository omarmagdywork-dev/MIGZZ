/* MIGZZ — panel: AI tools that run in the local AI worker (person cut-out, speech/music split, face tracking).
   The worker is ai/worker.js on its own Node; the AI runtime is ONNX Runtime (DirectML on Windows: any modern graphics card). */
(function () {
  'use strict';
  var MZ = window.MZ, E = window.MZE;
  if (!MZ || !E || !E.NODE) return;
  var PR = MZ.HOST === 'pr';
  var prefs = MZ.prefs, fs = E.fs, path = E.path;
  var ORT_V = '1.31.1';
  Object.assign(E.PACKS, {
    node: { label: 'محرك تشغيل الـ AI', url: 'https://nodejs.org/dist/v22.11.0/node-v22.11.0-win-x64.zip', zip: true, exe: 'node.exe', mb: 30 },
    ortNode: { label: 'مكتبة الـ AI', url: 'https://registry.npmjs.org/onnxruntime-node/-/onnxruntime-node-' + ORT_V + '.tgz', zip: true, exe: 'onnxruntime_binding.node', mb: 115 },
    ortCommon: {
      label: 'مكتبة الـ AI (جزء 2)', url: 'https://registry.npmjs.org/onnxruntime-common/-/onnxruntime-common-' + ORT_V + '.tgz', zip: true, exe: 'ready.txt', mb: 1,
      after: function (d) { // the worker finds it by name: …/node_modules/onnxruntime-common
        var nm = path.join(d, 'node_modules');
        if (!fs.existsSync(nm)) fs.mkdirSync(nm);
        fs.renameSync(path.join(d, 'package'), path.join(nm, 'onnxruntime-common'));
        fs.writeFileSync(path.join(d, 'ready.txt'), 'ok');
      }
    },
    mMask: { label: 'موديل قص الشخص', url: 'https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx', file: 'rvm_mobilenetv3_fp32.onnx', mb: 15 },
    mVoice: { label: 'موديل فصل الصوت', url: 'https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/Kim_Vocal_2.onnx', file: 'Kim_Vocal_2.onnx', mb: 67 },
    mSeg: { label: 'موديل شيل الخلفية', url: 'https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx', file: 'isnet-general-use.onnx', mb: 178 },
    m3dEnc: { label: 'موديل الـ 3D', url: 'https://huggingface.co/fernandotonon/QtMeshEditor-triposr-onnx/resolve/main/triposr_encoder_int8.onnx', file: 'triposr_encoder_int8.onnx', mb: 436 },
    m3dEncHQ: { label: 'موديل الـ 3D (أعلى جودة)', url: 'https://huggingface.co/fernandotonon/QtMeshEditor-triposr-onnx/resolve/main/triposr_encoder.onnx', file: 'triposr_encoder.onnx', mb: 1678 },
    m3dDec: { label: 'موديل الـ 3D (جزء 2)', url: 'https://huggingface.co/fernandotonon/QtMeshEditor-triposr-onnx/resolve/main/triposr_decoder.onnx', file: 'triposr_decoder.onnx', mb: 1 },
    mFace: { label: 'موديل الوشوش', url: 'https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx', file: 'face_detection_yunet_2023mar.onnx', mb: 1 }
  });
  MZ.defaults({ aiGpu: true, mkWork: true, mkInvert: false, vcWork: false, vcEnhance: true, fcWork: false, fcWhat: 'text', fcSmooth: 2 });
  ['mask', 'voice', 'face'].forEach(function (k) { var t = MZ.tool('ai', k); t.run = { page: k }; t.runOn = k === 'face' ? 'ae' : MZ.HOST; });
  Object.assign(MZ.ERR, { AI_FAIL: 'الـ AI وقف قبل ما يخلص. ابعتلنا ملف log.txt من فولدر MIGZZ' });

  function extDir() { return decodeURI(window.__adobe_cep__.getSystemPath('extension')).replace(/^file:\/\/\/?/, ''); }
  function aiSize(model) {
    var keys = ['node', 'ortNode', 'ortCommon', model], mb = 0;
    keys.forEach(function (k) { if (!E.installed(k)) mb += E.PACKS[k].mb; });
    return mb ? ' · ' + mb + 'MB أول مرة' : '';
  }
  // installs what's missing, writes the job, runs the worker; onP(percent) while it works
  function runAI(task, model, job, onP, J) {
    var nodeExe, ortDir, commonDir, modelFile;
    var step = function (txt, p) { MZ.status(txt, 'busy'); if (p !== null && p !== undefined) onP(p, true); };
    return E.ensure('ffmpeg', step, J).then(function (ff) { job.ff = ff; return E.ensure('node', step, J); })
      .then(function (n) { nodeExe = n; return E.ensure('ortNode', step, J); })
      .then(function () { ortDir = path.join(E.packDir('ortNode'), 'package'); return E.ensure('ortCommon', step, J); })
      .then(function () { commonDir = path.join(E.packDir('ortCommon'), 'node_modules'); return E.ensure(model, step, J); })
      .then(function (m) {
        modelFile = m;
        job.task = task; job.model = modelFile; job.ort = ortDir; job.cpuOnly = !prefs.aiGpu;
        var jf = E.tmpFile('.json');
        fs.writeFileSync(jf, JSON.stringify(job));
        var done = null, err = null, ep = '', t0 = Date.now(), lastLog = 0;
        E.log('ai start', task);
        // the result is in: if the worker doesn't quit by itself (seen with the GPU driver on exit), stop it
        var reap = function () { var w = J.proc; setTimeout(function () { try { if (w && w.exitCode === null) { E.log('ai reap', task); w.kill(); } } catch (e) {} }, 4000); };
        return E.run(nodeExe, [path.join(extDir(), 'ai', 'worker.js'), jf], function (line) {
          if (/^P \d+/.test(line)) { onP(Number(line.slice(2)), false); if (Date.now() - lastLog > 30000) { lastLog = Date.now(); E.log('ai progress', task, line.slice(2) + '%'); } }
          else if (/^EP /.test(line)) { ep = line.slice(3); E.log('ai ep', task, ep); }
          else if (/^L /.test(line)) E.log('ai', task, line.slice(2));
          else if (/^DONE /.test(line)) { done = JSON.parse(line.slice(5)); reap(); }
          else if (/^ERR /.test(line)) { err = line.slice(4); reap(); }
        }, J, { env: { NODE_PATH: commonDir } }).then(function (r) {
          E.rmrf(jf);
          if (J.cancelled) throw new Error('CANCELLED');
          if (!done) { E.log('ai failed', task, err || r.err); throw { mz: MZ.ERR.AI_FAIL }; }
          done.ep = ep;
          E.log('ai done', task, Math.round((Date.now() - t0) / 1000) + 's');
          return done;
        });
      });
  }
  MZ.runAI = runAI;
  function outDir(sub) { var d = path.join(E.os.homedir(), 'Downloads', 'MIGZZ', sub); if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); return d; }
  function clean(n) { return n.replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]/g, '_'); }

  var aiJob = null, aiKind = null;
  function aiPage(kind, t, body, btn) {
    var running = aiJob && aiKind === kind;
    return MZ.pageHead(t) + body +
      '<div class="card">' + MZ.check('aiGpu', 'استخدم كارت الشاشة (أسرع بكتير، أي كارت حديث)') +
      (running ? '<div class="bar"><span id="aiBar" style="width:0%"></span></div><button class="btn" data-x="aiCancel">إلغاء</button>'
               : '<button class="btn primary" data-x="aiGo" data-k="' + kind + '"' + (aiJob ? ' disabled' : '') + '>' + btn + '</button>') + '</div>';
  }
  MZ.PAGES.mask = function (t) {
    return aiPage('mask', t, '<div class="card">' + MZ.check('mkWork', 'الجزء بين B و N بس (أسرع في التجربة)') + (PR ? '' : MZ.check('mkInvert', 'اعكس: شيل الشخص وسيب الخلفية')) +
      '<span class="hint">' + (PR ? 'حدد الكليب. هيتعمل كليب جديد فوقه فيه الشخص بس من غير خلفية (ProRes 4444 شفاف)، والأصلي مش بيتغير.' : 'حدد الفيديو. البلوجن بيعمل «ماسك» أبيض وأسود للشخص فريم بفريم، ويحطه Track Matte على الكليب. الكليب الأصلي مش بيتغير، ولو عايز ترجّعه شيل الـ Track Matte.') + aiSize('mMask') + '</span></div>', 'قص الشخص');
  };
  MZ.PAGES.voice = function (t) {
    return aiPage('voice', t, '<div class="card">' + MZ.check('vcWork', 'الجزء بين B و N بس') + MZ.check('vcEnhance', 'حسّن صوت الكلام كمان (يشيل الوش ويظبط العلو زي البودكاستات)') +
      '<span class="hint">حدد الكليب أو ملف الصوت. هيطلع تراكين: «صوت الكلام» و«المزيكا والدوشة»، وصوت الكليب الأصلي بيتقفل. كل تراك له الفوليوم بتاعه.' + aiSize('mVoice') + '</span></div>', 'افصل الصوت');
  };
  MZ.PAGES.face = function (t) {
    return aiPage('face', t, '<div class="card"><span class="label">ضيف إيه على الوش</span>' + MZ.seg('fcWhat', prefs.fcWhat, [['text', 'نص فوق الراس'], ['blur', 'بلر على الوش'], ['null', 'Null بس']]) +
      '<span class="label">النعومة</span>' + MZ.seg('fcSmooth', prefs.fcSmooth, [[1, 'سريع'], [2, 'متوسط'], [4, 'ناعم جدًا']]) +
      MZ.check('fcWork', 'الجزء بين B و N بس') +
      '<span class="hint">حدد الفيديو. هيتعمل Null اسمه «MIGZZ وش» بيمشي مع الوش (المكان والحجم ولفة الراس). أي حاجة تربطها بيه (Parent) هتمشي مع الوش.' + aiSize('mFace') + '</span></div>', 'تتبع الوش');
  };
  MZ.handlers.aiCancel = function () { MZ.cancelJob(aiJob); };
  MZ.handlers.aiGo = function (b) {
    if (aiJob) return;
    var kind = b.dataset.k, J = aiJob = { cancelled: false }, info, t0 = Date.now();
    aiKind = kind;
    MZ.render();
    var bar = function (p, dl) {
      var el = document.getElementById('aiBar'); if (el) el.style.width = p + '%';
      if (!dl) {
        var s = (Date.now() - t0) / 1000, left = p > 2 ? Math.round(s * (100 - p) / p) : null;
        MZ.status((kind === 'voice' ? 'بيفصل الصوت… ' : kind === 'face' ? 'بيتتبع الوش… ' : 'بيقص الشخص… ') + p + '%' + (left !== null ? ' · فاضل حوالي ' + (left > 90 ? Math.round(left / 60) + ' دقيقة' : left + ' ثانية') : ''), 'busy');
      }
    };
    var stop = function (msg, k) { aiJob = null; aiKind = null; MZ.render(); MZ.status(msg, k); };
    var work = kind === 'mask' ? prefs.mkWork : kind === 'voice' ? prefs.vcWork : prefs.fcWork;
    var fn = kind === 'voice' ? 'mz_captionInfo' : 'mz_videoInfo';
    return MZ.hostReady.then(function () { return MZ.call(fn, !!work); }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      info = r;
      var job = { src: info.path, a: info.a, dur: info.b - info.a, fps: info.fps, w: info.w, h: info.h };
      if (kind === 'mask') { job.rgba = PR; job.out = path.join(outDir('Masks'), clean(info.name) + (PR ? ' cutout ' : ' matte ') + (Date.now() % 1e5) + '.mov'); }
      if (kind === 'voice') { var base = path.join(outDir('Audio'), clean(info.name) + ' ' + (Date.now() % 1e5)); job.outVoice = base + ' voice.wav'; job.outMusic = base + ' music.wav'; }
      if (kind === 'face') job.smooth = Number(prefs.fcSmooth);
      J.job = job;
      return runAI(kind, kind === 'mask' ? 'mMask' : kind === 'voice' ? 'mVoice' : 'mFace', job, bar, J);
    }).then(function (res) {
      E.log('ai done', kind, JSON.stringify(res).slice(0, 200), Math.round((Date.now() - t0) / 1000) + 's');
      var start = info.start + info.a;
      if (kind === 'mask') return MZ.call('mz_maskApply', J.job.out, info.id, start, !!prefs.mkInvert);
      if (kind === 'voice') {
        var go = function () { return MZ.call('mz_voiceApply', J.job.outVoice, J.job.outMusic, info.id, start); };
        if (!prefs.vcEnhance) return go();
        // studio clean-up of the isolated voice: rumble out, gentle denoise, de-harsh, compression, -16 LUFS
        MZ.status('بيحسّن صوت الكلام…', 'busy');
        var enh = J.job.outVoice.replace(/\.wav$/, ' enhanced.wav');
        return E.run(J.job.ff, ['-hide_banner', '-loglevel', 'error', '-y', '-i', J.job.outVoice, '-af',
          'highpass=f=75,afftdn=nr=10:nf=-45,equalizer=f=3500:t=q:w=1.2:g=-2,equalizer=f=180:t=q:w=1:g=1.5,acompressor=threshold=-21dB:ratio=3:attack=6:release=90:makeup=2,alimiter=limit=0.95,loudnorm=I=-16:TP=-1.5:LRA=9',
          '-ar', '48000', '-c:a', 'pcm_s16le', enh], null, J).then(function (r) {
          if (r.code === 0 && fs.existsSync(enh)) J.job.outVoice = enh; else E.log('enhance failed', r.err);
          return go();
        });
      }
      if (!res.found) throw { mz: 'مالقيتش وش واضح في الكليب ده' };
      return MZ.call('mz_faceApply', { id: info.id, t0: start, keys: res.keys, what: prefs.fcWhat });
    }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      var secs = Math.round((Date.now() - t0) / 1000);
      stop((kind === 'mask' ? 'الشخص اتقص' : kind === 'voice' ? 'الصوت اتفصل لتراكين' : 'اتعمل «' + r.name + '» بيمشي مع الوش') + ' · ' + secs + ' ثانية');
      return r;
    }).catch(function (e) {
      if (e && e.message === 'CANCELLED') return stop('اتلغى');
      if (e && e.mz) return stop(e.mz, 'err');
      E.log('ai failed', kind, e);
      var net = /HTTP|ENOTFOUND|ECONN|timed out|incomplete|EAI_AGAIN/.test(String(e && e.message));
      stop(net ? 'التحميل وقف. اتأكد من النت وجرب تاني' : 'حصل خطأ: ' + (e && e.message ? e.message : e), 'err');
    });
  };

  // ───────── image → 3D (AE)
  if (!PR) {
    MZ.defaults({ d3Quality: 'good', d3Camera: true, d3Orbit: true, d3Light: true, d3Cut: false });
    var t3 = MZ.tool('d3', 'to3d'); t3.run = { page: 'to3d' }; t3.runOn = 'ae';
    var tm = MZ.tool('d3', 'models'); tm.run = { page: 'models' }; tm.runOn = 'ae';
    Object.assign(MZ.ERR, { AE_3D_OLD: 'الافتر ده مفيهوش Advanced 3D: الموديلات محتاجة افتر 2024 أو أحدث', NO_IMAGE: 'اختار صورة الأول' });
    var LIB = path.join(E.os.homedir(), 'Documents', 'MIGZZ', '3D');
    var d3Img = '', d3Job = null;
    var Q = { fast: { res: 128, tex: 1024, enc: 'm3dEnc' }, good: { res: 176, tex: 2048, enc: 'm3dEnc' }, best: { res: 224, tex: 2048, enc: 'm3dEncHQ' } };
    var d3Size = function () {
      var q = Q[prefs.d3Quality] || Q.good, mb = 0;
      ['node', 'ortNode', 'ortCommon', 'mSeg', q.enc, 'm3dDec'].forEach(function (k) { if (!E.installed(k)) mb += E.PACKS[k].mb; });
      return mb ? ' · ' + (mb >= 1000 ? (mb / 1000).toFixed(1) + ' GB' : mb + 'MB') + ' أول مرة' : '';
    };
    MZ.PAGES.to3d = function (t) {
      var running = !!d3Job;
      return MZ.pageHead(t) +
        '<div class="card"><span class="label">الصورة</span>' +
        (d3Img ? '<div style="display:flex;gap:10px;align-items:center"><img src="file:///' + encodeURI(d3Img.replace(/\\/g, '/')) + '" style="width:64px;height:64px;object-fit:contain;border-radius:8px;background:#131417;border:1px solid #2A2B30"><span class="hint" style="flex:1;word-break:break-all">' + esc(path.basename(d3Img)) + '</span></div>' : '') +
        '<div class="row" style="grid-template-columns:1fr 1fr"><button class="btn" data-x="d3Pick">اختار صورة</button><button class="btn" data-x="d3Sel">الصورة المحددة في الكومب</button></div>' +
        '<span class="hint">صورة حاجة واحدة واضحة (منتج، لوجو، شخصية، عربية). الخلفية بتتشال لوحدها، ولو الصورة PNG شفافة بتتاخد زي ما هي.</span></div>' +
        '<div class="card"><span class="label">الجودة</span>' + MZ.seg('d3Quality', prefs.d3Quality, [['fast', 'سريع'], ['good', 'كويس'], ['best', 'أعلى جودة']]) +
        '<span class="hint">' + (prefs.d3Quality === 'best' ? 'أدق شكل، وبياخد وقت وحجم أكبر.' : prefs.d3Quality === 'fast' ? 'للتجربة السريعة.' : 'أحسن توازن بين السرعة والجودة.') + d3Size() + '. بيشتغل على أي كارت شاشة، ولو مفيش كارت بيشتغل على المعالج بس أبطأ.</span>' +
        MZ.check('d3Camera', 'ضيف كاميرا جاهزة') + MZ.check('d3Orbit', 'الكاميرا تلف حوالين الموديل') + MZ.check('d3Light', 'ضيف إضاءة') + MZ.check('aiGpu', 'استخدم كارت الشاشة') +
        (running ? '<div class="bar"><span id="d3Bar" style="width:0%"></span></div><button class="btn" data-x="d3Cancel">إلغاء</button>' : '<button class="btn primary" data-x="d3Go">حوّل لـ 3D</button>') + '</div>';
    };
    MZ.handlers.d3Pick = function () {
      var r = window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx ? window.cep.fs.showOpenDialogEx(false, false, 'اختار صورة', '', ['png', 'jpg', 'jpeg', 'webp', 'bmp', 'tif', 'tiff']) : null;
      if (r && r.data && r.data[0]) { d3Img = r.data[0]; MZ.render(); }
    };
    MZ.handlers.d3Sel = function () {
      MZ.hostReady.then(function () { return MZ.call('mz_selectedStill'); }).then(function (r) {
        if (r.ok && r.path) { d3Img = r.path; MZ.render(); } else MZ.status('حدد لير صورة في الكومب', 'err');
      });
    };
    MZ.handlers.d3Cancel = function () { MZ.cancelJob(d3Job); };
    MZ.make3d = function (img) {
      img = img || d3Img;
      if (!img) return Promise.resolve(MZ.status(MZ.ERR.NO_IMAGE, 'err'));
      if (d3Job) return Promise.resolve();
      var J = d3Job = { cancelled: false }, t0 = Date.now(), q = Q[prefs.d3Quality] || Q.good;
      MZ.render();
      if (!fs.existsSync(LIB)) fs.mkdirSync(LIB, { recursive: true });
      var base = clean(path.basename(img)), name = base, n = 2;
      while (fs.existsSync(path.join(LIB, name + '.glb'))) name = base + ' ' + (n++);
      var out = path.join(LIB, name + '.glb'), job = { src: img, out: out, preview: path.join(LIB, name + '.png'), res: q.res, tex: q.tex, name: name };
      var stop = function (msg, k) { d3Job = null; MZ.render(); MZ.status(msg, k); };
      var bar = function (p, dl) {
        var el = document.getElementById('d3Bar'); if (el) el.style.width = p + '%';
        if (!dl) MZ.status((p < 8 ? 'بيشيل الخلفية… ' : p < 25 ? 'بيفهم شكل الحاجة… ' : p < 70 ? 'بيبني الشكل… ' : 'بيلوّن الموديل… ') + p + '%', 'busy');
      };
      var step = function (txt, p) { MZ.status(txt, 'busy'); var el = document.getElementById('d3Bar'); if (el && p !== null && p !== undefined) el.style.width = p + '%'; };
      return E.ensure('mSeg', step, J).then(function (seg) {
        job.segModel = seg; return E.ensure(q.enc, step, J);
      }).then(function (enc) {
        job.encModel = enc; return E.ensure('m3dDec', step, J);
      }).then(function (dec) {
        job.decModel = dec;
        return runAI('to3d', 'm3dDec', job, bar, J);
      }).then(function (res) {
        E.log('3d done', JSON.stringify(res), Math.round((Date.now() - t0) / 1000) + 's');
        return MZ.call('mz_import3d', out, name, { camera: !!prefs.d3Camera, orbit: !!prefs.d3Orbit, light: !!prefs.d3Light });
      }).then(function (r) {
        if (!r.ok) throw { mz: MZ.errText(r) };
        stop('الموديل دخل «' + r.comp + '» · ' + Math.round((Date.now() - t0) / 1000) + ' ثانية');
        return r;
      }).catch(function (e) {
        if (e && e.message === 'CANCELLED') return stop('اتلغى');
        if (e && e.mz) return stop(e.mz, 'err');
        E.log('3d failed', e);
        stop('حصل خطأ: ' + (e && e.message ? e.message : e), 'err');
      });
    };
    MZ.handlers.d3Go = function () { return MZ.make3d(); };
    MZ.PAGES.models = function (t) {
      var list = fs.existsSync(LIB) ? fs.readdirSync(LIB).filter(function (n) { return /\.glb$/i.test(n); }).sort() : [];
      return MZ.pageHead(t) + '<div class="card">' + (list.length ? '<div class="kinds">' + list.map(function (n) {
        var pv = path.join(LIB, n.replace(/\.glb$/i, '.png'));
        return '<button class="btn" data-x="d3Use" data-n="' + esc(n) + '" style="height:auto;flex-direction:column;padding:8px">' +
          (fs.existsSync(pv) ? '<img src="file:///' + encodeURI(pv.replace(/\\/g, '/')) + '" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px">' : '') +
          '<span style="font-size:12px">' + esc(n.replace(/\.glb$/i, '')) + '</span></button>';
      }).join('') + '</div>' : '<span class="hint">لسه مفيش موديلات. اعمل أول واحد من «صورة لموديل 3D».</span>') +
        '<button class="btn" data-x="d3Open">افتح الفولدر</button></div>';
    };
    MZ.handlers.d3Use = function (b) {
      var f = path.join(LIB, b.dataset.n);
      return MZ.run('mz_import3d', [f, b.dataset.n.replace(/\.glb$/i, ''), { camera: !!prefs.d3Camera, orbit: false, light: !!prefs.d3Light }], function (r) { return 'الموديل دخل «' + r.comp + '»'; });
    };
    MZ.handlers.d3Open = function () { try { if (!fs.existsSync(LIB)) fs.mkdirSync(LIB, { recursive: true }); E.cp.spawn('explorer.exe', [LIB], { detached: true, stdio: 'ignore' }).unref(); } catch (e) {} };
  }
  MZ.render();
})();
