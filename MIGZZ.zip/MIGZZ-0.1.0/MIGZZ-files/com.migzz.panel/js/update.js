/* MIGZZ — panel: updates. Every time the panel opens it reads latest.json from the GitHub repo;
   when there is a newer one it shows a bar, and one click downloads it and swaps the panel's files in place. */
(function () {
  'use strict';
  var MZ = window.MZ, E = window.MZE;
  if (!MZ || !E || !E.NODE || !window.__adobe_cep__) return;
  var REPO = 'omarmagdywork-dev/MIGZZ';
  var fs = E.fs, path = E.path, prefs = MZ.prefs, esc = MZ.esc;
  var latest = null, busy = false;

  function extDir() { return decodeURI(window.__adobe_cep__.getSystemPath('extension')).replace(/^file:\/\/\/?/, ''); }
  // 0.10.0 > 0.9.2
  function newer(a, b) {
    var x = String(a).replace(/^v/, '').split('.').map(Number), y = String(b).replace(/^v/, '').split('.').map(Number);
    for (var i = 0; i < 3; i++) { if ((x[i] || 0) > (y[i] || 0)) return true; if ((x[i] || 0) < (y[i] || 0)) return false; }
    return false;
  }

  // the bar sits right under the search box (above the download bar)
  var bar = document.createElement('button');
  bar.type = 'button'; bar.className = 'dlbar upbar'; bar.hidden = true;
  var dl = document.getElementById('dlbar');
  if (dl) dl.parentNode.insertBefore(bar, dl);
  bar.addEventListener('click', function () { openSheet(); });

  // the repo keeps latest.json next to the zip: { "version": "0.2.0", "zip": "MIGZZ.zip", "notes": "…" }
  var RAW = 'https://raw.githubusercontent.com/' + REPO + '/main/';
  function check() {
    return E.getJSON(RAW + 'latest.json?t=' + Date.now()).then(function (r) {
      var tag = String(r.version || '').replace(/^v/, '');
      E.log('update check', 'have ' + MZ.VERSION, 'latest ' + tag);
      if (!tag || !r.zip || !newer(tag, MZ.VERSION)) { bar.hidden = true; return null; }
      latest = { ver: tag, url: 'https://github.com/' + REPO + '/raw/main/' + encodeURIComponent(r.zip), mb: Math.max(1, Math.round((r.bytes || 600000) / 1e6)), notes: String(r.notes || '').trim(), page: 'https://github.com/' + REPO };
      bar.innerHTML = '<span class="dlicon"></span><span class="dltext">فيه نسخة جديدة من MIGZZ (' + esc(latest.ver) + ') · دوس هنا تحدّث</span>';
      bar.hidden = false;
      return latest;
    }).catch(function (e) { E.log('update check failed', e && e.message); return null; });   // offline: just try next time
  }

  function openSheet(msg) {
    if (!latest) return;
    var sheet = document.getElementById('sheet');
    sheet.innerHTML = '<div class="sheet" role="dialog" aria-label="تحديث MIGZZ">' +
      '<div class="sheet-top"><b>نسخة جديدة: ' + esc(latest.ver) + '</b><button class="iconbtn" data-close aria-label="اقفل">×</button></div>' +
      '<p>عندك ' + esc(MZ.VERSION) + '. التحديث حجمه حوالي ' + latest.mb + ' ميجا، والموديلات اللي اتحمّلت قبل كده مش هتتحمّل تاني.</p>' +
      (latest.notes ? '<span class="k">الجديد</span><p class="how">' + esc(latest.notes) + '</p>' : '') +
      '<p class="how" id="upMsg">' + (msg ? esc(msg) : 'البانل هيقفل ويفتح لوحده بعد التحديث. لو الافتر وبريمير مفتوحين، اقفل البانل في التاني وافتحه.') + '</p>' +
      '<div class="row" style="grid-template-columns:1fr 1fr"><button class="btn" data-up="later">بعدين</button><button class="btn primary" data-up="go"' + (busy ? ' disabled' : '') + '>حدّث دلوقتي</button></div>' +
    '</div>';
    sheet.hidden = false;
  }
  function say(t) { var m = document.getElementById('upMsg'); if (m) m.textContent = t; MZ.status(t, 'busy'); }

  function install() {
    if (busy || !latest) return;
    busy = true; openSheet('بيبدأ…');
    var work = path.join(E.DATA, 'update'), zip = path.join(work, 'MIGZZ-' + latest.ver + '.zip'), out = path.join(work, latest.ver);
    E.rmrf(out); E.mkdirp(work);
    E.download(latest.url, zip, function (got, total) {
      say('بينزّل التحديث · ' + (total ? Math.round(got / total * 100) + '%' : Math.round(got / 1e6) + ' ميجا'));
    }).then(function () {
      say('بيفك التحديث…');
      return E.unzip(zip, out);
    }).then(function () {
      // find the panel folder inside the zip
      var src = null;
      (function find(d, depth) {
        if (src || depth > 3) return;
        fs.readdirSync(d).forEach(function (n) {
          var p = path.join(d, n);
          if (src || !fs.statSync(p).isDirectory()) return;
          if (n === 'com.migzz.panel' && fs.existsSync(path.join(p, 'CSXS', 'manifest.xml'))) src = p; else find(p, depth + 1);
        });
      })(out, 0);
      if (!src) throw new Error('الملف اللي اتنزّل ناقص');
      say('بيركّب التحديث…');
      fs.cpSync(src, extDir(), { recursive: true, force: true });
      E.log('updated', MZ.VERSION, '->', latest.ver);
      try { fs.unlinkSync(zip); } catch (e) {}
      E.rmrf(out);
      say('اتحدّث لـ ' + latest.ver + ' · البانل بيفتح من جديد…');
      setTimeout(function () { location.replace('index.html?v=' + Date.now()); }, 1200);
    }).catch(function (e) {
      busy = false;
      E.log('update failed', e && e.message);
      openSheet('التحديث موقفش كويس: ' + (e && e.message || e) + '. جرّب تاني، أو نزّل النسخة الجديدة من صفحة MIGZZ على GitHub.');
      MZ.status('التحديث ما كملش', 'err');
    });
  }

  document.getElementById('sheet').addEventListener('click', function (e) {
    var b = e.target.closest('[data-up]');
    if (!b) return;
    if (b.dataset.up === 'go') install();
    else { var sh = document.getElementById('sheet'); sh.hidden = true; sh.innerHTML = ''; }
  });

  MZ.checkUpdate = check;   // for tests
  setTimeout(check, 4000);
})();
