/* MIGZZ — panel: Premiere-only tools (silence cut, podcast multicam) and Premiere versions of shared tools. */
(function () {
  'use strict';
  var MZ = window.MZ, E = window.MZE;
  if (!MZ || MZ.HOST !== 'pr' || !E || !E.NODE) return;
  var prefs = MZ.prefs, esc = MZ.esc;
  MZ.defaults({ slDb: -38, slMin: 0.5, slPad: 0.12, slWork: false, pcMin: 2, pcWide: -1, pcMap: {} });
  MZ.tool('edit', 'silence').run = { page: 'silence' };
  MZ.tool('edit', 'podcast').run = { page: 'podcast' };
  Object.assign(MZ.ERR, { PC_NEED: 'محتاج كاميرتين وتراكين صوت على الأقل (كل متكلم له مايك)', PC_FAIL: 'مقدرتش أقرا صوت المايكات' });
  MZ.fmt.db = function (v) { return v + ' dB'; };

  function ff() { return E.ensure('ffmpeg', function (t) { MZ.status(t, 'busy'); }); }

  // ───────── silence cut
  var slPlan = null, slInfo = null, slBusy = false;
  MZ.PAGES.silence = function (t) {
    var removed = slPlan ? slPlan.removed : 0;
    return MZ.pageHead(t) +
      '<div class="card">' + MZ.range('slDb', 'أي صوت أوطى من كده يعتبر سكوت', -60, -20, 1, 'db') +
      MZ.range('slMin', 'أقل طول للسكتة اللي تتشال', 0.2, 2, 0.05, 'sec') + MZ.range('slPad', 'سيب نفَس قبل وبعد الكلام', 0, 0.4, 0.02, 'sec') +
      MZ.check('slWork', 'بين In و Out بس') +
      '<span class="hint">حدد الكليب (الفيديو بالصوت بتاعه). الأصلي مش بيتغير: بتتعمل سيكوانس جديدة فيها الكلام بس.</span>' +
      '<button class="btn" data-x="slPreview"' + (slBusy ? ' disabled' : '') + '>عاين</button>' +
      (slPlan ? '<span class="label">هيتشال <b>' + slPlan.cuts + '</b> سكتة، مجموعها <b>' + removed.toFixed(1) + ' ث</b> من ' + slPlan.total.toFixed(1) + ' ث</span>' +
        '<button class="btn primary" data-x="slGo">اقطع السكتات</button>' : '') + '</div>';
  };
  function detect(info) {
    return ff().then(function (f) {
      var out = '';
      return E.run(f, ['-hide_banner', '-nostats', '-ss', info.a.toFixed(3), '-t', (info.b - info.a).toFixed(3), '-i', info.path, '-vn', '-af',
        'silencedetect=noise=' + prefs.slDb + 'dB:d=' + prefs.slMin, '-f', 'null', '-'], function (l) { out += l + '\n'; }).then(function () {
        var sil = [], m, re = /silence_start: ([\d.]+)[\s\S]*?silence_end: ([\d.]+)/g, s0 = /silence_start: ([\d.]+)/g;
        while ((m = re.exec(out))) sil.push([Number(m[1]), Number(m[2])]);
        var starts = []; while ((m = s0.exec(out))) starts.push(Number(m[1]));
        if (starts.length > sil.length) sil.push([starts[starts.length - 1], info.b - info.a]);   // silent till the end
        // keep = everything that is not silence, with a little breathing room
        var keep = [], cur = 0, dur = info.b - info.a, pad = prefs.slPad;
        sil.forEach(function (s) {
          var a = Math.max(cur, s[0] + pad), b = Math.min(dur, s[1] - pad);
          if (b - a < 0.05) return;
          if (a > cur) keep.push([cur, a]);
          cur = b;
        });
        if (cur < dur) keep.push([cur, dur]);
        keep = keep.filter(function (k) { return k[1] - k[0] > 0.04; }).map(function (k) { return [info.a + k[0], info.a + k[1]]; });
        var kept = keep.reduce(function (s, k) { return s + k[1] - k[0]; }, 0);
        return { keep: keep, cuts: Math.max(0, keep.length - 1) + (keep.length && keep[0][0] > info.a + 0.05 ? 1 : 0), removed: dur - kept, total: dur };
      });
    });
  }
  MZ.handlers.slPreview = function () {
    slBusy = true; MZ.render(); MZ.status('بيسمع الكليب…', 'busy');
    return MZ.hostReady.then(function () { return MZ.call('mz_captionInfo', !!prefs.slWork); }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      slInfo = r;
      return detect(r);
    }).then(function (plan) {
      slPlan = plan; slBusy = false; MZ.render();
      MZ.status(plan.cuts ? 'شوف الأرقام ودوس اقطع' : 'مفيش سكتات بالإعدادات دي');
      return plan;
    }).catch(function (e) { slBusy = false; MZ.render(); MZ.status(e && e.mz ? e.mz : 'حصل خطأ: ' + (e && e.message || e), 'err'); });
  };
  MZ.handlers.slGo = function () {
    if (!slPlan) return;
    return MZ.run('mz_silenceCut', [slPlan.keep, slInfo.id], function (r) { slPlan = null; setTimeout(MZ.render, 0); return 'اتعملت «' + r.name + '» · ' + r.parts + ' جزء، طولها ' + r.len.toFixed(1) + ' ث'; });
  };
  ['slDb', 'slMin', 'slPad'].forEach(function (k) { MZ.onRange[k] = function () { if (slPlan) { slPlan = null; MZ.render(); } }; });

  // ───────── podcast multicam
  var pcInfo = null, pcBusy = false;
  MZ.PAGES.podcast = function (t) {
    var body = '';
    if (pcInfo) {
      var cams = pcInfo.video, mics = pcInfo.audio;
      body = '<div class="card"><span class="label">كل مايك ← الكاميرا بتاعة صاحبه</span>' + mics.map(function (m) {
        var cur = prefs.pcMap[m.track] !== undefined ? prefs.pcMap[m.track] : (cams[mics.indexOf(m)] || cams[0]).track;
        prefs.pcMap[m.track] = cur;
        return '<span class="hint">A' + (m.track + 1) + ' · ' + esc(m.name) + '</span><div class="seg">' + cams.map(function (c) {
          return '<button class="' + (cur === c.track ? 'on' : '') + '" data-x="pcMap" data-a="' + m.track + '" data-v="' + c.track + '">V' + (c.track + 1) + '</button>';
        }).join('') + '</div>';
      }).join('') +
        '<span class="label">لما محدش بيتكلم أو الاتنين مع بعض</span><div class="seg"><button class="' + (prefs.pcWide < 0 ? 'on' : '') + '" data-x="pcWide" data-v="-1">سيب آخر واحد</button>' +
        cams.map(function (c) { return '<button class="' + (prefs.pcWide === c.track ? 'on' : '') + '" data-x="pcWide" data-v="' + c.track + '">V' + (c.track + 1) + ' (واسعة)</button>'; }).join('') + '</div>' +
        MZ.range('pcMin', 'أقل مدة للقطة', 0.8, 6, 0.2, 'sec') +
        '<span class="hint">بيتعمل نسخة من السيكوانس اسمها «… بودكاست»، وفيها الكاميرات بتتقطع وبيتقفل اللي مش بيتكلم. الصوت مش بيتلمس.</span>' +
        '<button class="btn primary" data-x="pcGo"' + (pcBusy ? ' disabled' : '') + '>وزّع الكاميرات</button></div>';
    }
    return MZ.pageHead(t) + '<div class="card"><span class="hint">حط كل كاميرا على تراك فيديو (V1، V2…) وكل مايك على تراك صوت، ويكونوا متزامنين. وبعدين دوس اقرا السيكوانس.</span>' +
      '<button class="btn" data-x="pcRead">اقرا السيكوانس</button></div>' + body;
  };
  MZ.handlers.pcRead = function () {
    return MZ.run('mz_podcastInfo', [], function (r) {
      if (r.video.length < 2 || r.audio.length < 2) { pcInfo = null; setTimeout(MZ.render, 0); return MZ.ERR.PC_NEED; }
      pcInfo = r; setTimeout(MZ.render, 0);
      return r.video.length + ' كاميرا و' + r.audio.length + ' مايك';
    });
  };
  MZ.handlers.pcMap = function (b) { prefs.pcMap[b.dataset.a] = Number(b.dataset.v); MZ.savePrefs(); MZ.render(); };
  MZ.handlers.pcWide = function (b) { prefs.pcWide = Number(b.dataset.v); MZ.savePrefs(); MZ.render(); };
  // loudness of one mic every 100 ms (timeline time)
  function micLevels(f, m, end) {
    return new Promise(function (resolve, reject) {
      var SR = 8000, hop = 800, chunks = [], size = 0;
      var p = E.cp.spawn(f, ['-hide_banner', '-loglevel', 'error', '-ss', m.inP.toFixed(3), '-t', (m.end - m.start).toFixed(3), '-i', m.path, '-vn', '-ac', '1', '-ar', String(SR), '-f', 's16le', '-'], { windowsHide: true });
      p.stdout.on('data', function (d) { chunks.push(d); size += d.length; });
      p.on('error', reject);
      p.on('close', function () {
        var buf = Buffer.concat(chunks, size), n = Math.floor(buf.length / 2), N = Math.ceil(end * 10), lv = new Float32Array(N).fill(-100);
        var off = Math.round(m.start * 10);
        for (var w = 0; w * hop < n; w++) {
          var s = 0, c = 0;
          for (var i = w * hop; i < Math.min(n, (w + 1) * hop); i++) { var v = buf.readInt16LE(i * 2) / 32768; s += v * v; c++; }
          var k = off + w; if (k >= 0 && k < N) lv[k] = 10 * Math.log10(s / Math.max(1, c) + 1e-10);
        }
        resolve(lv);
      });
    });
  }
  function speakerTimeline(levels, mics, end) {
    var N = Math.ceil(end * 10), act = new Int16Array(N), M = levels.length;
    // each mic is compared to its own noise floor (the quiet 20 %), and the others' bleed is ignored by asking for a clear lead
    var floors = levels.map(function (lv) { var a = Array.prototype.slice.call(lv).filter(function (x) { return x > -99; }).sort(function (x, y) { return x - y; }); return a.length ? a[Math.floor(a.length * 0.2)] : -60; });
    for (var t = 0; t < N; t++) {
      var best = -1, bv = -1e9, second = -1e9;
      for (var m = 0; m < M; m++) {
        var s = 0, c = 0;
        for (var u = Math.max(0, t - 3); u <= Math.min(N - 1, t + 3); u++) { s += levels[m][u]; c++; }   // ±0.3 s
        var v = s / c - floors[m];
        if (v > bv) { second = bv; bv = v; best = m; } else if (v > second) second = v;
      }
      act[t] = bv > 8 && bv - second > 4 ? best : -1;
    }
    // shots: switch only for a speaker who holds the floor, never shorter than the minimum
    var minF = Math.round(prefs.pcMin * 10), segs = [], cur = act[0] >= 0 ? act[0] : 0, start = 0;
    for (var i = 1; i < N; i++) {
      if (act[i] === cur || act[i] < 0 && prefs.pcWide < 0) continue;
      var j = i; while (j < N && act[j] === act[i]) j++;
      if (j - i < 5) continue;                                        // a short reaction doesn't cut
      if (i - start < minF) continue;
      segs.push([start / 10, i / 10, cur]); cur = act[i]; start = i;
    }
    segs.push([start / 10, end, cur]);
    // merge same-camera neighbours
    var out = [];
    segs.forEach(function (s) { if (out.length && out[out.length - 1][2] === s[2]) out[out.length - 1][1] = s[1]; else out.push(s.slice()); });
    return out;
  }
  MZ.handlers.pcGo = function () {
    if (!pcInfo) return;
    pcBusy = true; MZ.render(); MZ.status('بيسمع المايكات…', 'busy');
    var mics = pcInfo.audio, end = pcInfo.end;
    return ff().then(function (f) { return Promise.all(mics.map(function (m) { return micLevels(f, m, end); })); }).then(function (levels) {
      var segs = speakerTimeline(levels, mics, end).map(function (s) {
        var tr = s[2] < 0 ? prefs.pcWide : prefs.pcMap[mics[s[2]].track];
        return [s[0], s[1], tr];
      });
      var cams = pcInfo.video.map(function (c) { return c.track; });
      E.log('podcast', segs.length + ' shots');
      return MZ.call('mz_podcastApply', segs, cams);
    }).then(function (r) {
      pcBusy = false; MZ.render();
      if (!r.ok) return MZ.status(MZ.errText(r), 'err');
      MZ.status('اتعملت «' + r.name + '» · ' + (r.cuts + 1) + ' لقطة');
      return r;
    }).catch(function (e) { pcBusy = false; MZ.render(); E.log('podcast failed', e); MZ.status(MZ.ERR.PC_FAIL, 'err'); });
  };

  // ───────── safe-zone guide: a transparent PNG at the sequence size
  var ZONES = { reels: ['Reels', 0.13, 0.22, 0.11, 0.03], tiktok: ['TikTok', 0.08, 0.25, 0.13, 0.05], shorts: ['Shorts', 0.08, 0.25, 0.12, 0.03] };
  MZ.safePr = function (platform) {
    var Z = ZONES[platform];
    MZ.status('شغال…', 'busy');
    return MZ.hostReady.then(function () { return MZ.call('mz_seqSize'); }).then(function (s) {
      if (!s.ok) throw { mz: MZ.errText(s) };
      if (!Z) return MZ.call('mz_safeGuidePr', '', platform);
      var W = s.w, H = s.h, t = Math.round(H * Z[1]), b = Math.round(H * Z[2]), r = Math.round(W * Z[3]), l = Math.round(W * Z[4]);
      var dir = E.path.join(E.DATA, 'guides'); if (!E.fs.existsSync(dir)) E.fs.mkdirSync(dir, { recursive: true });
      var file = E.path.join(dir, platform + ' ' + W + 'x' + H + '.png');
      var make = E.fs.existsSync(file) ? Promise.resolve() : ff().then(function (f) {
        var red = 'red@0.35', side = 'red@0.25';
        return E.run(f, ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=black@0.0:s=' + W + 'x' + H + ',format=rgba', '-frames:v', '1', '-vf',
          ['drawbox=x=0:y=0:w=' + W + ':h=' + t + ':color=' + red + ':t=fill', 'drawbox=x=0:y=' + (H - b) + ':w=' + W + ':h=' + b + ':color=' + red + ':t=fill',
            'drawbox=x=' + (W - r) + ':y=' + t + ':w=' + r + ':h=' + (H - t - b) + ':color=' + side + ':t=fill', 'drawbox=x=0:y=' + t + ':w=' + l + ':h=' + (H - t - b) + ':color=' + side + ':t=fill'].join(','),
          file]);
      });
      return make.then(function () { return MZ.call('mz_safeGuidePr', file, Z[0]); });
    }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      MZ.status(r.removed ? 'الدليل اتشال' : 'اتحط دليل ' + Z[0] + ' فوق كل حاجة (اقفل عين التراك قبل الإكسبورت)');
    }).catch(function (e) { MZ.status(e && e.mz ? e.mz : 'حصل خطأ: ' + (e && e.message || e), 'err'); });
  };
  MZ._speakerTimeline = speakerTimeline;
  MZ.render();
})();
