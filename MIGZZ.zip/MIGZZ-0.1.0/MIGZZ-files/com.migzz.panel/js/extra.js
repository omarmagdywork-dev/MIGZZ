/* MIGZZ — panel: liquid glass · image background removal · 3D text · 3D carousel (After Effects). */
(function () {
  'use strict';
  var MZ = window.MZ, E = window.MZE;
  if (!MZ || MZ.HOST !== 'ae') return;
  var prefs = MZ.prefs, esc = MZ.esc;
  Object.assign(MZ.I, {
    glass: 'M5 6a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3zM8 7c1-1 3-1 4 0',
    cutimg: 'M4 4h16v16H4zM9 9a2 2 0 1 0 0.01 0M20 15l-5-5-11 11',
    text3d: 'M4 7h10M9 7v12M14 9l6-3v12l-6 3M14 9v12',
    carousel: 'M12 6a9 3 0 1 0 0.01 0M5 12v4M19 12v4M12 15v5'
  });
  Object.assign(MZ.ERR, { AE_OLD_FRAME: 'الافتر ده قديم على الأداة دي (محتاج 2023 أو أحدث)', CAROUSEL_MIN: 'حدد 3 لايرز أو أكتر (صور أو كليبات)', IMG_ONLY: 'حدد لير صورة (PNG أو JPG)' });
  MZ.defaults({ glKind: 'card', glBlur: 10, glRefract: 50, glBevel: 28, glLight: 45, glUseFx: '', t3Depth: 60, t3Bevel: 6, t3Light: true, crFace: true, crDir: 1, crDur: 8 });
  MZ.TOOLS.tools.unshift({ k: 'glass', on: 'ae', run: { page: 'glass' }, runOn: 'ae', name: 'زجاج سائل (Liquid Glass)', sub: 'كارت أو زرار زجاج بيكسر اللي وراه زي آيفون', d: 'بيعمل قطعة زجاج حقيقية فوق الفيديو: بتكسر الصورة اللي وراها عند الحواف، وفيها بلر خفيف ولمعة على الحرف وظل ناعم. بتتحرك وتكبر وتلف من Null واحد، وكل حاجة فيها بتتظبط بسلايدرز.', h: 'حدد الفيديو اللي عايز الزجاج فوقه.\nاختار الشكل ودوس ضيف.\nحرّك «MIGZZ زجاج · تحكم» علشان تحرك الزجاج.', where: 'جوه الافتر' });
  MZ.TOOLS.ai.push({ k: 'cutimg', on: 'ae', run: { page: 'cutimg' }, runOn: 'ae', name: 'شيل خلفية صورة', sub: 'منتج أو شخص أو لوجو من غير خلفية', d: 'بيشيل خلفية أي صورة في الكومب ويحط نسخة شفافة مكانها، والأصل بيفضل مخفي لو احتجته.', h: 'حدد لير الصورة.\nدوس شيل الخلفية.', where: 'بيشتغل على جهازك من غير نت' });
  MZ.TOOLS.d3.push({ k: 'text3d', on: 'ae', run: { page: 'text3d' }, runOn: 'ae', name: 'نص 3D', sub: 'نص بعمق وحواف وإضاءة', d: 'بيحوّل النص لنص 3D حقيقي بعمق وحواف مشطوفة، ويضيف إضاءة. لو مفيش نص محدد بيعمل نص جديد.', h: 'حدد النص (أو ولا حاجة).\nظبط العمق والحواف.\nدوس اعمل.', where: 'جوه الافتر' },
    { k: 'carousel', on: 'ae', run: { page: 'carousel' }, runOn: 'ae', name: 'كاروسيل 3D', sub: 'الصور تلف في دايرة 3D', d: 'بيرص الصور أو الكليبات المحددة في دايرة 3D وبيخليها تلف، والسرعة والاتجاه بيتظبطوا.', h: 'حدد 3 صور أو أكتر.\nاختار المدة والاتجاه.\nدوس اعمل.', where: 'جوه الافتر' });

  // ───────── liquid glass
  var glassFx = null;
  MZ.PAGES.glass = function (t) {
    if (glassFx === null) { glassFx = []; MZ.hostReady.then(function () { return MZ.call('mz_findFx', 'liquid\\s*glass'); }).then(function (r) { if (r.ok) { glassFx = r.list; MZ.render(); } }); }   // a liquid-glass plugin the user owns (e.g. ToolsForMotion)
    return MZ.pageHead(t) +
      '<div class="card"><div style="height:110px;border-radius:12px;background:linear-gradient(135deg,#F5A524,#ff5f6d 45%,#4facfe);display:flex;align-items:center;justify-content:center">' +
      '<div style="width:' + (prefs.glKind === 'circle' ? 70 : prefs.glKind === 'pill' ? 160 : 150) + 'px;height:' + (prefs.glKind === 'card' ? 80 : 70) + 'px;border-radius:' + (prefs.glKind === 'card' ? 18 : 40) + 'px;background:rgba(255,255,255,.12);backdrop-filter:blur(' + Math.round(prefs.glBlur / 2) + 'px) saturate(140%);box-shadow:inset 0 1px 1px rgba(255,255,255,.7),0 8px 20px rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.35)"></div></div>' +
      '<span class="label">الشكل</span>' + MZ.seg('glKind', prefs.glKind, [['card', 'كارت'], ['pill', 'زرار'], ['circle', 'دايرة']]) + '</div>' +
      '<div class="card">' + MZ.range('glBlur', 'البلر', 0, 40, 1) + MZ.range('glRefract', 'الانكسار عند الحواف', 0, 100, 1) + MZ.range('glBevel', 'سُمك الحافة', 4, 60, 1) + MZ.range('glLight', 'اللمعة', 0, 100, 1) +
      (glassFx.length ? '<span class="label">إيفكت الزجاج</span>' + MZ.seg('glUseFx', prefs.glUseFx, [['', 'المدمج في MIGZZ']].concat(glassFx.map(function (x) { return [x.match, x.name]; }))) +
        '<span class="hint">لقيت عندك إيفكت زجاج متسطب. لو اخترته هيتستخدم بداله، بس اللي هيفتح المشروع على جهاز تاني لازم يكون عنده نفس الإيفكت.</span>' : '') +
      '<span class="hint">حدد الفيديو اللي الزجاج هيبقى فوقه. كل السلايدرز موجودة كمان على «MIGZZ زجاج · تحكم» في Effect Controls، وتقدر تعملهم كيفريمز.</span>' +
      '<button class="btn primary" data-x="glGo">ضيف زجاج</button></div>';
  };
  MZ.handlers.glGo = function () {
    var k = prefs.glKind, w = k === 'circle' ? 360 : k === 'pill' ? 520 : 640, h = k === 'circle' ? 360 : k === 'pill' ? 150 : 380;
    return MZ.run('mz_glass', [{ kind: k, w: w, h: h, blur: prefs.glBlur, refract: prefs.glRefract, bevel: prefs.glBevel, light: prefs.glLight, useFx: prefs.glUseFx || '' }], function (r) { return 'اتعمل «' + r.name + '» (' + r.fx + '): حرّك الـ Null علشان تحرّكه'; });
  };

  // ───────── image background removal
  MZ.PAGES.cutimg = function (t) {
    return MZ.pageHead(t) + '<div class="card"><span class="hint">حدد لير صورة في الكومب. أول مرة بينزّل موديل شيل الخلفية (178MB) لو مش متنزّل.</span>' +
      MZ.check('aiGpu', 'استخدم كارت الشاشة') + '<button class="btn primary" data-x="ciGo">شيل الخلفية</button></div>';
  };
  MZ.handlers.ciGo = function () {
    if (!MZ.runAI) return;
    var info, out, t0 = Date.now(), J = { cancelled: false };
    MZ.status('شغال…', 'busy');
    return MZ.hostReady.then(function () { return MZ.call('mz_stillInfo'); }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      info = r;
      var d = E.path.join(E.os.homedir(), 'Downloads', 'MIGZZ', 'Images'); if (!E.fs.existsSync(d)) E.fs.mkdirSync(d, { recursive: true });
      out = E.path.join(d, info.name.replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]/g, '_') + ' cutout ' + (Date.now() % 1e5) + '.png');
      return MZ.runAI('cutimg', 'mSeg', { src: info.path, out: out }, function (p) { MZ.status('بيشيل الخلفية… ' + p + '%', 'busy'); }, J);
    }).then(function () { return MZ.call('mz_cutImageApply', out, info.id); }).then(function (r) {
      if (!r.ok) throw { mz: MZ.errText(r) };
      MZ.status('الخلفية اتشالت · ' + Math.round((Date.now() - t0) / 1000) + ' ث (الأصل مخفي تحتها)');
    }).catch(function (e) { MZ.status(e && e.mz ? e.mz : 'حصل خطأ: ' + (e && e.message || e), 'err'); });
  };

  // ───────── 3D text
  MZ.PAGES.text3d = function (t) {
    return MZ.pageHead(t) + '<div class="card">' + MZ.range('t3Depth', 'العمق', 0, 300, 5) + MZ.range('t3Bevel', 'الحواف المشطوفة', 0, 20, 1) + MZ.check('t3Light', 'ضيف إضاءة') +
      '<span class="hint">الكومب بيتحول لـ Advanced 3D (لازم افتر 2024 أو أحدث). الفونتات العريضة بتطلع أحلى.</span><button class="btn primary" data-x="t3Go">اعمل نص 3D</button></div>';
  };
  MZ.handlers.t3Go = function () { return MZ.run('mz_text3d', [{ depth: prefs.t3Depth, bevel: prefs.t3Bevel, light: !!prefs.t3Light, text: 'MIGZZ' }], function (r) { return '«' + r.name + '» بقى 3D'; }); };

  // ───────── 3D carousel
  MZ.PAGES.carousel = function (t) {
    return MZ.pageHead(t) + '<div class="card">' + MZ.range('crDur', 'لفة كاملة في', 2, 30, 1, 'sec') +
      '<span class="label">الاتجاه</span>' + MZ.seg('crDir', prefs.crDir, [[1, 'يمين'], [-1, 'شمال']]) + MZ.check('crFace', 'الصور دايمًا باصة للكاميرا') +
      '<span class="hint">حدد 3 صور أو كليبات أو أكتر. الحجم والميلان بيتظبطوا من «MIGZZ كاروسيل».</span><button class="btn primary" data-x="crGo">اعمل كاروسيل</button></div>';
  };
  MZ.handlers.crGo = function () { return MZ.run('mz_carousel', [{ dur: prefs.crDur, dir: Number(prefs.crDir), face: !!prefs.crFace }], function (r) { return 'اتعمل كاروسيل من ' + r.count + ' لير'; }); };

  // ───────── transitions with sound
  MZ.I.trans = 'M3 6h7v12H3zM14 6h7v12h-7zM10 12h4M12 10l2 2-2 2';
  MZ.I.textPath = 'M4 17c4-8 12-8 16 0M8 9l1-3h2l1 3M10 7.5h1.5';
  MZ.defaults({ trKind: 'zoom', trDur: 0.6, trSound: true, tpShape: 'circle', tpAnim: true, tpDur: 6 });
  MZ.TOOLS.motion.push({ k: 'trans', on: 'ae', run: { page: 'trans' }, runOn: 'ae', name: 'ترانزيشنز بالصوت', sub: 'زووم، سحبة، لف، فلاش، جليتش + صوت', d: 'بيحط ترانزيشن عند المؤشر بين لقطتين: زووم، سحبة يمين أو شمال، لف، فلاش، أو جليتش، بموشن بلر حقيقي ومعاه صوت وُوش متعمل على جهازك.', h: 'حط المؤشر عند القطع بين اللقطتين.\nاختار الترانزيشن والمدة.\nدوس ضيف.', where: 'جوه الافتر' },
    { k: 'textPath', on: 'ae', run: { page: 'textPath' }, runOn: 'ae', name: 'نص على مسار', sub: 'النص يمشي على دايرة أو قوس أو موجة', d: 'بيخلي النص يمشي على شكل: دايرة بتلف، أو قوس، أو موجة، ويتحرك عليه لو عايز.', h: 'حدد النص.\nاختار الشكل.\nدوس طبّق.', where: 'جوه الافتر' });
  var TR = [['zoom', 'زووم'], ['whipL', 'سحبة شمال'], ['whipR', 'سحبة يمين'], ['spin', 'لف'], ['flash', 'فلاش'], ['glitch', 'جليتش']];
  // procedural sound effects (made once with ffmpeg, then reused)
  var SFX = {
    whoosh: 'anoisesrc=d=0.9:c=pink:a=0.9,afade=t=in:st=0:d=0.42:curve=exp,afade=t=out:st=0.42:d=0.48:curve=log,highpass=f=180,lowpass=f=5200,equalizer=f=900:t=q:w=0.8:g=6,aecho=0.7:0.35:35:0.25,volume=3',
    impact: 'sine=f=52:d=0.7,volume=1.4,afade=t=out:st=0.02:d=0.68:curve=exp[a];anoisesrc=d=0.25:c=white:a=0.6,highpass=f=1500,afade=t=out:st=0:d=0.25:curve=exp[b];[a][b]amix=inputs=2:normalize=0',
    glitch: 'anoisesrc=d=0.55:c=white:a=0.5,acrusher=bits=5:samples=30:mix=1,tremolo=f=22:d=0.95,highpass=f=300,afade=t=out:st=0.25:d=0.3'
  };
  function sfxFor(kind) {
    var name = kind === 'flash' ? 'impact' : kind === 'glitch' ? 'glitch' : 'whoosh';
    var dir = E.path.join(E.DATA, 'sfx'), f = E.path.join(dir, name + '.wav');
    if (E.fs.existsSync(f)) return Promise.resolve(f);
    if (!E.fs.existsSync(dir)) E.fs.mkdirSync(dir, { recursive: true });
    return E.ensure('ffmpeg', function (t) { MZ.status(t, 'busy'); }).then(function (ff) {
      var g = SFX[name], args = /\[a\]/.test(g) ? ['-hide_banner', '-loglevel', 'error', '-y', '-filter_complex', g.replace(/^/, '').replace(/^sine/, 'sine') , '-ac', '2', '-ar', '48000', f]
        : ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', g, '-ac', '2', '-ar', '48000', f];
      return E.run(ff, args).then(function (r) { if (r.code !== 0) { E.log('sfx', r.err); return ''; } return f; });
    });
  }
  MZ._sfxFor = sfxFor;
  MZ.PAGES.trans = function (t) {
    return MZ.pageHead(t) + '<div class="card"><span class="label">الترانزيشن</span><div class="kinds">' + TR.map(function (k) { return '<button class="btn' + (prefs.trKind === k[0] ? ' primary' : '') + '" data-pref="trKind" data-val="' + k[0] + '">' + k[1] + '</button>'; }).join('') + '</div>' +
      MZ.range('trDur', 'المدة', 0.2, 2, 0.05, 'sec') + MZ.check('trSound', 'ضيف صوت للترانزيشن') +
      '<span class="hint">حط المؤشر عند القطع بين اللقطتين ودوس ضيف. الترانزيشن لير Adjustment فوق كل حاجة، تقدر تطوّلها أو تقصّرها.</span><button class="btn primary" data-x="trGo">ضيف ترانزيشن</button></div>';
  };
  MZ.handlers.trGo = function () {
    var kind = prefs.trKind;
    return (prefs.trSound && E && E.NODE ? sfxFor(kind) : Promise.resolve('')).then(function (f) {
      return MZ.run('mz_transition', [kind, Number(prefs.trDur), f || ''], function (r) { return 'اتضاف ترانزيشن' + (r.sound ? ' بالصوت' : ''); });
    });
  };
  MZ.PAGES.textPath = function (t) {
    return MZ.pageHead(t) + '<div class="card"><span class="label">الشكل</span>' + MZ.seg('tpShape', prefs.tpShape, [['circle', 'دايرة'], ['arc', 'قوس'], ['wave', 'موجة']]) +
      MZ.check('tpAnim', 'النص يتحرك على المسار') + MZ.range('tpDur', 'مدة الحركة', 1, 20, 0.5, 'sec') +
      '<span class="hint">حدد لير نص. المسار ماسك اسمه «MIGZZ مسار النص» تقدر تعدّل شكله بإيدك.</span><button class="btn primary" data-x="tpGo">طبّق</button></div>';
  };
  MZ.handlers.tpGo = function () { return MZ.run('mz_textPath', [{ shape: prefs.tpShape, animate: !!prefs.tpAnim, dur: prefs.tpDur }], function () { return 'النص بقى على المسار'; }); };

  // ───────── icon library (Lucide, ISC licence, bundled: no internet)
  MZ.I.icons = 'M12 3l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.4 6.8 19.1l1-5.8-4.3-4.1 5.9-.9z';
  MZ.defaults({ icColor: '#FFFFFF', icWidth: 2, icSize: 300, icDraw: true, icFill: false });
  MZ.TOOLS.lib.push({ k: 'icons', on: 'ae', run: { page: 'icons' }, runOn: 'ae', name: 'مكتبة الأيقونات', sub: 'أكتر من 2000 أيقونة شكل (Shape) تتلوّن وتتحرك', d: 'أيقونات جاهزة جوه البلوجن (من غير نت): سهم، قلب، إيموجي، سوشيال، أدوات… كل واحدة بتدخل Shape Layer تقدر تغيّر لونها وسُمكها، وتظهر بحركة رسم لو عايز.', h: 'دوّر بالعربي أو الإنجليزي.\nاختار اللون والسُمك.\nدوس على الأيقونة.', where: 'جوه الافتر' });
  var ICONS = null, icQ = '', icPage = 0;
  var AR = { 'قلب': 'heart', 'حب': 'heart', 'نجمة': 'star', 'نجوم': 'star', 'كاميرا': 'camera', 'تصوير': 'camera', 'اعدادات': 'settings', 'ترس': 'settings', 'موسيقى': 'music', 'مزيكا': 'music', 'بيت': 'house', 'منزل': 'house', 'رسالة': 'message', 'رسايل': 'message', 'شات': 'message', 'مكان': 'map-pin', 'لوكيشن': 'map-pin', 'خريطة': 'map', 'صاروخ': 'rocket', 'جرس': 'bell', 'اشعار': 'bell', 'بحث': 'search', 'دور': 'search', 'سهم': 'arrow', 'تليفون': 'phone', 'موبايل': 'smartphone', 'ايميل': 'mail', 'بريد': 'mail', 'ساعة': 'clock', 'وقت': 'clock', 'تقويم': 'calendar', 'صورة': 'image', 'صور': 'image', 'فيديو': 'video', 'مايك': 'mic', 'ميكروفون': 'mic', 'شخص': 'user', 'ناس': 'users', 'لايك': 'thumbs-up', 'شير': 'share', 'مشاركة': 'share', 'سلة': 'shopping', 'شراء': 'shopping', 'فلوس': 'dollar', 'محفظة': 'wallet', 'قفل': 'lock', 'نار': 'flame', 'شمس': 'sun', 'قمر': 'moon', 'سحابة': 'cloud', 'مطر': 'cloud-rain', 'عربية': 'car', 'طيارة': 'plane', 'كتاب': 'book', 'قلم': 'pen', 'صح': 'check', 'غلط': 'x', 'تحذير': 'alert', 'هدية': 'gift', 'تاج': 'crown', 'جايزة': 'award', 'كوباية': 'coffee', 'قهوة': 'coffee', 'اكل': 'utensils', 'لعبة': 'gamepad', 'كمبيوتر': 'monitor', 'لابتوب': 'laptop', 'واي فاي': 'wifi', 'نت': 'wifi', 'بطارية': 'battery', 'تشغيل': 'play', 'ايقاف': 'pause', 'صوت': 'volume', 'سماعة': 'headphones', 'يوتيوب': 'youtube', 'انستجرام': 'instagram', 'فيسبوك': 'facebook', 'تويتر': 'twitter', 'لينكدان': 'linkedin', 'تحميل': 'download', 'رفع': 'upload', 'لينك': 'link', 'رابط': 'link', 'عين': 'eye', 'شوف': 'eye', 'جراف': 'chart', 'رسم بياني': 'chart', 'زهرة': 'flower', 'شجرة': 'tree', 'كورة': 'ball', 'مقص': 'scissors', 'مونتاج': 'scissors', 'فيلم': 'film', 'ضوء': 'lightbulb', 'فكرة': 'lightbulb', 'نجاح': 'trophy', 'كاس': 'trophy', 'هدف': 'target', 'برق': 'zap', 'كهربا': 'zap', 'عالم': 'globe', 'لغة': 'languages', 'ملف': 'file', 'فولدر': 'folder', 'سيف': 'save', 'حذف': 'trash', 'مسح': 'trash', 'زائد': 'plus', 'ناقص': 'minus', 'علم': 'flag', 'بوكس': 'box', 'شنطة': 'briefcase', 'شغل': 'briefcase', 'ضحكة': 'smile', 'وش': 'smile', 'حزين': 'frown', 'باب': 'door', 'مفتاح': 'key', 'طبيب': 'stethoscope', 'دوا': 'pill', 'رياضة': 'dumbbell', 'جيم': 'dumbbell' };
  function loadIcons() {
    if (ICONS) return ICONS;
    try { ICONS = JSON.parse(E.fs.readFileSync(E.path.join(decodeURI(window.__adobe_cep__.getSystemPath('extension')).replace(/^file:\/\/\/?/, ''), 'data', 'icons.json'), 'utf8')); } catch (e) { ICONS = {}; }
    return ICONS;
  }
  function iconD(p) {
    return p.map(function (s) {
      var a = s[1], n = a.length / 6, d = '', i;
      for (i = 0; i < n; i++) {
        if (!i) { d += 'M' + a[0] + ' ' + a[1]; continue; }
        d += 'C' + (a[(i - 1) * 6] + a[(i - 1) * 6 + 4]) + ' ' + (a[(i - 1) * 6 + 1] + a[(i - 1) * 6 + 5]) + ' ' + (a[i * 6] + a[i * 6 + 2]) + ' ' + (a[i * 6 + 1] + a[i * 6 + 3]) + ' ' + a[i * 6] + ' ' + a[i * 6 + 1];
      }
      if (s[0]) { var L = (n - 1) * 6; d += 'C' + (a[L] + a[L + 4]) + ' ' + (a[L + 1] + a[L + 5]) + ' ' + (a[0] + a[2]) + ' ' + (a[1] + a[3]) + ' ' + a[0] + ' ' + a[1] + 'Z'; }
      return d;
    }).join(' ');
  }
  function iconHits() {
    var I = loadIcons(), q = icQ.trim().toLowerCase(), en = q;
    Object.keys(AR).forEach(function (k) { if (q && (q === k || q.indexOf(k) >= 0)) en = AR[k]; });
    var names = Object.keys(I);
    if (!q) return names;
    return names.filter(function (n) { return n.indexOf(en) >= 0 || (I[n].t || '').indexOf(en) >= 0; }).sort(function (a, b) { return (a.indexOf(en) === 0 ? 0 : 1) - (b.indexOf(en) === 0 ? 0 : 1) || a.length - b.length; });
  }
  MZ.PAGES.icons = function (t) {
    var I = loadIcons(), hits = iconHits(), per = 96, pages = Math.max(1, Math.ceil(hits.length / per));
    icPage = Math.min(icPage, pages - 1);
    var show = hits.slice(icPage * per, icPage * per + per);
    return MZ.pageHead(t) +
      '<div class="card"><input id="icQ" type="text" placeholder="دوّر: قلب، سهم، heart، arrow…" value="' + esc(icQ) + '" style="height:38px;border-radius:10px;border:1px solid #34353B;background:#1F2024;color:#F2F2F3;padding:0 10px;font-size:13px">' +
      '<div class="color"><span class="label" style="flex:1">اللون</span><input type="color" id="icColor" value="' + prefs.icColor + '"></div>' +
      MZ.range('icWidth', 'سُمك الخط', 0.5, 4, 0.25) + MZ.range('icSize', 'الحجم', 60, 1000, 10) + MZ.check('icDraw', 'تظهر بحركة رسم') + MZ.check('icFill', 'مليانة (Fill)') + '</div>' +
      '<div class="card"><span class="label">' + hits.length + ' أيقونة</span><div style="display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:6px;direction:ltr">' +
      show.map(function (n) {
        return '<button data-x="icAdd" data-n="' + esc(n) + '" title="' + esc(n) + '" style="aspect-ratio:1;border-radius:9px;border:1px solid #2A2B30;background:#1F2024;display:flex;align-items:center;justify-content:center;padding:6px">' +
          '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#F2F2F3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="' + iconD(I[n].p) + '"/></svg></button>';
      }).join('') + '</div>' +
      (pages > 1 ? '<div class="row" style="grid-template-columns:1fr auto 1fr;align-items:center"><button class="btn" data-x="icPrev"' + (icPage ? '' : ' disabled') + '>السابق</button><span class="hint">' + (icPage + 1) + ' / ' + pages + '</span><button class="btn" data-x="icNext"' + (icPage < pages - 1 ? '' : ' disabled') + '>التالي</button></div>' : '') +
      '<span class="hint">الأيقونات من Lucide (رخصة ISC، مجانية حتى للشغل التجاري).</span></div>';
  };
  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'icQ') { icQ = e.target.value; icPage = 0; var pos = e.target.selectionStart; MZ.render(); var n = document.getElementById('icQ'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }
  });
  document.addEventListener('change', function (e) { if (e.target && e.target.id === 'icColor') { prefs.icColor = e.target.value; MZ.savePrefs(); } });
  MZ.handlers.icPrev = function () { icPage = Math.max(0, icPage - 1); MZ.render(); };
  MZ.handlers.icNext = function () { icPage++; MZ.render(); };
  MZ.handlers.icAdd = function (b) {
    var n = b.dataset.n, I = loadIcons(), h = prefs.icColor.replace('#', '');
    if (!I[n]) { MZ.status('الأيقونة «' + n + '» مش موجودة', 'err'); return; }
    var col = [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255];
    return MZ.run('mz_icon', [{ name: n, paths: I[n].p, size: Number(prefs.icSize), color: col, width: Number(prefs.icWidth), fill: !!prefs.icFill, draw: !!prefs.icDraw, dur: 1 }], function () { return 'اتضافت «' + n + '»'; });
  };


  MZ.render();
})();
