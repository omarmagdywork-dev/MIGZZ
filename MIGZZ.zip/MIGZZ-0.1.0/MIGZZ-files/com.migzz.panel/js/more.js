/* MIGZZ — panel: relight · my presets · import from link. Needs js/app.js (window.MZ) and js/engine.js (window.MZE). */
(function () {
  'use strict';
  var MZ = window.MZ, E = window.MZE;
  if (!MZ) return;
  var prefs = MZ.prefs, esc = MZ.esc, AE = MZ.HOST === 'ae';
  Object.assign(MZ.ERR, {
    PRESET_EMPTY: 'مفيش حاجة أحفظها: اللير مفيهاش إيفكتات أو حركة', PRESET_FAIL: 'البريسيت ده مانفعش على اللايرز دي',
    NEED_NODE: 'الأداة دي محتاجة تشتغل جوه البرنامج'
  });
  MZ.defaults({
    rlColor: '#FFD9A0', rlInt: 70, rlSize: 500, rlMode: 'screen', rlSubject: false,
    psFx: true, psAnim: true, psText: true, psFolder: 'عام',
    lnKind: 'video', lnCookies: '', lnLast: 0
  });
  function hex2rgb(h) { h = h.replace('#', ''); return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255]; }
  function downloadsDir(sub) {
    var d = E.path.join(E.os.homedir(), 'Downloads', 'MIGZZ', sub);
    if (!E.fs.existsSync(d)) E.fs.mkdirSync(d, { recursive: true });
    return d;
  }

  // ───────── relight (AE)
  if (AE) {
    var rl = MZ.tool('ai', 'relight'); rl.run = { page: 'relight' }; rl.runOn = 'ae';
    MZ.PAGES.relight = function (t) {
      return MZ.pageHead(t) +
        '<div class="card"><div class="color"><span class="label" style="flex:1">لون النور</span><input type="color" id="rlColor" value="' + prefs.rlColor + '" aria-label="لون النور"></div>' +
        '<div class="kinds">' + [['#FFD9A0', 'دافي'], ['#FFFFFF', 'أبيض'], ['#A8C8FF', 'بارد'], ['#FF6FB5', 'نيون بينك'], ['#5CE1E6', 'نيون أزرق'], ['#FF8A3D', 'غروب']].map(function (c) {
          return '<button class="btn" data-x="rlPick" data-c="' + c[0] + '"><span style="width:14px;height:14px;border-radius:50%;background:' + c[0] + ';display:inline-block"></span>' + c[1] + '</button>';
        }).join('') + '</div>' +
        MZ.range('rlInt', 'القوة', 5, 100, 5, 'pct') + MZ.range('rlSize', 'الحجم', 100, 2000, 50) +
        '<span class="label">نوع النور</span>' + MZ.seg('rlMode', prefs.rlMode, [['screen', 'ناعم'], ['add', 'قوي'], ['soft', 'خفيف جدًا']]) +
        MZ.check('rlSubject', 'النور على الشخص بس (محتاج لير مقصوصة، من «قص الشخص» مثلًا)') + '</div>' +
        '<div class="card"><span class="hint">حدد اللير ودوس ضيف. هتلاقي Null اسمه «MIGZZ إضاءة · المكان»: حركه في المعاينة علشان تحرك النور، واعمله كيفريمز لو عايز النور يمشي. القوة والحجم بتتظبط من Effect Controls، والأوباسيتي بتعمل فلاش.</span>' +
        '<button class="btn primary" data-x="rlApply">ضيف إضاءة</button></div>';
    };
    MZ.handlers.rlPick = function (b) { prefs.rlColor = b.dataset.c; MZ.savePrefs(); var i = document.getElementById('rlColor'); if (i) i.value = b.dataset.c; };
    document.addEventListener('change', function (e) { if (e.target && e.target.id === 'rlColor') { prefs.rlColor = e.target.value; MZ.savePrefs(); } });
    MZ.handlers.rlApply = function () {
      return MZ.run('mz_relight', [{ color: hex2rgb(prefs.rlColor), intensity: prefs.rlInt, size: prefs.rlSize, mode: prefs.rlMode, subject: !!prefs.rlSubject }], function (r) {
        return r.noMatte ? 'اتضافت الإضاءة (القص على الشخص محتاج افتر 2023 أو أحدث)' : 'اتضافت «' + r.name + '»: حرك الـ Null علشان تحرك النور';
      });
    };
  }

  // ───────── my presets (AE): Documents\MIGZZ\Presets\<folder>\*.json | *.ffx
  if (AE && E && E.NODE) {
    var ps = MZ.tool('lib', 'presets'); ps.run = { page: 'presets' }; ps.runOn = 'ae';
    var ROOT = E.path.join(E.os.homedir(), 'Documents', 'MIGZZ', 'Presets');
    var safe = function (s) { return String(s).replace(/[\\/:*?"<>|]/g, '_').trim().slice(0, 60) || 'بدون اسم'; };
    var folders = function () {
      if (!E.fs.existsSync(E.path.join(ROOT, 'عام'))) E.fs.mkdirSync(E.path.join(ROOT, 'عام'), { recursive: true });
      return E.fs.readdirSync(ROOT).filter(function (n) { try { return E.fs.statSync(E.path.join(ROOT, n)).isDirectory(); } catch (e) { return false; } });
    };
    var items = function (f) {
      var d = E.path.join(ROOT, f);
      if (!E.fs.existsSync(d)) return [];
      return E.fs.readdirSync(d).filter(function (n) { return /\.(json|ffx)$/i.test(n); }).sort();
    };
    var KIND = { fx: 'إيفكتات', anim: 'حركة', text: 'ستايل نص' };
    MZ.PAGES.presets = function (t) {
      var fl = folders();
      if (fl.indexOf(prefs.psFolder) < 0) prefs.psFolder = fl[0];
      var list = items(prefs.psFolder);
      return MZ.pageHead(t) +
        '<div class="card"><span class="label">احفظ من اللير المحددة</span>' +
        '<input id="psName" type="text" placeholder="اسم البريسيت" style="height:38px;border-radius:10px;border:1px solid #34353B;background:#1F2024;color:#F2F2F3;padding:0 10px;font-size:13px">' +
        MZ.check('psFx', 'الإيفكتات بإعداداتها وحركتها') + MZ.check('psAnim', 'حركة اللير (المكان والحجم واللف والأوباسيتي)') + MZ.check('psText', 'ستايل النص (الفونت والحجم والألوان)') +
        '<button class="btn primary" data-x="psSave">احفظ في «' + esc(prefs.psFolder) + '»</button></div>' +
        '<div class="card"><span class="label">الفولدرات</span><div class="kinds">' + fl.map(function (f) {
          return '<button class="btn' + (f === prefs.psFolder ? ' primary' : '') + '" data-pref="psFolder" data-val="' + esc(f) + '">' + esc(f) + ' <span style="opacity:.6">' + items(f).length + '</span></button>';
        }).join('') + '<button class="btn" data-x="psNewFolder">+ فولدر جديد</button></div></div>' +
        '<div class="card"><span class="label">البريسيتس في «' + esc(prefs.psFolder) + '» · حدد اللايرز ودوس على البريسيت</span>' +
        (list.length ? '<div class="list">' + list.map(function (n) {
          var ffx = /\.ffx$/i.test(n), meta = '';
          if (!ffx) { try { meta = (JSON.parse(E.fs.readFileSync(E.path.join(ROOT, prefs.psFolder, n), 'utf8')).kinds || []).map(function (k) { return KIND[k]; }).join(' + '); } catch (e) { meta = 'ملف بايظ'; } }
          return '<div class="tool"><button class="main" data-x="psApply" data-n="' + esc(n) + '" style="padding-left:48px"><span class="ttext"><span class="tname">' + esc(n.replace(/\.(json|ffx)$/i, '')) + '</span><span class="tsub">' + (ffx ? 'بريسيت أدوبي (.ffx)' : meta) + '</span></span></button>' +
            '<button class="i" data-x="psDel" data-n="' + esc(n) + '" aria-label="امسح" style="color:#A1A2A9">×</button></div>';
        }).join('') + '</div>' : '<span class="hint">لسه مفيش. احفظ أول بريسيت من فوق، أو حط ملفات .ffx في الفولدر.</span>') +
        '<button class="btn" data-x="psOpen">افتح الفولدر</button></div>';
    };
    MZ.handlers.psSave = function () {
      var nameEl = document.getElementById('psName'), nm = nameEl && nameEl.value.trim();
      return MZ.run('mz_presetGet', [{ fx: !!prefs.psFx, anim: !!prefs.psAnim, text: !!prefs.psText }], function (r) {
        var P = r.preset, base = safe(nm || P.name), dir = E.path.join(ROOT, prefs.psFolder || 'عام'), f = E.path.join(dir, base + '.json'), i = 2;
        if (!E.fs.existsSync(dir)) E.fs.mkdirSync(dir, { recursive: true });
        while (E.fs.existsSync(f)) f = E.path.join(dir, base + ' ' + (i++) + '.json');
        P.name = E.path.basename(f, '.json');
        E.fs.writeFileSync(f, JSON.stringify(P), 'utf8');
        setTimeout(MZ.render, 0);
        return 'اتحفظ «' + P.name + '» (' + P.kinds.map(function (k) { return KIND[k]; }).join(' + ') + ')';
      });
    };
    MZ.handlers.psApply = function (b) {
      var f = E.path.join(ROOT, prefs.psFolder, b.dataset.n);
      if (/\.ffx$/i.test(f)) return MZ.run('mz_applyFfx', [f], function (r) { return 'اتطبق على ' + r.count + ' لير'; });
      var P;
      try { P = JSON.parse(E.fs.readFileSync(f, 'utf8')); } catch (e) { return MZ.status('الملف ده بايظ', 'err'); }
      return MZ.run('mz_presetApply', [P], function (r) { return 'اتطبق «' + P.name + '» على ' + r.count + ' لير' + (r.skipped ? ' (' + r.skipped + ' إعداد متنقلش)' : ''); });
    };
    var armed = null;
    MZ.handlers.psDel = function (b) {
      if (armed !== b.dataset.n) { armed = b.dataset.n; return MZ.status('دوس × تاني علشان تمسح «' + b.dataset.n.replace(/\.(json|ffx)$/i, '') + '»'); }
      armed = null;
      try { E.fs.unlinkSync(E.path.join(ROOT, prefs.psFolder, b.dataset.n)); } catch (e) {}
      MZ.render(); MZ.status('اتمسح');
    };
    MZ.handlers.psNewFolder = function () {
      var nameEl = document.getElementById('psName'), nm = safe(nameEl && nameEl.value.trim() ? nameEl.value : 'فولدر ' + (folders().length + 1));
      E.fs.mkdirSync(E.path.join(ROOT, nm), { recursive: true });
      prefs.psFolder = nm; MZ.savePrefs(); MZ.render();
      MZ.status('اتعمل فولدر «' + nm + '» (الاسم بيتاخد من خانة الاسم)');
    };
    MZ.handlers.psOpen = function () { try { E.cp.spawn('explorer.exe', [E.path.join(ROOT, prefs.psFolder)], { detached: true, stdio: 'ignore' }).unref(); } catch (e) {} };
  }

  // ───────── import from link (both apps): yt-dlp + ffmpeg, then into the timeline
  if (E && E.NODE) {
    E.PACKS.ytdlp = { label: 'أداة التحميل من اللينكات', url: 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe', file: 'yt-dlp.exe', mb: 18 };
    var lk = MZ.tool('tools', 'link'); lk.run = { page: 'link' }; lk.runOn = MZ.HOST;
    var lnJob = null;
    MZ.PAGES.link = function (t) {
      var running = !!lnJob;
      return MZ.pageHead(t) +
        '<div class="card"><span class="label">اللينك</span>' +
        '<div style="display:flex;gap:6px"><input id="lnUrl" type="text" dir="ltr" placeholder="https://…" style="flex:1;min-width:0;height:40px;border-radius:10px;border:1px solid #34353B;background:#1F2024;color:#F2F2F3;padding:0 10px;font-size:12.5px"><button class="btn" data-x="lnPaste" style="height:40px">الصق</button></div>' +
        '<span class="label">نزّله</span>' + MZ.seg('lnKind', prefs.lnKind, [['video', 'فيديو'], ['image', 'صورة'], ['audio', 'صوت بس']]) +
        '<span class="label">لو الموقع طلب تسجيل دخول (زي إنستجرام أحيانًا)</span>' + MZ.seg('lnCookies', prefs.lnCookies, [['', 'من غير'], ['firefox', 'Firefox'], ['edge', 'Edge'], ['chrome', 'Chrome']]) +
        '<span class="hint">تيك توك، يوتيوب، إنستجرام، فيسبوك، X، بنترست، وأي لينك صورة مباشر. الملف بيتحفظ في Downloads › MIGZZ › Links، ويدخل التايملاين عند المؤشر. نزّل بس حاجات من حقك تستخدمها.</span>' +
        (running ? '<div class="bar"><span id="lnBar" style="width:0%"></span></div><button class="btn" data-x="lnCancel">إلغاء</button>' : '<button class="btn primary" data-x="lnGo">استورد</button>') + '</div>';
    };
    MZ.handlers.lnPaste = function () {
      var el = document.getElementById('lnUrl');
      E.cp.execFile('powershell.exe', ['-NoProfile', '-STA', '-NonInteractive', '-Command', 'Get-Clipboard -Raw'], { windowsHide: true }, function (err, so) {
        if (!err && el) el.value = String(so || '').trim().split(/\s+/)[0];
      });
    };
    MZ.handlers.lnCancel = function () { MZ.cancelJob(lnJob); };
    var lnBar = function (p) { var b = document.getElementById('lnBar'); if (b) b.style.width = p + '%'; };
    // H.264/HEVC mp4 and images/wav go in as they are; anything else (VP9, AV1, webm) becomes ProRes so the app can read it
    var probe = function (ff, f, job) { return E.run(ff, ['-hide_banner', '-i', f], null, job).then(function (r) { return r.err || ''; }); };
    MZ.importLink = function (url, kind) {
      if (lnJob) return Promise.resolve();
      var job = lnJob = { cancelled: false }, ff, yt, dir = downloadsDir('Links'), out;
      MZ.render();
      function stop(msg, k) { lnJob = null; MZ.render(); MZ.status(msg, k); }
      function prog(txt, p) { MZ.status(txt, 'busy'); if (p !== null && p !== undefined) lnBar(p); }
      return E.ensure('ffmpeg', prog, job).then(function (f) { ff = f; return E.ensure('ytdlp', prog, job); }).then(function (y) {
        yt = y;
        // keep yt-dlp fresh: sites change often (once every 3 days)
        if (Date.now() - (prefs.lnLast || 0) > 3 * 864e5) {
          prog('بيحدّث أداة التحميل…', null);
          return E.run(yt, ['-U'], null, job).then(function () { prefs.lnLast = Date.now(); MZ.savePrefs(); });
        }
      }).then(function () {
        if (job.cancelled) throw new Error('CANCELLED');
        var direct = /\.(png|jpe?g|webp|gif|bmp)(\?|$)/i.test(url);
        var stamp = Date.now() % 1e6, tpl = E.path.join(dir, '%(title).70B ' + stamp + '.%(ext)s');
        var args = ['--no-playlist', '--newline', '--no-warnings', '--ffmpeg-location', E.path.dirname(ff), '--print', 'after_move:filepath', '-o', tpl];
        if (prefs.lnCookies) args.push('--cookies-from-browser', prefs.lnCookies);
        if (kind === 'audio') args.push('-x', '--audio-format', 'wav');
        else if (kind === 'image') {
          if (direct) return directImage(url, dir, stamp, job);
          args.push('--skip-download', '--write-thumbnail', '--convert-thumbnails', 'png', '--print', 'after_move:%(title).70B', '-o', 'thumbnail:' + E.path.join(dir, '%(title).70B ' + stamp + '.%(ext)s'));
        } else args.push('-f', 'bv*[vcodec^=avc][ext=mp4]+ba[ext=m4a]/b[vcodec^=avc][ext=mp4]/bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b', '--merge-output-format', 'mp4');
        args.push(url);
        prog('بيجيب اللينك…', 0);
        var lastLine = '';
        return E.run(yt, args, function (line) {
          var m = /\[download\]\s+([\d.]+)%/.exec(line);
          if (m) prog('بينزّل… ' + Math.round(Number(m[1])) + '%', Number(m[1]));
          else if (/^\[Merger\]|^\[ExtractAudio\]/.test(line)) prog('بيجهّز الملف…', 100);
          if (line.trim()) lastLine = line;
        }, job).then(function (r) {
          if (job.cancelled) throw new Error('CANCELLED');
          var lines = String(r.out || '').split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean);
          var file = null;
          if (kind === 'image') {
            var title = lines[lines.length - 1];
            var cands = E.fs.readdirSync(dir).filter(function (n) { return n.indexOf(' ' + stamp + '.') > 0 && /\.png$/i.test(n); });
            if (cands.length) file = E.path.join(dir, cands[0]);
          } else file = lines.filter(function (l) { return E.fs.existsSync(l); }).pop();
          if (r.code !== 0 || !file) {
            var e = String(r.err || '');
            if (/login|cookies|private|Sign in|rate-limit/i.test(e)) throw { mz: 'الموقع طالب تسجيل دخول: اختار المتصفح اللي إنت داخل منه على الموقع وجرب تاني' };
            if (/Unsupported URL/i.test(e)) throw { mz: 'اللينك ده مش مدعوم' };
            if (/not available|unavailable|removed|404/i.test(e)) throw { mz: 'الفيديو مش متاح (اتمسح أو خاص)' };
            if (/getaddrinfo|resolve|network|timed out/i.test(e)) throw { mz: 'مفيش نت أو الموقع مش راد' };
            E.log('link failed', e.slice(-2000));
            throw { mz: 'مقدرتش أنزّل اللينك ده. ابعتلنا ملف log.txt من فولدر MIGZZ' };
          }
          return file;
        });
      }).then(function (file) {
        out = file;
        if (kind !== 'video') return file;
        return probe(ff, file, job).then(function (info) {
          if (/Video: (h264|hevc)/.test(info) && /\.(mp4|mov|m4v)$/i.test(file)) return file;
          prog('بيحوّل الفيديو لصيغة البرنامج بيقراها…', null);
          var mov = file.replace(/\.[^.]+$/, '') + ' (ProRes).mov';
          return E.run(ff, ['-hide_banner', '-loglevel', 'error', '-y', '-i', file, '-c:v', 'prores_ks', '-profile:v', '2', '-pix_fmt', 'yuv422p10le', '-c:a', 'pcm_s16le', mov], null, job).then(function (r) {
            if (r.code !== 0 || !E.fs.existsSync(mov)) throw { mz: 'مقدرتش أحوّل الفيديو' };
            E.rmrf(file);
            return mov;
          });
        });
      }).then(function (file) {
        out = file;
        return MZ.call('mz_importMedia', file, E.path.basename(file).replace(/ \d+(?=\.| \(ProRes\))/, ''));
      }).then(function (r) {
        if (!r.ok) throw { mz: MZ.errText(r) };
        stop(r.comp ? 'اتحط في التايملاين: ' + r.name : 'اتحط في المشروع (افتح كومب علشان يدخل التايملاين)');
        return { file: out, name: r.name };
      }).catch(function (e) {
        if (e && e.message === 'CANCELLED') return stop('اتلغى');
        if (e && e.mz) return stop(e.mz, 'err');
        E.log('link failed', e);
        var net = /HTTP|ENOTFOUND|ECONN|timed out|incomplete|EAI_AGAIN/.test(String(e && e.message));
        stop(net ? 'التحميل وقف. اتأكد من النت وجرب تاني' : 'حصل خطأ: ' + (e && e.message ? e.message : e), 'err');
      });
    };
    function directImage(url, dir, stamp, job) {
      var https = window.cep_node ? window.cep_node.require('https') : require('https');
      var name = decodeURIComponent((url.split('?')[0].split('/').pop() || 'image')).replace(/[\\/:*?"<>|]/g, '_');
      var ext = (/\.[a-z0-9]{2,5}$/i.exec(name) || ['.png'])[0], f = E.path.join(dir, name.replace(/\.[a-z0-9]{2,5}$/i, '') + ' ' + stamp + ext);
      return new Promise(function (resolve, reject) {
        function get(u, hops) {
          https.get(u, { headers: { 'User-Agent': 'Mozilla/5.0' } }, function (res) {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && hops < 5) { res.resume(); return get(new URL(res.headers.location, u).href, hops + 1); }
            if (res.statusCode !== 200) { res.resume(); return reject({ mz: 'الصورة مش متاحة (' + res.statusCode + ')' }); }
            var w = E.fs.createWriteStream(f); res.pipe(w);
            w.on('finish', function () { w.close(function () { resolve(f); }); });
            w.on('error', reject);
          }).on('error', reject);
        }
        get(url, 0);
      }).then(function (file) {
        if (!/\.webp$/i.test(file)) return file;
        var png = file.replace(/\.webp$/i, '.png');
        return E.ensure('ffmpeg').then(function (ff) { return E.run(ff, ['-hide_banner', '-loglevel', 'error', '-y', '-i', file, png], null, job); }).then(function () { E.rmrf(file); return png; });
      });
    }
    MZ.handlers.lnGo = function () {
      var el = document.getElementById('lnUrl'), url = el ? el.value.trim() : '';
      if (!/^https?:\/\/\S+$/i.test(url)) return MZ.status('حط لينك صح (بيبدأ بـ https)', 'err');
      MZ.importLink(url, prefs.lnKind);
    };
  }

  MZ.render();
})();
